package com.bankingapp.customer.dto;

import java.math.BigDecimal; // Import for BigDecimal

public class UserProfileDto {

    private Integer userId;
    private String username;
    private String fullName;
    private String email;
    private String phone;
    private String address;
    private String accountNumber;
    private BigDecimal accountBalance;

    // Constructor to easily populate the DTO
    public UserProfileDto(Integer userId, String username, String fullName, String email, String phone,
                          String address, String accountNumber, BigDecimal accountBalance) {
        this.userId = userId;
        this.username = username;
        this.fullName = fullName;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.accountNumber = accountNumber;
        this.accountBalance = accountBalance;
    }

    // Getters for all fields
    public Integer getUserId() {
        return userId;
    }

    public String getUsername() {
        return username;
    }

    public String getFullName() {
        return fullName;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public BigDecimal getAccountBalance() {
        return accountBalance;
    }

    // You can add toString(), equals(), hashCode() if needed, but not strictly necessary for this DTO.
}