package com.bankingapp.customer.controller;

import com.bankingapp.customer.model.PiggyBankGoal;
import com.bankingapp.customer.service.PiggyBankGoalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/piggy-bank")
public class PiggyBankGoalController {

    @Autowired
    private PiggyBankGoalService piggyBankGoalService;

    // Helper method to get user ID from authenticated principal
    private Long getUserId(UserDetails userDetails) {
        // This assumes your UserDetails implementation or your User entity's ID is accessible.
        // You'll need to adapt this based on how your UserDetails stores the user ID.
        // For demonstration, let's assume the username is the user ID for simplicity,
        // OR, you might have a custom UserDetails object that stores the ID.
        // For a real app, you'd fetch the user from a UserService based on username
        // and then get their ID.
        // Placeholder for now: assuming username is convertible to Long or you fetch from DB.
        // Example: if your User model has an ID, you'd likely fetch User by username, then get ID.
        // For now, let's hardcode or parse a dummy ID if UserDetails doesn't have it directly.
        // A better way: Have a UserService to get the User object from UserDetails.getUsername()
        // and then return user.getId().
        // For this example, let's return a dummy ID. YOU NEED TO REPLACE THIS.
        // If your UserDetails contains a custom User object, cast it and get ID.
        // Example: ((CustomUserDetails) userDetails).getUserId();
        return 1L; // <<< IMPORTANT: REPLACE WITH ACTUAL USER ID RETRIEVAL LOGIC >>>
    }


    @GetMapping("/goals")
    public ResponseEntity<List<PiggyBankGoal>> getGoals(@AuthenticationPrincipal UserDetails userDetails) {
        Long userId = getUserId(userDetails); // Get the actual user ID
        List<PiggyBankGoal> goals = piggyBankGoalService.getGoalsByUserId(userId);
        return ResponseEntity.ok(goals);
    }

    @PostMapping("/goals")
    public ResponseEntity<PiggyBankGoal> createGoal(@RequestBody Map<String, Object> payload,
                                                   @AuthenticationPrincipal UserDetails userDetails) {
        Long userId = getUserId(userDetails); // Get the actual user ID
        String goalName = (String) payload.get("goalName");
        BigDecimal targetAmount = new BigDecimal(payload.get("targetAmount").toString());
        LocalDate targetDate = LocalDate.parse((String) payload.get("targetDate"));

        PiggyBankGoal newGoal = new PiggyBankGoal(userId, goalName, targetAmount, targetDate);
        newGoal = piggyBankGoalService.createGoal(newGoal);
        return ResponseEntity.status(HttpStatus.CREATED).body(newGoal);
    }

    @PostMapping("/goals/{goalId}/add-funds")
    public ResponseEntity<PiggyBankGoal> addFundsToGoal(@PathVariable Long goalId,
                                                        @RequestBody Map<String, String> payload) {
        BigDecimal amount = new BigDecimal(payload.get("amount"));
        Optional<PiggyBankGoal> updatedGoal = piggyBankGoalService.addFundsToGoal(goalId, amount);

        return updatedGoal.map(ResponseEntity::ok)
                          .orElseGet(() -> ResponseEntity.notFound().build());
    }
}