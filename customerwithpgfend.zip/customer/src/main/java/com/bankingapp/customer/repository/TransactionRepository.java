package com.bankingapp.customer.repository;

import com.bankingapp.customer.model.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {

    // Custom method to find recent transactions for a specific account ID, ordered by date descending
    List<Transaction> findTop5ByAccountIdOrderByTransactionDateDesc(Long accountId);
    
    List<Transaction> findByAccountIdInOrderByTransactionDateDesc(List<Long> accountIds);
    
    List<Transaction> findByAccountIdAndTransactionDateBetweenOrderByTransactionDateAsc(
            Long accountId, LocalDateTime startDate, LocalDateTime endDate);


}