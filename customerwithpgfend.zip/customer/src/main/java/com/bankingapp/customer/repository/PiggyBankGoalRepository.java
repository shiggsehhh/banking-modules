package com.bankingapp.customer.repository;

import com.bankingapp.customer.model.PiggyBankGoal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PiggyBankGoalRepository extends JpaRepository<PiggyBankGoal, Long> {
    List<PiggyBankGoal> findByUserId(Long userId);
}