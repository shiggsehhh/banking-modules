package com.bankingapp.customer.service;

import com.bankingapp.customer.model.PiggyBankGoal;
import com.bankingapp.customer.repository.PiggyBankGoalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
public class PiggyBankGoalService {

    @Autowired
    private PiggyBankGoalRepository piggyBankGoalRepository;

    public List<PiggyBankGoal> getGoalsByUserId(Long userId) {
        return piggyBankGoalRepository.findByUserId(userId);
    }

    public PiggyBankGoal createGoal(PiggyBankGoal goal) {
        // You might want to add validation here (e.g., target amount > 0)
        return piggyBankGoalRepository.save(goal);
    }

    @Transactional // Ensures atomicity for funds addition
    public Optional<PiggyBankGoal> addFundsToGoal(Long goalId, BigDecimal amount) {
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            // Cannot add non-positive amount
            return Optional.empty();
        }

        Optional<PiggyBankGoal> goalOptional = piggyBankGoalRepository.findById(goalId);
        if (goalOptional.isPresent()) {
            PiggyBankGoal goal = goalOptional.get();
            BigDecimal newCurrentAmount = goal.getCurrentAmount().add(amount);

            // Optional: Prevent exceeding target amount
            if (newCurrentAmount.compareTo(goal.getTargetAmount()) > 0) {
                newCurrentAmount = goal.getTargetAmount(); // Cap at target
                // Or throw an exception if you want to strictly prevent overfunding
            }

            goal.setCurrentAmount(newCurrentAmount);
            return Optional.of(piggyBankGoalRepository.save(goal));
        }
        return Optional.empty(); // Goal not found
    }

    // Optional: Get a single goal by ID
    public Optional<PiggyBankGoal> getGoalById(Long goalId) {
        return piggyBankGoalRepository.findById(goalId);
    }

    // Optional: Delete a goal
    public void deleteGoal(Long goalId) {
        piggyBankGoalRepository.deleteById(goalId);
    }
}