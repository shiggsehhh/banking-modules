package com.bankingapp.customer.dto;

public class AddressUpdateRequest {
    private String address; // Assuming address is a single string field in your User entity

    // Getter and Setter
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}