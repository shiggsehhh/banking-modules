package com.bankingapp.customer.model;

public enum TransactionType {
    Credit, Debit, Transfer
}