package com.bankingapp.customer.service;

import com.bankingapp.customer.dto.UserProfileDto;
import com.bankingapp.customer.model.Account;
import com.bankingapp.customer.model.Loan;
import com.bankingapp.customer.model.LoanStatus;
import com.bankingapp.customer.model.Transaction;
import com.bankingapp.customer.model.User;
import com.bankingapp.customer.model.TransactionMode; // <-- ADD THIS IMPORT
import com.bankingapp.customer.model.TransactionType; // <-- ADD THIS IMPORT
import com.bankingapp.customer.repository.AccountRepository;
import com.bankingapp.customer.repository.LoanRepository;
import com.bankingapp.customer.repository.TransactionRepository;
import com.bankingapp.customer.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional; // <-- ADD THIS IMPORT for @Transactional
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.math.BigDecimal; // <-- ADD THIS IMPORT
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime; // <-- ADD THIS IMPORT
import java.util.List;
import java.util.Optional;
import java.nio.file.Files; // Add this import
import java.nio.file.Path;  // Add this import
import java.nio.file.Paths; // Add this import
import java.util.UUID; 
@Service
public class CustomerService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private AccountRepository accountRepository;

	@Autowired
	private TransactionRepository transactionRepository;

	@Autowired
	private LoanRepository loanRepository;
	
	@Autowired // ADD THIS LINE
    private NotificationService notificationService;
	
	@Autowired // <-- ADD THIS FIELD
    private BCryptPasswordEncoder passwordEncoder;

	private static final BigDecimal DEFAULT_ANNUAL_INTEREST_RATE = new BigDecimal("0.10"); // 10%
	private static final String UPLOAD_DIR = "src/main/resources/static/uploads/loans/"; // Local path for development
	private static final long MAX_FILE_SIZE = 5 * 1024 * 1024; // 5 MB

	/**
	 * Retrieves a user by their ID. * @param userId The ID of the user.
	 * 
	 * @return An Optional containing the User if found, otherwise empty.
	 */
	public Optional<User> getUserById(Integer userId) {
		return userRepository.findById(userId);
	}

	/**
	 * Retrieves all accounts associated with a specific user. * @param userId The
	 * ID of the user.
	 * 
	 * @return A list of Account objects.
	 */
	public List<Account> getAccountsByUserId(Integer userId) {
		return accountRepository.findByUserId(userId);
	}

	/**
	 * Retrieves a specific account by its account ID. * @param accountId The ID of
	 * the account.
	 * 
	 * @return An Optional containing the Account if found, otherwise empty.
	 */
	public Optional<Account> getAccountById(Long accountId) {
		return accountRepository.findById(accountId);
	}

	/**
	 * Retrieves the primary account for a user (assuming the first one found is
	 * primary for simplicity). This method is for dashboard display where a single
	 * balance is often shown. * @param userId The ID of the user.
	 * 
	 * @return An Optional containing the primary Account, or empty if none found.
	 */
	public Optional<Account> getPrimaryAccountForUser(Integer userId) {
		List<Account> accounts = accountRepository.findByUserId(userId);
		return accounts.isEmpty() ? Optional.empty() : Optional.of(accounts.get(0));
	}

	/**
	 * Retrieves the 5 most recent transactions for the user's primary account.
	 *
	 * @param userId The ID of the user.
	 * @return A list of the 5 most recent Transaction objects.
	 */
	public List<Transaction> getRecentTransactionsForUser(Integer userId) {
		Optional<Account> primaryAccountOptional = getPrimaryAccountForUser(userId);

		if (primaryAccountOptional.isPresent()) {
			Long accountId = primaryAccountOptional.get().getAccountId();
			return transactionRepository.findTop5ByAccountIdOrderByTransactionDateDesc(accountId);
		} else {
			return List.of();
		}
	}

	/**
	 * Retrieves all transactions for all accounts belonging to a specific user.
	 *
	 * @param userId The ID of the user.
	 * @return A list of all Transaction objects for the user.
	 */
	public List<Transaction> getAllTransactionsForUser(Integer userId) {
		List<Account> userAccounts = accountRepository.findByUserId(userId);
		List<Long> accountIds = userAccounts.stream().map(Account::getAccountId)
				.collect(java.util.stream.Collectors.toList());

		if (accountIds.isEmpty()) {
			return List.of();
		}

		return transactionRepository.findByAccountIdInOrderByTransactionDateDesc(accountIds);
	}

	/**
	 * Processes a money transfer from the customer's primary account to a
	 * recipient. This method is transactional to ensure atomicity of balance update
	 * and transaction logging.
	 *
	 * @param senderUserId           The ID of the user initiating the transfer.
	 * @param recipientName          The name of the recipient.
	 * @param recipientAccountNumber The account number of the recipient.
	 * @param recipientIfscCode      The IFSC code of the recipient's bank.
	 * @param amount                 The amount to be transferred.
	 * @throws IllegalArgumentException if sender account not found, insufficient
	 *                                  funds, or other business rules violated.
	 */
	@Transactional // Ensures that if any part of this method fails, all changes are rolled back
	public void performTransfer(Integer senderUserId, String recipientName, String recipientAccountNumber,
			String recipientIfscCode, BigDecimal amount) {

		// 1. Get the sender's primary account
		Optional<Account> senderAccountOptional = getPrimaryAccountForUser(senderUserId);
		if (senderAccountOptional.isEmpty()) {
			throw new IllegalArgumentException("Sender account not found for user ID: " + senderUserId);
		}
		Account senderAccount = senderAccountOptional.get();

		// 2. Check for sufficient funds
		if (senderAccount.getBalance().compareTo(amount) < 0) {
			throw new IllegalArgumentException("Insufficient funds. Available balance: ₹" + senderAccount.getBalance());
		}

		// 3. Debit the sender's account
		senderAccount.setBalance(senderAccount.getBalance().subtract(amount));
		accountRepository.save(senderAccount); // Save the updated balance

		// 4. Create and save a transaction record for the sender (DEBIT)
		Transaction senderTransaction = new Transaction();
		senderTransaction.setAccountId(senderAccount.getAccountId());
		senderTransaction.setTransactionType(TransactionType.Debit); // It's a Debit from sender's perspective
		senderTransaction.setAmount(amount);
		senderTransaction.setTransactionMode(TransactionMode.IMPS); // Defaulting to IMPS for transfers
		senderTransaction.setTransactionDate(LocalDateTime.now());

		// Construct description to include recipient details and IFSC code
		// This is a workaround since there's no dedicated IFSC column in the
		// Transaction model
		String description = "Transfer to " + recipientName + " (Acc: " + recipientAccountNumber + ", IFSC: "
				+ recipientIfscCode + ")";
		senderTransaction.setDescription(description);
		senderTransaction.setReferenceAccountNumber(recipientAccountNumber); // Recipient's account is the reference for
																				// this debit

		transactionRepository.save(senderTransaction);

		// --- Important Note for Future Development (Recipient Credit) ---
		// For now, this implementation only handles the debit from the sender's
		// account.
		// A complete transfer system would also need to:
		// A) Find the recipient's account (if within the same system) and credit it,
		// creating a separate TransactionType.Credit record for them.
		// B) If the recipient is in an external bank, integrate with a payment gateway
		// API
		// (e.g., NEFT, IMPS, UPI) to send the funds out.
		// This current setup simulates the outward part of a transfer.
	}

	/**
	 * Processes a deposit into the customer's primary account. This method is
	 * transactional to ensure atomicity of balance update and transaction logging.
	 *
	 * @param userId The ID of the user for whom the deposit is made.
	 * @param amount The amount to be deposited.
	 * @param mode   The mode of the transaction (e.g., Cash, Cheque).
	 * @throws IllegalArgumentException if user's account not found.
	 */
	@Transactional // Ensures atomicity: either both balance update and transaction save succeed,
					// or both fail.
	public void processDeposit(Integer userId, BigDecimal amount, TransactionMode mode) {
		// 1. Get the user's primary account
		Optional<Account> userAccountOptional = getPrimaryAccountForUser(userId);
		if (userAccountOptional.isEmpty()) {
			throw new IllegalArgumentException("Account not found for user ID: " + userId);
		}
		Account userAccount = userAccountOptional.get();

		// 2. Add the amount to the account balance
		userAccount.setBalance(userAccount.getBalance().add(amount));
		accountRepository.save(userAccount); // Save the updated balance

		// 3. Create and save a transaction record (CREDIT)
		Transaction depositTransaction = new Transaction();
		depositTransaction.setAccountId(userAccount.getAccountId());
		depositTransaction.setTransactionType(TransactionType.Credit); // It's a Credit for the user
		depositTransaction.setAmount(amount);
		depositTransaction.setTransactionMode(mode); // Use the mode provided (Cash/Cheque)
		depositTransaction.setTransactionDate(LocalDateTime.now());

		// Set a description based on the deposit mode
		depositTransaction.setDescription(mode.toString() + " Deposit");
		// For deposits, reference_account_number can be null or empty string as no
		// external account is involved.
		depositTransaction.setReferenceAccountNumber(null); // Or use an empty string ""

		transactionRepository.save(depositTransaction);
	}

	// --- NEW METHOD for Loan Zone functionality ---
	/**
	 * Retrieves all loans for a given user ID.
	 *
	 * @param userId The ID of the user.
	 * @return A list of Loan objects associated with the user.
	 */
	public List<Loan> getLoansByUserId(Integer userId) {
		return loanRepository.findByUserId(userId);
	}

	/**
	 * Processes an EMI payment for a specific loan. Deducts amount from user's
	 * primary account, updates loan details, and records a transaction.
	 *
	 * @param userId        The ID of the user making the payment.
	 * @param loanId        The ID of the loan to pay for.
	 * @param paymentAmount The amount to be paid (expected to be EMI amount).
	 * @return The new available balance of the user's primary account after the
	 *         payment.
	 * @throws IllegalArgumentException if loan/account not found, insufficient
	 *                                  funds, or loan not active/overdue.
	 */
	@Transactional
	public BigDecimal processLoanPayment(Integer userId, Long loanId, BigDecimal paymentAmount) { // <--- CHANGE RETURN
																									// TYPE TO
																									// BigDecimal
		// 1. Retrieve the Loan
		Optional<Loan> loanOptional = loanRepository.findById(loanId);
		if (loanOptional.isEmpty()) {
			throw new IllegalArgumentException("Loan not found with ID: " + loanId);
		}
		Loan loan = loanOptional.get();

		// Ensure the loan belongs to the correct user
		if (!loan.getUserId().equals(userId)) {
			throw new IllegalArgumentException("Loan ID " + loanId + " does not belong to user ID " + userId);
		}

		// Check loan status
		if (!(loan.getLoanStatus() == LoanStatus.ACTIVE || loan.getLoanStatus() == LoanStatus.OVERDUE)) {
			throw new IllegalArgumentException("Loan is not active or overdue for payment.");
		}

		// 2. Retrieve the User's Primary Account
		Optional<Account> primaryAccountOptional = getPrimaryAccountForUser(userId);
		if (primaryAccountOptional.isEmpty()) {
			throw new IllegalArgumentException("Primary account not found for user ID: " + userId);
		}
		Account primaryAccount = primaryAccountOptional.get();

		// 3. Check for sufficient funds
		if (primaryAccount.getBalance().compareTo(paymentAmount) < 0) {
			throw new IllegalArgumentException(
					"Insufficient funds. Available balance: ₹" + primaryAccount.getBalance());
		}

		// 4. Deduct amount from account
		primaryAccount.setBalance(primaryAccount.getBalance().subtract(paymentAmount));
		accountRepository.save(primaryAccount); // Save updated account balance

		// 5. Update Loan details
		loan.setAmountPaid(loan.getAmountPaid().add(paymentAmount));
		loan.setCurrentDue(loan.getCurrentDue().subtract(paymentAmount));

		// Update next due date (advance by one month)
		if (loan.getNextDueDate() != null) {
			loan.setNextDueDate(loan.getNextDueDate().plusMonths(1));
		} else {
			// Fallback: next month from now, or implement specific logic for first EMI.
			// For robust application, you might want a loan disbursement date or a schedule
			// to derive this.
			loan.setNextDueDate(LocalDate.now().plusMonths(1));
		}

		// 6. Check if loan is fully paid
		if (loan.getCurrentDue().compareTo(BigDecimal.ZERO) <= 0) {
			loan.setCurrentDue(BigDecimal.ZERO); // Ensure it's not negative
			loan.setLoanStatus(LoanStatus.CLOSED);
			loan.setNextDueDate(null); // No more due dates
		} else {
			// If it was OVERDUE, change to ACTIVE upon successful payment
			if (loan.getLoanStatus() == LoanStatus.OVERDUE) {
				loan.setLoanStatus(LoanStatus.ACTIVE);
			}
		}

		loanRepository.save(loan); // Save updated loan details

		// 7. Record Transaction
		Transaction loanPaymentTransaction = new Transaction();
		loanPaymentTransaction.setAccountId(primaryAccount.getAccountId());
		loanPaymentTransaction.setTransactionType(TransactionType.Debit);
		loanPaymentTransaction.setAmount(paymentAmount);
		loanPaymentTransaction.setTransactionMode(TransactionMode.IMPS);
		loanPaymentTransaction.setTransactionDate(LocalDateTime.now());
		loanPaymentTransaction.setDescription("EMI Payment for Loan ID: " + loanId);
		loanPaymentTransaction.setReferenceAccountNumber(null);

		transactionRepository.save(loanPaymentTransaction);

		return primaryAccount.getBalance(); // <--- RETURN THE NEW BALANCE
	}

	/**
	 * Processes a new loan application for a user. Includes basic eligibility
	 * checks and EMI calculation.
	 *
	 * @param userId         The ID of the user applying for the loan.
	 * @param loanAmount     The requested loan principal amount.
	 * @param loanTermMonths The requested loan term in months.
	 * @return true if the application was successful, false otherwise (though
	 *         exceptions are better for errors).
	 * @throws IllegalArgumentException if loan amount/term is invalid or
	 *                                  eligibility fails.
	 */
	@Transactional
	public boolean applyForLoan(Integer userId, BigDecimal loanAmount, Integer loanTermMonths,MultipartFile assetDocument) {
		// Basic Input Validation
		if (loanAmount == null || loanAmount.compareTo(BigDecimal.ZERO) <= 0) {
			throw new IllegalArgumentException("Loan amount must be positive.");
		}
		if (loanTermMonths == null || loanTermMonths <= 0) {
			throw new IllegalArgumentException("Loan term must be positive.");
		}

		// Placeholder Eligibility Check:
		// 1. Check if user exists
		Optional<User> userOptional = userRepository.findById(userId);
		if (userOptional.isEmpty()) {
			throw new IllegalArgumentException("User not found with ID: " + userId);
		}

		// 2. Prevent too many pending/active loans (Example: max 2 active/pending
		// loans)
		List<Loan> userLoans = loanRepository.findByUserId(userId);
		long activeOrPendingLoans = userLoans.stream().filter(l -> l.getLoanStatus() == LoanStatus.ACTIVE
				|| l.getLoanStatus() == LoanStatus.PENDING || l.getLoanStatus() == LoanStatus.OVERDUE).count();
		if (activeOrPendingLoans >= 2) { // Example limit
			throw new IllegalArgumentException(
					"You have too many active or pending loans. Please settle existing loans before applying for a new one.");
		}

		// 3. Loan amount limits (Example: Min 1,000, Max 500,000)
		BigDecimal minLoanAmount = new BigDecimal("1000");
		BigDecimal maxLoanAmount = new BigDecimal("500000");
		if (loanAmount.compareTo(minLoanAmount) < 0 || loanAmount.compareTo(maxLoanAmount) > 0) {
			throw new IllegalArgumentException(
					"Loan amount must be between ₹" + minLoanAmount + " and ₹" + maxLoanAmount + ".");
		}

		// 4. Loan term limits (Example: Min 6 months, Max 60 months)
		int minTermMonths = 6;
		int maxTermMonths = 60;
		if (loanTermMonths < minTermMonths || loanTermMonths > maxTermMonths) {
			throw new IllegalArgumentException(
					"Loan term must be between " + minTermMonths + " and " + maxTermMonths + " months.");
		}
		//5.Document Verification
		String documentPath = null;
	    if (assetDocument != null && !assetDocument.isEmpty()) {
	        try {
	            documentPath = saveDocument(assetDocument);
	        } catch (IOException e) {
	            throw new IllegalArgumentException("Failed to upload document: " + e.getMessage());
	        }
	    }

		// EMI Calculation
		// Monthly interest rate = (Annual Rate / 12)
		BigDecimal monthlyInterestRate = DEFAULT_ANNUAL_INTEREST_RATE.divide(new BigDecimal("12"), 8,
				RoundingMode.HALF_UP); // 8 decimal places for precision

		// Number of payments (N)
		BigDecimal numberOfPayments = new BigDecimal(loanTermMonths);

		// EMI Formula: P * R * (1 + R)^N / ((1 + R)^N - 1)
		BigDecimal emi;
		if (monthlyInterestRate.compareTo(BigDecimal.ZERO) == 0) {
			// Handle zero interest rate case to avoid division by zero
			emi = loanAmount.divide(numberOfPayments, 2, RoundingMode.HALF_UP);
		} else {
			BigDecimal onePlusR = BigDecimal.ONE.add(monthlyInterestRate);
			BigDecimal powerTerm = onePlusR.pow(loanTermMonths);

			BigDecimal numerator = loanAmount.multiply(monthlyInterestRate).multiply(powerTerm);
			BigDecimal denominator = powerTerm.subtract(BigDecimal.ONE);

			if (denominator.compareTo(BigDecimal.ZERO) == 0) {
				// Should not happen with positive interest rate, but good for robustness
				throw new ArithmeticException("Cannot calculate EMI: Denominator is zero.");
			}
			emi = numerator.divide(denominator, 2, RoundingMode.HALF_UP); // Round to 2 decimal places for currency
		}

		// Create new Loan entity
		Loan newLoan = new Loan();
		newLoan.setUserId(userId);
		newLoan.setLoanAmount(loanAmount);
		newLoan.setInterestRate(DEFAULT_ANNUAL_INTEREST_RATE.multiply(new BigDecimal("100"))); // Store as percentage
																								// (e.g., 10.00)
		newLoan.setTenureMonths(loanTermMonths);
		newLoan.setEmiAmount(emi);
		newLoan.setAmountPaid(BigDecimal.ZERO);
		newLoan.setCurrentDue(loanAmount); // Initially, current due is the full loan amount
		newLoan.setLoanStatus(LoanStatus.PENDING); // Initial status is PENDING
		newLoan.setApplicationDate(LocalDate.now());
		newLoan.setAssetDocumentPath(documentPath);
		// next_due_date will be set upon approval/disbursement, or on the first EMI if
		// active.
		// For now, we'll leave it null for PENDING loans.
		newLoan.setNextDueDate(null);

		loanRepository.save(newLoan); // Save the new loan application

		return true; // Indicate success
	}
	// ... (inside CustomerService class) ...

	private String saveDocument(MultipartFile file) throws IOException {
	    // Validate file type (PDF)
	    if (!"application/pdf".equals(file.getContentType())) {
	        throw new IllegalArgumentException("Only PDF files are allowed for asset documents.");
	    }

	    // Validate file size
	    if (file.getSize() > MAX_FILE_SIZE) {
	        throw new IllegalArgumentException("File size exceeds the maximum limit of " + (MAX_FILE_SIZE / (1024 * 1024)) + "MB.");
	    }

	    // Ensure the upload directory exists
	    Path uploadPath = Paths.get(UPLOAD_DIR);
	    if (!Files.exists(uploadPath)) {
	        Files.createDirectories(uploadPath);
	    }

	    // Generate a unique filename to prevent clashes
	    String originalFilename = file.getOriginalFilename();
	    String fileExtension = "";
	    if (originalFilename != null && originalFilename.contains(".")) {
	        fileExtension = originalFilename.substring(originalFilename.lastIndexOf("."));
	    }
	    String uniqueFileName = UUID.randomUUID().toString() + fileExtension;

	    // Construct the full file path
	    Path filePath = uploadPath.resolve(uniqueFileName);

	    // Save the file
	    Files.copy(file.getInputStream(), filePath);

	    // Return the relative path to be stored in the database
	    // We'll store the path relative to 'static' or a configured base URL for serving
	    return "/uploads/loans/" + uniqueFileName; // This path is relative to src/main/resources/static
	                                              // For serving, Spring will map /uploads to static/uploads
	}
	
	/**
     * Fetches user's primary account, transactions within a date range, and calculates opening balance.
     *
     * @param userId The ID of the user.
     * @param startDate The start date of the statement period.
     * @param endDate The end date of the statement period.
     * @return A StatementData object containing user, account, transactions, and opening/closing balances.
     * @throws IllegalArgumentException if user or primary account not found.
     */
    public StatementData getTransactionsForStatement(Integer userId, LocalDate startDate, LocalDate endDate) {
        Optional<User> userOptional = userRepository.findById(userId);
        if (userOptional.isEmpty()) {
            throw new IllegalArgumentException("User not found with ID: " + userId);
        }
        User user = userOptional.get();

        Optional<Account> primaryAccountOptional = getPrimaryAccountForUser(userId);
        if (primaryAccountOptional.isEmpty()) {
            throw new IllegalArgumentException("Primary account not found for user ID: " + userId);
        }
        Account account = primaryAccountOptional.get();

        // Transactions within the period
        // Adjust transactionRepository.findByAccountIdAndTransactionDateBetween if your method is different
        List<Transaction> transactionsInPeriod = transactionRepository
                .findByAccountIdAndTransactionDateBetweenOrderByTransactionDateAsc(
                        account.getAccountId(),
                        startDate.atStartOfDay(), // Start of day for start date
                        endDate.plusDays(1).atStartOfDay().minusNanos(1) // End of day for end date
                );

        // Calculate opening balance for the statement period:
        // Current balance - sum of all credits in period + sum of all debits in period
        BigDecimal closingBalance = account.getBalance(); // This is the current, up-to-date balance
        BigDecimal totalCreditsInPeriod = BigDecimal.ZERO;
        BigDecimal totalDebitsInPeriod = BigDecimal.ZERO;

        for (Transaction t : transactionsInPeriod) {
            if (t.getTransactionType() == TransactionType.Credit) {
                totalCreditsInPeriod = totalCreditsInPeriod.add(t.getAmount());
            } else if (t.getTransactionType() == TransactionType.Debit) {
                totalDebitsInPeriod = totalDebitsInPeriod.add(t.getAmount());
            }
        }

        // The balance *before* the transactions in this period happened
        // closingBalance - totalCreditsInPeriod + totalDebitsInPeriod
        BigDecimal openingBalance = closingBalance
                                    .subtract(totalCreditsInPeriod)
                                    .add(totalDebitsInPeriod);

        // Fetch transactions BEFORE the start date to calculate opening balance
        // This is a more robust way to get opening balance based on historical data.
        // For simplicity, we calculate based on current balance and transactions in period above.
        // A more complex approach would be:
        // 1. Get current balance.
        // 2. Sum all transactions *after* endDate.
        // 3. Subtract (credits after) and Add (debits after) from current balance to get balance at endDate.
        // 4. Sum all transactions *in* period (credits/debits).
        // 5. Calculate opening = balanceAtEndDate - totalCreditsInPeriod + totalDebitsInPeriod.
        // For now, let's stick to the simpler approach (current balance adjusted by period transactions).

        // Or, ideally, calculate the true opening balance by summing all transactions *before* startDate
        // List<Transaction> transactionsBeforePeriod = transactionRepository
        //         .findByAccountIdAndTransactionDateBefore(account.getAccountId(), startDate.atStartOfDay());
        // BigDecimal trueOpeningBalance = initialAccountBalance + (sum of credits before) - (sum of debits before)
        // This would require fetching the *initial* account balance and recalculating.
        // The approach above (adjusting current balance) is simpler for a basic statement.

        return new StatementData(user, account, transactionsInPeriod, openingBalance, closingBalance, totalDebitsInPeriod, totalCreditsInPeriod);
        
    }
    
    /**
     * Retrieves the comprehensive profile data for a user, including user details
     * and their primary account information.
     *
     * @param userId The ID of the user.
     * @return An Optional containing UserProfileDto if user and primary account are found,
     * otherwise empty.
     */
    public Optional<UserProfileDto> getUserProfile(Integer userId) {
        // 1. Get the User details
        Optional<User> userOptional = userRepository.findById(userId);

        if (userOptional.isEmpty()) {
            return Optional.empty(); // User not found
        }
        User user = userOptional.get();

        // 2. Get the Primary Account details using the existing service method
        Optional<Account> primaryAccountOptional = getPrimaryAccountForUser(userId);

        String accountNumber = null;
        BigDecimal accountBalance = null;

        if (primaryAccountOptional.isPresent()) {
            Account primaryAccount = primaryAccountOptional.get();
            accountNumber = primaryAccount.getAccountNumber();
            accountBalance = primaryAccount.getBalance();
        }
        // Note: If a user might exist without an account, we handle that by setting account details to null.
        // You might want to throw an exception or handle this differently based on your business logic.

        // 3. Construct the UserProfileDto
        UserProfileDto userProfile = new UserProfileDto(
            user.getUserId(),
            user.getUsername(),
            user.getFullName(),
            user.getEmail(),
            user.getPhone(),
            user.getAddress(),
            accountNumber,
            accountBalance
        );

        return Optional.of(userProfile);
    }
    
    /**
     * Changes the user's password after verifying the current password.
     * @param userId The ID of the user.
     * @param currentPassword The user's current password.
     * @param newPassword The new password to set.
     * @throws IllegalArgumentException if user not found, current password is incorrect,
     * or new password is empty/invalid.
     */
    @Transactional // Ensures the database update is atomic
    public void changePassword(Integer userId, String currentPassword, String newPassword) {
        Optional<User> userOptional = userRepository.findById(userId);
        if (userOptional.isEmpty()) {
            throw new IllegalArgumentException("User not found.");
        }
        User user = userOptional.get();

        // 1. Verify current password
        if (!passwordEncoder.matches(currentPassword, user.getPasswordHash())) {
            throw new IllegalArgumentException("Incorrect current password.");
        }

        // 2. Basic validation for new password
        if (newPassword == null || newPassword.trim().isEmpty() || newPassword.length() < 6) { // Example: min length 6
            throw new IllegalArgumentException("New password cannot be empty and must be at least 6 characters long.");
        }
        if (passwordEncoder.matches(newPassword, user.getPasswordHash())) {
            throw new IllegalArgumentException("New password cannot be the same as the old password.");
        }

        // 3. Hash and set the new password
        user.setPasswordHash(passwordEncoder.encode(newPassword));
        user.setUpdatedAt(LocalDateTime.now()); // Update timestamp
        userRepository.save(user); // Save the updated user

        // Optionally, notify the user about password change
        notificationService.createNotification(userId, "Your password has been changed successfully.");
    }

    /**
     * Updates the user's email and phone number.
     * @param userId The ID of the user.
     * @param newEmail The new email address.
     * @param newPhone The new phone number.
     * @throws IllegalArgumentException if user not found or input is invalid.
     */
    @Transactional
    public void updateContactInfo(Integer userId, String newEmail, String newPhone) {
        Optional<User> userOptional = userRepository.findById(userId);
        if (userOptional.isEmpty()) {
            throw new IllegalArgumentException("User not found.");
        }
        User user = userOptional.get();

        // Basic validation (you might want more robust regex validation)
        if (newEmail != null && !newEmail.trim().isEmpty() && !newEmail.equals(user.getEmail())) {
            // Add email format validation if needed
            if (!newEmail.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}$")) {
                throw new IllegalArgumentException("Invalid email format.");
            }
            user.setEmail(newEmail.trim());
        }

        if (newPhone != null && !newPhone.trim().isEmpty() && !newPhone.equals(user.getPhone())) {
            // Add phone number format validation if needed (e.g., digits only, length)
            if (!newPhone.matches("^\\d{10}$")) { // Example: 10 digits
                throw new IllegalArgumentException("Invalid phone number format. Must be 10 digits.");
            }
            user.setPhone(newPhone.trim());
        }

        if (!user.getEmail().equals(newEmail) || !user.getPhone().equals(newPhone)) { // Only save if changes were made
            user.setUpdatedAt(LocalDateTime.now()); // Update timestamp
            userRepository.save(user);
            notificationService.createNotification(userId, "Your contact information has been updated.");
        }
    }

    /**
     * Updates the user's residential address.
     * @param userId The ID of the user.
     * @param newAddress The new residential address.
     * @throws IllegalArgumentException if user not found or address is empty.
     */
    @Transactional
    public void updateAddress(Integer userId, String newAddress) {
        Optional<User> userOptional = userRepository.findById(userId);
        if (userOptional.isEmpty()) {
            throw new IllegalArgumentException("User not found.");
        }
        User user = userOptional.get();

        if (newAddress == null || newAddress.trim().isEmpty()) {
            throw new IllegalArgumentException("Address cannot be empty.");
        }

        if (!newAddress.trim().equals(user.getAddress())) { // Only save if address actually changed
            user.setAddress(newAddress.trim());
            user.setUpdatedAt(LocalDateTime.now()); // Update timestamp
            userRepository.save(user);
            notificationService.createNotification(userId, "Your residential address has been updated.");
        }
    }
}