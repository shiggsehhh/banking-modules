package com.bank.branchmanagerportal.repository;

import com.bank.branchmanagerportal.entity.LoanApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.time.Month;
import java.util.List;

public interface LoanApplicationRepository extends JpaRepository<LoanApplication, Long> {
    List<LoanApplication> findByBranchName(String branchName);

    long countByBranchName(String branchName);

    long countByBranchNameAndStatus(String branchName, String status);

    // Count new loan applications on a specific date for a branch - ADDED IS NOT NULL
    @Query("SELECT COUNT(l) FROM LoanApplication l WHERE l.branchName = :branchName AND FUNCTION('DATE', l.applicationDate) = :date AND l.applicationDate IS NOT NULL")
    long countByBranchNameAndApplicationDate(@Param("branchName") String branchName, @Param("date") LocalDate date);

    // Sum approved loan amounts on a specific date for a branch - ADDED IS NOT NULL
    @Query("SELECT COALESCE(SUM(l.amount), 0.0) FROM LoanApplication l WHERE l.branchName = :branchName AND l.status = 'APPROVED' AND FUNCTION('DATE', l.applicationDate) = :date AND l.applicationDate IS NOT NULL")
    double sumApprovedAmountByBranchNameAndApplicationDate(@Param("branchName") String branchName, @Param("date") LocalDate date);

    // Count loan applications by month for a specific branch - ADDED IS NOT NULL
    @Query("SELECT FUNCTION('MONTH', l.applicationDate) AS month, COUNT(l) FROM LoanApplication l WHERE l.branchName = :branchName AND l.applicationDate IS NOT NULL GROUP BY FUNCTION('MONTH', l.applicationDate) ORDER BY month")
    List<Object[]> countApplicationsByMonth(@Param("branchName") String branchName);

    // Sum approved loan amounts by month for a specific branch - ADDED IS NOT NULL
    @Query("SELECT FUNCTION('MONTH', l.applicationDate) AS month, COALESCE(SUM(l.amount), 0.0) FROM LoanApplication l WHERE l.branchName = :branchName AND l.status = 'APPROVED' AND l.applicationDate IS NOT NULL GROUP BY FUNCTION('MONTH', l.applicationDate) ORDER BY month")
    List<Object[]> sumApprovedAmountByMonth(@Param("branchName") String branchName);

    // Total sum of APPROVED loan amounts for a given branch
    @Query("SELECT COALESCE(SUM(l.amount), 0.0) FROM LoanApplication l WHERE l.branchName = :branchName AND l.status = 'APPROVED'")
    double sumTotalApprovedAmountByBranchName(@Param("branchName") String branchName);
}
