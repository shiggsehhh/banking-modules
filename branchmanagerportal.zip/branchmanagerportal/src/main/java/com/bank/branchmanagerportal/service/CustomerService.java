package com.bank.branchmanagerportal.service;

import com.bank.branchmanagerportal.entity.Customer;
import com.bank.branchmanagerportal.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate; // Import for LocalDate
import java.util.List;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    public List<Customer> getCustomersByBranch(String branchName) {
        return customerRepository.findByBranchName(branchName);
    }

    public Customer saveCustomer(Customer customer) {
        // Set registration date for new customers
        if (customer.getId() == null) { // Assuming it's a new customer if ID is null
            customer.setRegistrationDate(LocalDate.now());
        }
        return customerRepository.save(customer);
    }

    public Customer getCustomerById(Long id) {
        return customerRepository.findById(id).orElse(null);
    }
}
