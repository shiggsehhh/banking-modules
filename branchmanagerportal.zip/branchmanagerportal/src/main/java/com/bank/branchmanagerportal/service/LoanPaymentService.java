// src/main/java/com/bank/branchmanagerportal/service/LoanPaymentService.java
package com.bank.branchmanagerportal.service;

import com.bank.branchmanagerportal.entity.LoanPayment;
import com.bank.branchmanagerportal.entity.LoanPaymentGroup;

import java.util.List;

public interface LoanPaymentService {
    List<LoanPayment> getPaymentsByBranch(String branchName);
    String recordPayment(LoanPayment payment); // Changed return type to String
    List<LoanPaymentGroup> getGroupedPayments(String branchName);
}
