// src/main/java/com/bank/branchmanagerportal/service/BranchStaffService.java
package com.bank.branchmanagerportal.service;

import com.bank.branchmanagerportal.entity.BranchStaff;
import com.bank.branchmanagerportal.repository.BranchStaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service // Marks this class as a Spring service component
public class BranchStaffService {

    @Autowired // Injects the BranchStaffRepository
    private BranchStaffRepository repository;

    /**
     * Retrieves a list of all staff members belonging to a specific branch.
     * This method will now include staff of all statuses.
     * @param branchName The name of the branch.
     * @return A list of BranchStaff entities.
     */
    public List<BranchStaff> getStaffByBranch(String branchName) {
        return repository.findByBranchName(branchName);
    }

    /**
     * Retrieves a list of staff members for a specific branch and status.
     * Useful for getting 'PENDING_APPROVAL' staff or 'ACTIVE' staff.
     * @param branchName The name of the branch.
     * @param status The status of the staff member (e.g., "PENDING_APPROVAL", "ACTIVE", "REJECTED").
     * @return A list of BranchStaff entities matching the criteria.
     */
    public List<BranchStaff> getStaffByBranchAndStatus(String branchName, String status) {
        return repository.findByBranchNameAndStatus(branchName, status);
    }

    /**
     * Adds a new staff member to the database.
     * New staff members will have their status set to "PENDING_APPROVAL" by default.
     * Their role will be implicitly set to "TELLER".
     * The branchName must be set by the caller (controller).
     * @param staff The BranchStaff entity to be saved.
     */
    public void addStaff(BranchStaff staff) {
        // Automatically set the role to "TELLER" as per the requirement
        staff.setRole("TELLER");
        // Set initial status for new staff members
        staff.setStatus("PENDING_APPROVAL");
        repository.save(staff);
    }

    /**
     * Approves a pending staff member, changing their status to "ACTIVE".
     * Ensures the staff member belongs to the specified branch and is in PENDING_APPROVAL status.
     * @param staffId The ID of the staff member to approve.
     * @param branchName The branch name of the manager performing the action.
     * @return true if approved, false otherwise (e.g., not found, wrong branch, wrong status).
     */
    public boolean approveStaff(Long staffId, String branchName) {
        Optional<BranchStaff> staffOptional = repository.findById(staffId);
        if (staffOptional.isPresent()) {
            BranchStaff staff = staffOptional.get();
            // Crucial: Ensure the staff belongs to the manager's branch AND is pending approval
            if (staff.getBranchName().equals(branchName) && "PENDING_APPROVAL".equals(staff.getStatus())) {
                staff.setStatus("ACTIVE");
                repository.save(staff);
                return true;
            } else {
                System.out.println("WARN: Staff " + staff.getName() + " (ID: " + staff.getId() + ") in branch " + staff.getBranchName() + " cannot be approved by manager of branch " + branchName + " or is not in PENDING_APPROVAL status.");
                return false;
            }
        } else {
            System.out.println("ERROR: Staff with ID " + staffId + " not found for approval.");
            return false;
        }
    }

    /**
     * Rejects a pending staff member, changing their status to "REJECTED".
     * Ensures the staff member belongs to the specified branch.
     * @param staffId The ID of the staff member to reject.
     * @param branchName The branch name of the manager performing the action.
     * @return true if rejected, false otherwise.
     */
    public boolean rejectStaff(Long staffId, String branchName) {
        Optional<BranchStaff> staffOptional = repository.findById(staffId);
        if (staffOptional.isPresent()) {
            BranchStaff staff = staffOptional.get();
            // Crucial: Ensure the staff belongs to the manager's branch
            if (staff.getBranchName().equals(branchName)) {
                staff.setStatus("REJECTED");
                repository.save(staff);
                return true;
            } else {
                System.out.println("WARN: Staff " + staff.getName() + " (ID: " + staff.getId() + ") in branch " + staff.getBranchName() + " cannot be rejected by manager of branch " + branchName + ".");
                return false;
            }
        } else {
            System.out.println("ERROR: Staff with ID " + staffId + " not found for rejection.");
            return false;
        }
    }

    /**
     * Deletes a staff member by their ID.
     * Ensures the staff member belongs to the specified branch.
     * @param id The ID of the staff member to delete.
     * @param branchName The branch name of the manager performing the action.
     * @return true if deleted, false otherwise.
     */
    public boolean deleteStaff(Long id, String branchName) {
        Optional<BranchStaff> staffOptional = repository.findById(id);
        if (staffOptional.isPresent()) {
            BranchStaff staff = staffOptional.get();
            // Crucial: Ensure the staff belongs to the manager's branch before deleting
            if (staff.getBranchName().equals(branchName)) {
                repository.deleteById(id);
                return true;
            } else {
                System.out.println("WARN: Staff " + staff.getName() + " (ID: " + staff.getId() + ") in branch " + staff.getBranchName() + " cannot be deleted by manager of branch " + branchName + ".");
                return false;
            }
        } else {
            System.out.println("ERROR: Staff with ID " + id + " not found for deletion.");
            return false;
        }
    }

    /**
     * Finds a staff member by their username for authentication purposes.
     * @param username The username of the staff member.
     * @return BranchStaff object if found, otherwise null.
     */
    public BranchStaff findByUsername(String username) {
        return repository.findByUsername(username);
    }
}
