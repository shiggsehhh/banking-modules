// src/main/java/com/bank/branchmanagerportal/service/BranchManagerService.java
package com.bank.branchmanagerportal.service;

import com.bank.branchmanagerportal.entity.BranchManager;
import com.bank.branchmanagerportal.repository.BranchManagerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime; // Import LocalDateTime

@Service
public class BranchManagerService {

    @Autowired
    private BranchManagerRepository branchManagerRepository;

    public BranchManager authenticate(String username, String password) {
        BranchManager manager = branchManagerRepository.findByUsernameAndPassword(username, password);
        if (manager != null) {
            // Update last login timestamp upon successful authentication
            manager.setLastLogin(LocalDateTime.now());
            branchManagerRepository.save(manager); // Save the updated manager object
        }
        return manager;
    }
}
