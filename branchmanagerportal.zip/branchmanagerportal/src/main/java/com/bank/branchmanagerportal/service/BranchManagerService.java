package com.bank.branchmanagerportal.service;

import com.bank.branchmanagerportal.entity.BranchManager;
import com.bank.branchmanagerportal.repository.BranchManagerRepository;
import org.springframework.beans.factory.annotation.Autowired;
// REMOVED: No longer need BCryptPasswordEncoder
// import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime; // Import LocalDateTime

@Service
public class BranchManagerService {

    @Autowired
    private BranchManagerRepository branchManagerRepository;

    

    /**
     * Authenticates a BranchManager using username and password (plain text).
     * The last login timestamp is updated upon successful authentication.
     * @param username The username of the manager.
     * @param password The plain-text password provided by the user.
     * @return The authenticated BranchManager object, or null if authentication fails.
     */
    public BranchManager authenticate(String username, String password) {
        // REVERTED: Directly use findByUsernameAndPassword for plain-text authentication
        BranchManager manager = branchManagerRepository.findByUsernameAndPassword(username, password);

        if (manager != null) {
            // Update last login timestamp upon successful authentication
            manager.setLastLogin(LocalDateTime.now());
            branchManagerRepository.save(manager); // Save the updated manager object
            System.out.println("DEBUG: Manager '" + username + "' authenticated successfully.");
            return manager;
        } else {
            System.out.println("DEBUG: Authentication failed for manager '" + username + "'. Invalid credentials.");
            return null; // Authentication failed
        }
    }

    /**
     * Saves a BranchManager.
     * @param manager The BranchManager entity to save.
     * @return The saved BranchManager entity.
     */
    public BranchManager saveManager(BranchManager manager) {
        // When not hashing, ensure the password is set as plain text if creating/updating
        return branchManagerRepository.save(manager);
    }
}
