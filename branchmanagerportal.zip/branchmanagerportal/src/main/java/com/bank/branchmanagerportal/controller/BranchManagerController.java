package com.bank.branchmanagerportal.controller;

import com.bank.branchmanagerportal.entity.BranchManager;
import com.bank.branchmanagerportal.entity.BranchReportDTO; // Import the new DTO
import com.bank.branchmanagerportal.entity.BranchStaff;
import com.bank.branchmanagerportal.entity.Customer;
import com.bank.branchmanagerportal.entity.Issue;
import com.bank.branchmanagerportal.entity.LoanApplication;
import com.bank.branchmanagerportal.entity.LoanPayment;
import com.bank.branchmanagerportal.entity.LoanPaymentGroup;
import com.bank.branchmanagerportal.service.*;

import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.time.LocalDate;
import java.time.Month; // Import Month for iterating through TreeMap keys
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.text.DecimalFormat; // For consistent number formatting

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;

@Controller
public class BranchManagerController {

    @Autowired
    private BranchManagerService branchManagerService;

    @Autowired
    private CustomerService customerService;

    @Autowired
    private BranchStaffService branchStaffService;

    @Autowired
    private LoanApplicationService loanService;

    @Autowired
    private LoanPaymentService paymentService;

    @Autowired
    private ReportService reportService; // Autowire ReportService

    @Autowired
    private IssueService issueService;

    @GetMapping("/")
    public String showLoginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String loginManager(@RequestParam String username,
                               @RequestParam String password,
                               Model model,
                               HttpSession session) {
        BranchManager manager = branchManagerService.authenticate(username, password);

        if (manager != null) {
            session.setAttribute("loggedInManager", manager);
            // Fetch comprehensive report for dashboard
            BranchReportDTO report = reportService.generateBranchReport(manager.getBranchName());
            model.addAttribute("report", report); // Add report to model for dashboard
            model.addAttribute("manager", manager);
            return "manager-dashboard";
        } else {
            model.addAttribute("error", "Invalid username or password");
            return "login";
        }
    }

    @GetMapping("/dashboard")
    public String showDashboard(Model model, HttpSession session) {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) return "redirect:/";

        // Fetch comprehensive report for dashboard
        BranchReportDTO report = reportService.generateBranchReport(manager.getBranchName());
        model.addAttribute("report", report); // Add report to model for dashboard
        model.addAttribute("manager", manager);
        return "manager-dashboard";
    }

    @GetMapping("/add-customer")
    public String showAddCustomerForm(Model model, HttpSession session) {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) return "redirect:/";

        model.addAttribute("customer", new Customer());
        model.addAttribute("branchName", manager.getBranchName());
        return "add-customer";
    }

    @PostMapping("/add-customer")
    public String addCustomer(@ModelAttribute Customer customer, HttpSession session, Model model) {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) return "redirect:/";

        customer.setBranchName(manager.getBranchName());
        customerService.saveCustomer(customer);

        // When redirecting to dashboard, ensure report data is passed
        BranchReportDTO report = reportService.generateBranchReport(manager.getBranchName());
        model.addAttribute("report", report);
        model.addAttribute("manager", manager);
        model.addAttribute("message", "Customer added successfully!");
        return "manager-dashboard"; // Stay on dashboard after adding customer
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }

    @GetMapping("/staff")
    public String viewStaff(Model model, HttpSession session) {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) return "redirect:/";

        List<BranchStaff> staffList = branchStaffService.getStaffByBranch(manager.getBranchName());
        model.addAttribute("staffList", staffList);

        model.addAttribute("newStaff", new BranchStaff());
        model.addAttribute("branchName", manager.getBranchName());

        return "manage-staff";
    }

    @PostMapping("/staff/add")
    public String addStaff(@ModelAttribute BranchStaff newStaff, HttpSession session, RedirectAttributes redirectAttributes) {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) {
            redirectAttributes.addFlashAttribute("error", "Session expired. Please log in.");
            return "redirect:/";
        }

        newStaff.setBranchName(manager.getBranchName());
        BranchStaff addedStaff = branchStaffService.addStaff(newStaff); // Capture the returned staff object

        if (addedStaff != null) {
            redirectAttributes.addFlashAttribute("message", "Staff member added successfully! Their account details have been sent to " + addedStaff.getEmail() + ". Awaiting approval.");
        } else {
            redirectAttributes.addFlashAttribute("error", "Failed to add staff member. A teller with that username might already exist.");
        }
        return "redirect:/staff";
    }

    @PostMapping("/staff/approve/{id}")
    public String approveStaff(@PathVariable Long id, HttpSession session, RedirectAttributes redirectAttributes) {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) {
            redirectAttributes.addFlashAttribute("error", "Session expired. Please log in.");
            return "redirect:/";
        }

        boolean approved = branchStaffService.approveStaff(id, manager.getBranchName());
        if (approved) {
            redirectAttributes.addFlashAttribute("message", "Staff member approved successfully!");
        } else {
            redirectAttributes.addFlashAttribute("error", "Could not approve staff member. Check logs for details or if already active.");
        }
        return "redirect:/staff";
    }

    @PostMapping("/staff/reject/{id}")
    public String rejectStaff(@PathVariable Long id, HttpSession session, RedirectAttributes redirectAttributes) {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) {
            redirectAttributes.addFlashAttribute("error", "Session expired. Please log in.");
            return "redirect:/";
        }

        boolean rejected = branchStaffService.rejectStaff(id, manager.getBranchName());
        if (rejected) {
            redirectAttributes.addFlashAttribute("message", "Staff member rejected successfully!");
        } else {
            redirectAttributes.addFlashAttribute("error", "Could not reject staff member. Check logs for details.");
        }
        return "redirect:/staff";
    }

    @GetMapping("/staff/delete/{id}")
    public String deleteStaff(@PathVariable Long id, HttpSession session, RedirectAttributes redirectAttributes) {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) {
            redirectAttributes.addFlashAttribute("error", "Session expired. Please log in.");
            return "redirect:/";
        }

        boolean deleted = branchStaffService.deleteStaff(id, manager.getBranchName());
        if (deleted) {
            redirectAttributes.addFlashAttribute("message", "Staff member deleted successfully!");
        } else {
            redirectAttributes.addFlashAttribute("error", "Could not delete staff member. Check logs for details.");
        }
        return "redirect:/staff";
    }


    @GetMapping("/loan-applications")
    public String viewLoanApplications(Model model, HttpSession session) {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) return "redirect:/";

        List<LoanApplication> apps = loanService.getLoanApplications(manager.getBranchName());
        model.addAttribute("loanApps", apps);
        return "loan-applications";
    }

    @PostMapping("/loan-applications/approve/{id}")
    public String approveLoan(@PathVariable Long id) {
        loanService.approveLoan(id);
        return "redirect:/loan-applications";
    }

    @PostMapping("/loan-applications/reject/{id}")
    public String rejectLoan(@PathVariable Long id) {
        loanService.rejectLoan(id);
        return "redirect:/loan-applications";
    }

    @GetMapping("/loan-payments")
    public String viewLoanPayments(Model model, HttpSession session) {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) return "redirect:/";

        List<LoanPaymentGroup> grouped = paymentService.getGroupedPayments(manager.getBranchName());
        model.addAttribute("groupedPayments", grouped);
        return "loan-payments";
    }


    @GetMapping("/loan-payments/add")
    public String showAddPaymentForm(@RequestParam(name = "loanId", required = false) Long loanId,
                                     @RequestParam(name = "customerName", required = false) String customerName,
                                     Model model) {
        LoanPayment payment = new LoanPayment();
        if (loanId != null) {
            payment.setLoanId(loanId);
        }
        if (customerName != null) {
            payment.setCustomerName(customerName);
        }
        model.addAttribute("payment", payment);
        return "add-loan-payment";
    }

    @PostMapping("/loan-payments/add")
    public String addLoanPayment(@ModelAttribute LoanPayment payment, HttpSession session, RedirectAttributes redirectAttributes) {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) {
            redirectAttributes.addFlashAttribute("error", "Session expired. Please log in.");
            return "redirect:/";
        }

        payment.setBranchName(manager.getBranchName()); // Set branch name from logged-in manager

        String result = paymentService.recordPayment(payment);

        if (result.startsWith("Error:")) {
            redirectAttributes.addFlashAttribute("error", result);
        } else {
            redirectAttributes.addFlashAttribute("message", result);
        }
        return "redirect:/loan-payments"; // Redirect back to the payments list
    }

    @GetMapping("/report")
    public String showReport(Model model, HttpSession session) {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) {
            return "redirect:/login"; // or your login page
        }

        BranchReportDTO report = reportService.generateBranchReport(manager.getBranchName()); // Changed return type
        model.addAttribute("manager", manager);
        model.addAttribute("report", report); // Now passing BranchReportDTO
        return "branch-report"; // Returns "branch-report" to match your file name
    }


    @GetMapping("/report/pdf")
    public void downloadReportPdf(HttpServletResponse response, HttpSession session) throws Exception {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) {
            response.sendRedirect("/");
            return;
        }

        BranchReportDTO report = reportService.generateBranchReport(manager.getBranchName());

        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=branch_report.pdf");

        Document document = new Document();
        PdfWriter.getInstance(document, response.getOutputStream());
        document.open();

        // Fonts for styling
        Font titleFont = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD, BaseColor.DARK_GRAY);
        Font sectionTitleFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD, BaseColor.BLUE);
        Font subSectionTitleFont = new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD, BaseColor.GRAY);
        Font normalFont = new Font(Font.FontFamily.HELVETICA, 11, Font.NORMAL, BaseColor.BLACK);
        Font boldFont = new Font(Font.FontFamily.HELVETICA, 11, Font.BOLD, BaseColor.BLACK);

        // Number formatter for currency and percentages
        DecimalFormat currencyFormat = new DecimalFormat("₹#,##0.00");
        DecimalFormat percentageFormat = new DecimalFormat("#,##0.00'%'");

        // --- Report Header ---
        Paragraph header = new Paragraph("Branch Report - " + manager.getBranchName(), titleFont);
        header.setAlignment(Element.ALIGN_CENTER);
        document.add(header);
        document.add(new Paragraph("Generated on: " + LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("dd-MM-yyyy")), normalFont));
        document.add(Chunk.NEWLINE);

        // --- 1. Overall Summary ---
        document.add(new Paragraph("Overall Summary", sectionTitleFont));
        document.add(Chunk.NEWLINE);
        document.add(new Paragraph("Total Customers: " + report.getTotalCustomers(), normalFont));
        document.add(new Paragraph("Total Staff: " + report.getTotalStaff(), normalFont));
        document.add(new Paragraph("Total Loan Applications: " + report.getTotalLoanApplications(), normalFont));
        document.add(new Paragraph("Total Loans Issued: " + currencyFormat.format(report.getTotalLoansIssued()), normalFont));
        document.add(new Paragraph("Total Payments Made: " + currencyFormat.format(report.getTotalPaymentsMade()), normalFont));
        document.add(new Paragraph("Total Payments Count: " + report.getTotalPaymentsCount(), normalFont));
        document.add(new Paragraph("Total Issues: " + report.getTotalIssues(), normalFont));
        document.add(Chunk.NEWLINE);

        // --- 2. Performance Insights ---
        document.add(new Paragraph("Performance Insights", sectionTitleFont));
        document.add(Chunk.NEWLINE);
        document.add(new Paragraph("Average Loan Amount: " + currencyFormat.format(report.getAvgLoanAmount()), normalFont));
        document.add(new Paragraph("Average Payment Amount: " + currencyFormat.format(report.getAvgPaymentAmount()), normalFont));
        document.add(new Paragraph("Loan Coverage Ratio: " + percentageFormat.format(report.getLoanCoverageRatio()), normalFont));
        document.add(Chunk.NEWLINE);

        // --- 3. Loan Status Breakdown ---
        document.add(new Paragraph("Loan Status Breakdown", sectionTitleFont));
        document.add(Chunk.NEWLINE);
        document.add(new Paragraph("Approved Loans: " + report.getApprovedLoansCount(), normalFont));
        document.add(new Paragraph("Pending Loans: " + report.getPendingLoansCount(), normalFont));
        document.add(new Paragraph("Rejected Loans: " + report.getRejectedLoansCount(), normalFont));
        document.add(Chunk.NEWLINE);

        // --- 4. Staff Overview ---
        document.add(new Paragraph("Staff Overview", sectionTitleFont));
        document.add(Chunk.NEWLINE);
        if (report.getStaffCountsByRole() != null && !report.getStaffCountsByRole().isEmpty()) {
            report.getStaffCountsByRole().forEach((role, count) -> {
                try {
                    document.add(new Paragraph(role + ": " + count, normalFont));
                } catch (DocumentException e) {
                    e.printStackTrace();
                }
            });
        } else {
            document.add(new Paragraph("No staff role data available.", normalFont));
        }
        document.add(Chunk.NEWLINE);

        // --- 5. Issue Tracking ---
        document.add(new Paragraph("Issue Tracking", sectionTitleFont));
        document.add(Chunk.NEWLINE);
        document.add(new Paragraph("Resolved Issues: " + report.getResolvedIssues(), normalFont));
        document.add(new Paragraph("Pending Issues: " + report.getPendingIssues(), normalFont));
        document.add(Chunk.NEWLINE);

        // --- 6. Monthly Trends (Text-based summary) ---
        document.add(new Paragraph("Monthly Trends", sectionTitleFont));
        document.add(Chunk.NEWLINE);

        document.add(new Paragraph("Loan Applications per Month:", subSectionTitleFont));
        if (report.getMonthlyLoanApplications() != null && !report.getMonthlyLoanApplications().isEmpty()) {
            for (Map.Entry<Month, Long> entry : report.getMonthlyLoanApplications().entrySet()) {
                document.add(new Paragraph(entry.getKey().getDisplayName(java.time.format.TextStyle.SHORT, java.util.Locale.ENGLISH) + ": " + entry.getValue() + " applications", normalFont));
            }
        } else {
            document.add(new Paragraph("No monthly loan application data available.", normalFont));
        }
        document.add(Chunk.NEWLINE);

        document.add(new Paragraph("Loans Issued Amount per Month:", subSectionTitleFont));
        if (report.getMonthlyLoansIssuedAmount() != null && !report.getMonthlyLoansIssuedAmount().isEmpty()) {
            for (Map.Entry<Month, Double> entry : report.getMonthlyLoansIssuedAmount().entrySet()) {
                document.add(new Paragraph(entry.getKey().getDisplayName(java.time.format.TextStyle.SHORT, java.util.Locale.ENGLISH) + ": " + currencyFormat.format(entry.getValue()), normalFont));
            }
        } else {
            document.add(new Paragraph("No monthly loans issued amount data available.", normalFont));
        }
        document.add(Chunk.NEWLINE);

        document.add(new Paragraph("Payments Made Amount per Month:", subSectionTitleFont));
        if (report.getMonthlyPaymentsMadeAmount() != null && !report.getMonthlyPaymentsMadeAmount().isEmpty()) {
            for (Map.Entry<Month, Double> entry : report.getMonthlyPaymentsMadeAmount().entrySet()) {
                document.add(new Paragraph(entry.getKey().getDisplayName(java.time.format.TextStyle.SHORT, java.util.Locale.ENGLISH) + ": " + currencyFormat.format(entry.getValue()), normalFont));
            }
        } else {
            document.add(new Paragraph("No monthly payments made amount data available.", normalFont));
        }
        document.add(Chunk.NEWLINE);

        // --- 7. Daily/Recent Activity ---
        document.add(new Paragraph("Daily/Recent Activity", sectionTitleFont));
        document.add(Chunk.NEWLINE);
        document.add(new Paragraph("New Customers Today: " + report.getNewCustomersToday(), normalFont));
        document.add(new Paragraph("New Loan Applications Today: " + report.getNewLoanApplicationsToday(), normalFont));
        document.add(new Paragraph("Payments Received Today: " + currencyFormat.format(report.getPaymentsReceivedToday()), normalFont));
        document.add(new Paragraph("Staff Approved Today: " + report.getStaffApprovedToday(), normalFont));
        document.add(new Paragraph("Issues Raised Today: " + report.getIssuesRaisedToday(), normalFont));
        document.add(Chunk.NEWLINE);


        // --- Footer ---
        Paragraph footer = new Paragraph("© 2025 Mirchi Mitchells. All rights reserved.", new Font(Font.FontFamily.HELVETICA, 10, Font.ITALIC, BaseColor.GRAY));
        footer.setAlignment(Element.ALIGN_CENTER);
        document.add(footer);

        document.close();
    }

    @GetMapping("/raise-issue")
    public String showRaiseIssueForm(Model model, HttpSession session) {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) return "redirect:/";

        model.addAttribute("issue", new Issue());
        model.addAttribute("customers", customerService.getCustomersByBranch(manager.getBranchName()));
        return "raise-issue";
    }

    @PostMapping("/raise-issue")
    public String submitIssue(@ModelAttribute Issue issue, Model model, HttpSession session) {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) return "redirect:/";

        // Set current date and default status
        issue.setDateRaised(LocalDate.now());
        issue.setStatus("OPEN");

        // Save the issue
        issueService.raiseIssue(issue);

        // For alert popup, redirect with flash attribute or use JS alert on page
        return "redirect:/raise-issue?success=true";
    }
}
