// src/main/java/com/bank/branchmanagerportal/entity/LoanPaymentGroup.java
package com.bank.branchmanagerportal.entity;

import java.util.ArrayList;
import java.util.List;

public class LoanPaymentGroup {
    private Long loanId;
    private String customerName;
    private List<LoanPayment> payments;
    private double totalPaid;
    private double loanAmount; // The total amount of the loan from LoanApplication

    // Default constructor (important for Spring/Thymeleaf)
    public LoanPaymentGroup() {
        this.payments = new ArrayList<>(); // Initialize list to avoid NullPointerException
    }

    // Constructor to set initial values for grouping
    public LoanPaymentGroup(Long loanId, String customerName) {
        this.loanId = loanId;
        this.customerName = customerName;
        this.payments = new ArrayList<>(); // Initialize list
        this.totalPaid = 0.0;
        this.loanAmount = 0.0; // Will be set after fetching loan application details
    }

    // Getters and setters
    public Long getLoanId() {
        return loanId;
    }
    public void setLoanId(Long loanId) {
        this.loanId = loanId;
    }
    public String getCustomerName() {
        return customerName;
    }
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
    public List<LoanPayment> getPayments() {
        return payments;
    }
    public void setPayments(List<LoanPayment> payments) {
        this.payments = payments;
    }
    public double getTotalPaid() {
        return totalPaid;
    }
    public void setTotalPaid(double totalPaid) {
        this.totalPaid = totalPaid;
    }
    public double getLoanAmount() {
        return loanAmount;
    }
    public void setLoanAmount(double loanAmount) {
        this.loanAmount = loanAmount;
    }
}
