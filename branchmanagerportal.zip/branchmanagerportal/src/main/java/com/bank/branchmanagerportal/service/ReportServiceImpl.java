// src/main/java/com/bank/branchmanagerportal/service/ReportServiceImpl.java
package com.bank.branchmanagerportal.service;

import com.bank.branchmanagerportal.entity.*; // Import all entities needed
import com.bank.branchmanagerportal.repository.*; // Import all repositories needed
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.Month;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ReportServiceImpl implements ReportService {

    @Autowired
    private CustomerRepository customerRepo;
    @Autowired
    private LoanApplicationRepository loanRepo;
    @Autowired
    private LoanPaymentRepository paymentRepo;
    @Autowired
    private BranchStaffRepository branchStaffRepo;
    @Autowired
    private IssueRepository issueRepo;

    @Override
    public BranchReportDTO generateBranchReport(String branchName) {
        BranchReportDTO report = new BranchReportDTO();

        // Fetch Data for the specified branch
        List<Customer> customers = customerRepo.findByBranchName(branchName);
        List<LoanApplication> loanApps = loanRepo.findByBranchName(branchName);
        List<LoanPayment> payments = paymentRepo.findByBranchName(branchName);
        List<BranchStaff> staff = branchStaffRepo.findByBranchName(branchName);
        List<Issue> issues = issueRepo.findByBranchName(branchName);

        // --- 1. Summary Metrics ---
        report.setTotalCustomers(customers.size());
        report.setTotalLoanApplications(loanApps.size());

        // Filter out loan applications with null amounts before summing
        double totalLoansIssued = loanApps.stream()
                                          .filter(la -> la.getAmount() != 0) // Ensure amount is not zero or null-equivalent
                                          .mapToDouble(LoanApplication::getAmount)
                                          .sum();
        report.setTotalLoansIssued(totalLoansIssued);

        // Filter out payments with null amounts before summing
        double totalPaymentsMade = payments.stream()
                                           .filter(lp -> lp.getAmountPaid() != 0) // Ensure amountPaid is not zero or null-equivalent
                                           .mapToDouble(LoanPayment::getAmountPaid)
                                           .sum();
        report.setTotalPaymentsMade(totalPaymentsMade);
        report.setTotalPaymentsCount(payments.size());

        // --- 2. Loan Status Breakdown ---
        long approved = loanApps.stream().filter(l -> "APPROVED".equalsIgnoreCase(l.getStatus())).count();
        long pending = loanApps.stream().filter(l -> "PENDING".equalsIgnoreCase(l.getStatus())).count();
        long rejected = loanApps.stream().filter(l -> "REJECTED".equalsIgnoreCase(l.getStatus())).count();

        report.setApprovedLoansCount((int) approved);
        report.setPendingLoansCount((int) pending);
        report.setRejectedLoansCount((int) rejected);

        // --- 3. Performance Insights ---
        // Ensure division by zero is handled, and filter out applications with zero amount
        double avgLoan = loanApps.stream().filter(la -> la.getAmount() > 0).mapToDouble(LoanApplication::getAmount).average().orElse(0.0);
        report.setAvgLoanAmount(avgLoan);

        // Ensure division by zero is handled, and filter out payments with zero amount
        double avgPayment = payments.stream().filter(lp -> lp.getAmountPaid() > 0).mapToDouble(LoanPayment::getAmountPaid).average().orElse(0.0);
        report.setAvgPaymentAmount(avgPayment);

        double loanCoverageRatio = (totalLoansIssued == 0) ? 0 : (totalPaymentsMade / totalLoansIssued) * 100;
        report.setLoanCoverageRatio(loanCoverageRatio);

        // --- 4. Staff Metrics ---
        report.setTotalStaff(staff.size());
        Map<String, Long> staffCountsByRole = staff.stream()
            .collect(Collectors.groupingBy(BranchStaff::getRole, Collectors.counting()));
        report.setStaffCountsByRole(staffCountsByRole);

        // --- 5. Issue Tracking ---
        report.setTotalIssues(issues.size());
        report.setResolvedIssues((int) issues.stream().filter(i -> "RESOLVED".equalsIgnoreCase(i.getStatus())).count());
        report.setPendingIssues((int) issues.stream()
            .filter(i -> "OPEN".equalsIgnoreCase(i.getStatus()) || "IN_PROGRESS".equalsIgnoreCase(i.getStatus()))
            .count());

        // --- 6. Trend Data (Monthly Aggregations) ---
        // Filter out LoanApplication objects with null applicationDate before grouping
        Map<String, Long> monthlyLoanApplications = loanApps.stream()
            .filter(la -> la.getApplicationDate() != null) // IMPORTANT: Filter out null dates here
            .collect(Collectors.groupingBy(
                la -> la.getApplicationDate().getMonth().name(),
                () -> new LinkedHashMap<>(12),
                Collectors.counting()
            ));
        report.setMonthlyLoanApplications(fillMissingMonths(monthlyLoanApplications, 0L));

        // Filter out LoanApplication objects with null applicationDate before grouping
        Map<String, Double> monthlyLoansIssuedAmount = loanApps.stream()
            .filter(la -> la.getApplicationDate() != null) // IMPORTANT: Filter out null dates here
            .collect(Collectors.groupingBy(
                la -> la.getApplicationDate().getMonth().name(),
                () -> new LinkedHashMap<>(12),
                Collectors.summingDouble(LoanApplication::getAmount)
            ));
        report.setMonthlyLoansIssuedAmount(fillMissingMonthsDouble(monthlyLoansIssuedAmount, 0.0));

        // Filter out LoanPayment objects with null paymentDate before grouping
        Map<String, Double> monthlyPaymentsMadeAmount = payments.stream()
            .filter(lp -> lp.getPaymentDate() != null) // IMPORTANT: Filter out null dates here
            .collect(Collectors.groupingBy(
                lp -> lp.getPaymentDate().getMonth().name(),
                () -> new LinkedHashMap<>(12),
                Collectors.summingDouble(LoanPayment::getAmountPaid)
            ));
        report.setMonthlyPaymentsMadeAmount(fillMissingMonthsDouble(monthlyPaymentsMadeAmount, 0.0));


        return report;
    }

    // Helper method to ensure all months are present in monthly data, filling missing ones with default value
    private <T> Map<String, T> fillMissingMonths(Map<String, T> data, T defaultValue) {
        Map<String, T> orderedData = new LinkedHashMap<>();
        Arrays.stream(Month.values()).forEach(month -> {
            String monthName = month.name();
            orderedData.put(monthName, data.getOrDefault(monthName, defaultValue));
        });
        return orderedData;
    }

    private Map<String, Double> fillMissingMonthsDouble(Map<String, Double> data, Double defaultValue) {
        Map<String, Double> orderedData = new LinkedHashMap<>();
        Arrays.stream(Month.values()).forEach(month -> {
            String monthName = month.name();
            orderedData.put(monthName, data.getOrDefault(monthName, defaultValue));
        });
        return orderedData;
    }
}
