package com.bank.branchmanagerportal.service;

import com.bank.branchmanagerportal.entity.*; // Import all entities needed
import com.bank.branchmanagerportal.repository.*; // Import all repositories needed
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.Month;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap; // Keep order of months
import java.util.List;
import java.util.Map;
import java.util.TreeMap; // For BranchReportDTO's TreeMap for months
import java.util.HashMap; // NEW: Added import for HashMap
import java.util.stream.Collectors;

@Service
public class ReportServiceImpl implements ReportService {

    @Autowired
    private CustomerRepository customerRepo;
    @Autowired
    private LoanApplicationRepository loanRepo;
    @Autowired
    private LoanPaymentRepository paymentRepo;
    @Autowired
    private BranchStaffRepository branchStaffRepo;
    @Autowired
    private IssueRepository issueRepo;

    @Override
    public BranchReportDTO generateBranchReport(String branchName) {
        BranchReportDTO report = new BranchReportDTO();
        LocalDate today = LocalDate.now(); // Get today's date

        // --- 1. Overall Summary Metrics ---
        // Using new countByBranchName methods for direct counting
        report.setTotalCustomers((int) customerRepo.countByBranchName(branchName));
        report.setTotalLoanApplications((int) loanRepo.countByBranchName(branchName));

        // Use repository methods for sums
        report.setTotalLoansIssued(loanRepo.sumTotalApprovedAmountByBranchName(branchName));
        report.setTotalPaymentsMade(paymentRepo.sumTotalAmountPaidByBranchName(branchName));
        report.setTotalPaymentsCount((int) paymentRepo.countByBranchName(branchName));

        report.setTotalStaff((int) branchStaffRepo.countByBranchName(branchName));
        report.setTotalIssues((int) issueRepo.countByBranchName(branchName));
        report.setResolvedIssues((int) issueRepo.countByBranchNameAndStatus(branchName, "RESOLVED"));
        report.setPendingIssues((int) issueRepo.countByBranchNameAndStatus(branchName, "OPEN")); // Assuming "OPEN" is pending

        // Staff Counts by Role (using existing logic)
        Map<String, Long> staffRoleCounts = new HashMap<>();
        branchStaffRepo.countStaffByRole(branchName).forEach(
            result -> staffRoleCounts.put((String) result[0], (Long) result[1])
        );
        report.setStaffCountsByRole(staffRoleCounts);

        // --- 2. Loan Status Breakdown (Directly from DTO and countByBranchNameAndStatus) ---
        report.setApprovedLoansCount((int) loanRepo.countByBranchNameAndStatus(branchName, "APPROVED"));
        report.setPendingLoansCount((int) loanRepo.countByBranchNameAndStatus(branchName, "PENDING"));
        report.setRejectedLoansCount((int) loanRepo.countByBranchNameAndStatus(branchName, "REJECTED"));

        // --- 3. Performance Insights ---
        // To calculate average loan amount, we need total amount of all loans (approved, pending, rejected)
        // and total count of all loans.
        double totalAmountOfAllLoans = loanRepo.findByBranchName(branchName).stream() // Use findByBranchName instead of findAll().stream().filter()
                                                .mapToDouble(LoanApplication::getAmount)
                                                .sum();
        if (report.getTotalLoanApplications() > 0) {
            report.setAvgLoanAmount(totalAmountOfAllLoans / report.getTotalLoanApplications());
        } else {
            report.setAvgLoanAmount(0.0);
        }

        if (report.getTotalPaymentsCount() > 0) {
            report.setAvgPaymentAmount(report.getTotalPaymentsMade() / report.getTotalPaymentsCount());
        } else {
            report.setAvgPaymentAmount(0.0);
        }

        double loanCoverageRatio = (report.getTotalLoansIssued() == 0) ? 0 : (report.getTotalPaymentsMade() / report.getTotalLoansIssued()) * 100;
        report.setLoanCoverageRatio(loanCoverageRatio);

        // --- 4. Trend Data (Monthly Aggregations) ---
        // Initialize all months to 0 for consistent chart display
        // Use TreeMap directly as BranchReportDTO now holds TreeMap<Month, ...>
        TreeMap<Month, Long> monthlyLoanApplicationsMap = new TreeMap<>();
        TreeMap<Month, Double> monthlyLoansIssuedAmountMap = new TreeMap<>();
        TreeMap<Month, Double> monthlyPaymentsMadeAmountMap = new TreeMap<>();

        Arrays.stream(Month.values()).forEach(month -> {
            monthlyLoanApplicationsMap.put(month, 0L);
            monthlyLoansIssuedAmountMap.put(month, 0.0);
            monthlyPaymentsMadeAmountMap.put(month, 0.0);
        });

        loanRepo.countApplicationsByMonth(branchName).forEach(result -> {
            Month month = Month.of(((Number) result[0]).intValue());
            Long count = (Long) result[1];
            monthlyLoanApplicationsMap.put(month, count);
        });
        report.setMonthlyLoanApplications(monthlyLoanApplicationsMap);

        loanRepo.sumApprovedAmountByMonth(branchName).forEach(result -> {
            Month month = Month.of(((Number) result[0]).intValue());
            Double amount = (Double) result[1];
            monthlyLoansIssuedAmountMap.put(month, amount);
        });
        report.setMonthlyLoansIssuedAmount(monthlyLoansIssuedAmountMap);


        paymentRepo.sumAmountPaidByMonth(branchName).forEach(result -> {
            Month month = Month.of(((Number) result[0]).intValue());
            Double amount = (Double) result[1];
            monthlyPaymentsMadeAmountMap.put(month, amount);
        });
        report.setMonthlyPaymentsMadeAmount(monthlyPaymentsMadeAmountMap);


        // --- 5. Daily/Recent Activity ---
        report.setNewCustomersToday((int) customerRepo.countByBranchNameAndRegistrationDate(branchName, today));
        report.setNewLoanApplicationsToday((int) loanRepo.countByBranchNameAndApplicationDate(branchName, today));
        report.setPaymentsReceivedToday(paymentRepo.sumAmountPaidByBranchNameAndPaymentDate(branchName, today));
        report.setStaffApprovedToday((int) branchStaffRepo.countApprovedStaffByBranchNameAndLastLoginDate(branchName, today));
        report.setIssuesRaisedToday((int) issueRepo.countByBranchNameAndDateRaised(branchName, today));

        return report;
    }
}
