package com.bank.branchmanagerportal.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service // Marks this class as a Spring service component
public class EmailService {

    @Autowired // Injects the JavaMailSender bean configured by Spring Boot
    private JavaMailSender mailSender;

    /**
     * Sends a simple email to a recipient with a specified subject and body.
     * This method is marked as public so it can be called from other services
     * (e.g., BranchStaffService after creating a new teller).
     *
     * @param to The email address of the recipient.
     * @param subject The subject line of the email.
     * @param body The main content of the email.
     */
    public void sendEmail(String to, String subject, String body) {
        // Create a new SimpleMailMessage object
        SimpleMailMessage message = new SimpleMailMessage();

        // Set the recipient, subject, and body of the email
        message.setTo(to);
        message.setSubject(subject);
        message.setText(body);

        try {
            // Send the email using the JavaMailSender
            mailSender.send(message);
            System.out.println("Email sent successfully to: " + to);
        } catch (MailException e) {
            // Log any exceptions that occur during email sending
            System.err.println("Error sending email to " + to + ": " + e.getMessage());
            // In a real application, you might want to throw a custom exception
            // or handle this error more gracefully (e.g., retry mechanism, notify admin).
        }
    }
}
