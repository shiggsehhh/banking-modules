// src/main/java/com/bank/branchmanagerportal/entity/BranchReportDTO.java
package com.bank.branchmanagerportal.entity;

import java.util.List;
import java.util.Map;

public class BranchReportDTO {
    // Summary
    private int totalCustomers;
    private int totalLoanApplications;
    private double totalLoansIssued; // Renamed from totalLoans for clarity
    private double totalPaymentsMade; // Renamed from totalPayments for clarity
    private int totalPaymentsCount;

    // Loan Status Breakdown
    private int approvedLoansCount; // Renamed from approvedLoans
    private int pendingLoansCount;  // Renamed from pendingLoans
    private int rejectedLoansCount; // Renamed from rejectedLoans

    // Performance Insights
    private double avgLoanAmount;
    private double avgPaymentAmount;
    private double loanCoverageRatio;

    // Staff Metrics
    private int totalStaff;
    private Map<String, Long> staffCountsByRole; // e.g., {"TELLER": 5, "LOAN_OFFICER": 2}

    // Issue Tracking
    private int totalIssues;
    private int resolvedIssues;
    private int pendingIssues; // Open or In Progress issues

    // Trend Data for Charts
    // Map<MonthName, Count> or Map<MonthName, Amount>
    private Map<String, Long> monthlyLoanApplications; // Count of applications per month
    private Map<String, Double> monthlyLoansIssuedAmount; // Total amount of loans issued per month
    private Map<String, Double> monthlyPaymentsMadeAmount; // Total amount of payments made per month


    // --- Getters and Setters for all fields ---

    public int getTotalCustomers() { return totalCustomers; }
    public void setTotalCustomers(int totalCustomers) { this.totalCustomers = totalCustomers; }

    public int getTotalLoanApplications() { return totalLoanApplications; }
    public void setTotalLoanApplications(int totalLoanApplications) { this.totalLoanApplications = totalLoanApplications; }

    public double getTotalLoansIssued() { return totalLoansIssued; }
    public void setTotalLoansIssued(double totalLoansIssued) { this.totalLoansIssued = totalLoansIssued; }

    public double getTotalPaymentsMade() { return totalPaymentsMade; }
    public void setTotalPaymentsMade(double totalPaymentsMade) { this.totalPaymentsMade = totalPaymentsMade; }

    public int getTotalPaymentsCount() { return totalPaymentsCount; }
    public void setTotalPaymentsCount(int totalPaymentsCount) { this.totalPaymentsCount = totalPaymentsCount; }

    public int getApprovedLoansCount() { return approvedLoansCount; }
    public void setApprovedLoansCount(int approvedLoansCount) { this.approvedLoansCount = approvedLoansCount; }

    public int getPendingLoansCount() { return pendingLoansCount; }
    public void setPendingLoansCount(int pendingLoansCount) { this.pendingLoansCount = pendingLoansCount; }

    public int getRejectedLoansCount() { return rejectedLoansCount; }
    public void setRejectedLoansCount(int rejectedLoansCount) { this.rejectedLoansCount = rejectedLoansCount; }

    public double getAvgLoanAmount() { return avgLoanAmount; }
    public void setAvgLoanAmount(double avgLoanAmount) { this.avgLoanAmount = avgLoanAmount; }

    public double getAvgPaymentAmount() { return avgPaymentAmount; }
    public void setAvgPaymentAmount(double avgPaymentAmount) { this.avgPaymentAmount = avgPaymentAmount; }

    public double getLoanCoverageRatio() { return loanCoverageRatio; }
    public void setLoanCoverageRatio(double loanCoverageRatio) { this.loanCoverageRatio = loanCoverageRatio; }

    public int getTotalStaff() { return totalStaff; }
    public void setTotalStaff(int totalStaff) { this.totalStaff = totalStaff; }

    public Map<String, Long> getStaffCountsByRole() { return staffCountsByRole; }
    public void setStaffCountsByRole(Map<String, Long> staffCountsByRole) { this.staffCountsByRole = staffCountsByRole; }

    public int getTotalIssues() { return totalIssues; }
    public void setTotalIssues(int totalIssues) { this.totalIssues = totalIssues; }

    public int getResolvedIssues() { return resolvedIssues; }
    public void setResolvedIssues(int resolvedIssues) { this.resolvedIssues = resolvedIssues; }

    public int getPendingIssues() { return pendingIssues; }
    public void setPendingIssues(int pendingIssues) { this.pendingIssues = pendingIssues; }

    public Map<String, Long> getMonthlyLoanApplications() { return monthlyLoanApplications; }
    public void setMonthlyLoanApplications(Map<String, Long> monthlyLoanApplications) { this.monthlyLoanApplications = monthlyLoanApplications; }

    public Map<String, Double> getMonthlyLoansIssuedAmount() { return monthlyLoansIssuedAmount; }
    public void setMonthlyLoansIssuedAmount(Map<String, Double> monthlyLoansIssuedAmount) { this.monthlyLoansIssuedAmount = monthlyLoansIssuedAmount; }

    public Map<String, Double> getMonthlyPaymentsMadeAmount() { return monthlyPaymentsMadeAmount; }
    public void setMonthlyPaymentsMadeAmount(Map<String, Double> monthlyPaymentsMadeAmount) { this.monthlyPaymentsMadeAmount = monthlyPaymentsMadeAmount; }
}
