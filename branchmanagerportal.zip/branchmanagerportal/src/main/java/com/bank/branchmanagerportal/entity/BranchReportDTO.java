package com.bank.branchmanagerportal.entity;

import java.time.Month;
import java.util.Map;
import java.util.TreeMap; // Use TreeMap to keep months ordered

// This DTO (Data Transfer Object) is used to consolidate
// various statistics for a branch report.
public class BranchReportDTO {

    // --- Overall Summary ---
    private int totalCustomers;
    private int totalLoanApplications;
    private double totalLoansIssued; // Sum of approved loan amounts
    private double totalPaymentsMade; // Sum of all payments received
    private int totalPaymentsCount;
    private int totalStaff;
    private Map<String, Long> staffCountsByRole; // Role -> Count
    private int totalIssues;
    private int resolvedIssues;
    private int pendingIssues;

    // NEW: Loan Status Breakdown counts
    private int approvedLoansCount;
    private int pendingLoansCount;
    private int rejectedLoansCount;

    // --- Performance Insights ---
    private double avgLoanAmount;
    private double avgPaymentAmount;
    private double loanCoverageRatio; // (Total Payments Made / Total Loans Issued) * 100

    // --- Monthly Trend Data (for detailed reports) ---
    // Using TreeMap to ensure consistent month order (e.g., JAN, FEB, MAR)
    private TreeMap<Month, Long> monthlyLoanApplications; // Month -> Count of applications
    private TreeMap<Month, Double> monthlyLoansIssuedAmount; // Month -> Sum of approved loan amounts
    private TreeMap<Month, Double> monthlyPaymentsMadeAmount; // Month -> Sum of payments received

    // --- NEW: Daily/Recent Activity (for dashboard quick glance) ---
    private int newCustomersToday;
    private int newLoanApplicationsToday;
    private double paymentsReceivedToday;
    private int staffApprovedToday; // Count of staff whose status became ACTIVE today
    private int issuesRaisedToday;

    // Constructors
    public BranchReportDTO() {
        this.staffCountsByRole = new TreeMap<>(); // Use TreeMap for consistent order if iterating
        this.monthlyLoanApplications = new TreeMap<>();
        this.monthlyLoansIssuedAmount = new TreeMap<>();
        this.monthlyPaymentsMadeAmount = new TreeMap<>();
    }

    // --- Getters and Setters for all fields ---

    // Overall Summary
    public int getTotalCustomers() { return totalCustomers; }
    public void setTotalCustomers(int totalCustomers) { this.totalCustomers = totalCustomers; }

    public int getTotalLoanApplications() { return totalLoanApplications; }
    public void setTotalLoanApplications(int totalLoanApplications) { this.totalLoanApplications = totalLoanApplications; }

    public double getTotalLoansIssued() { return totalLoansIssued; }
    public void setTotalLoansIssued(double totalLoansIssued) { this.totalLoansIssued = totalLoansIssued; }

    public double getTotalPaymentsMade() { return totalPaymentsMade; }
    public void setTotalPaymentsMade(double totalPaymentsMade) { this.totalPaymentsMade = totalPaymentsMade; }

    public int getTotalPaymentsCount() { return totalPaymentsCount; }
    public void setTotalPaymentsCount(int totalPaymentsCount) { this.totalPaymentsCount = totalPaymentsCount; }

    public int getTotalStaff() { return totalStaff; }
    public void setTotalStaff(int totalStaff) { this.totalStaff = totalStaff; }

    public Map<String, Long> getStaffCountsByRole() { return staffCountsByRole; }
    public void setStaffCountsByRole(Map<String, Long> staffCountsByRole) { this.staffCountsByRole = staffCountsByRole; }

    public int getTotalIssues() { return totalIssues; }
    public void setTotalIssues(int totalIssues) { this.totalIssues = totalIssues; }

    public int getResolvedIssues() { return resolvedIssues; }
    public void setResolvedIssues(int resolvedIssues) { this.resolvedIssues = resolvedIssues; }

    public int getPendingIssues() { return pendingIssues; }
    public void setPendingIssues(int pendingIssues) { this.pendingIssues = pendingIssues; }

    // NEW: Getters and Setters for loan counts
    public int getApprovedLoansCount() { return approvedLoansCount; }
    public void setApprovedLoansCount(int approvedLoansCount) { this.approvedLoansCount = approvedLoansCount; }

    public int getPendingLoansCount() { return pendingLoansCount; }
    public void setPendingLoansCount(int pendingLoansCount) { this.pendingLoansCount = pendingLoansCount; }

    public int getRejectedLoansCount() { return rejectedLoansCount; }
    public void setRejectedLoansCount(int rejectedLoansCount) { this.rejectedLoansCount = rejectedLoansCount; }


    // Performance Insights
    public double getAvgLoanAmount() { return avgLoanAmount; }
    public void setAvgLoanAmount(double avgLoanAmount) { this.avgLoanAmount = avgLoanAmount; }

    public double getAvgPaymentAmount() { return avgPaymentAmount; }
    public void setAvgPaymentAmount(double avgPaymentAmount) { this.avgPaymentAmount = avgPaymentAmount; }

    public double getLoanCoverageRatio() { return loanCoverageRatio; }
    public void setLoanCoverageRatio(double loanCoverageRatio) { this.loanCoverageRatio = loanCoverageRatio; }

    // Monthly Trend Data
    public TreeMap<Month, Long> getMonthlyLoanApplications() { return monthlyLoanApplications; }
    public void setMonthlyLoanApplications(TreeMap<Month, Long> monthlyLoanApplications) { this.monthlyLoanApplications = monthlyLoanApplications; }

    public TreeMap<Month, Double> getMonthlyLoansIssuedAmount() { return monthlyLoansIssuedAmount; }
    public void setMonthlyLoansIssuedAmount(TreeMap<Month, Double> monthlyLoansIssuedAmount) { this.monthlyLoansIssuedAmount = monthlyLoansIssuedAmount; }

    public TreeMap<Month, Double> getMonthlyPaymentsMadeAmount() { return monthlyPaymentsMadeAmount; }
    public void setMonthlyPaymentsMadeAmount(TreeMap<Month, Double> monthlyPaymentsMadeAmount) { this.monthlyPaymentsMadeAmount = monthlyPaymentsMadeAmount; }

    // NEW: Daily/Recent Activity
    public int getNewCustomersToday() { return newCustomersToday; }
    public void setNewCustomersToday(int newCustomersToday) { this.newCustomersToday = newCustomersToday; }

    public int getNewLoanApplicationsToday() { return newLoanApplicationsToday; }
    public void setNewLoanApplicationsToday(int newLoanApplicationsToday) { this.newLoanApplicationsToday = newLoanApplicationsToday; }

    public double getPaymentsReceivedToday() { return paymentsReceivedToday; }
    public void setPaymentsReceivedToday(double paymentsReceivedToday) { this.paymentsReceivedToday = paymentsReceivedToday; } // Corrected setter name

    public int getStaffApprovedToday() { return staffApprovedToday; }
    public void setStaffApprovedToday(int staffApprovedToday) { this.staffApprovedToday = staffApprovedToday; }

    public int getIssuesRaisedToday() { return issuesRaisedToday; }
    public void setIssuesRaisedToday(int issuesRaisedToday) { this.issuesRaisedToday = issuesRaisedToday; }
}
