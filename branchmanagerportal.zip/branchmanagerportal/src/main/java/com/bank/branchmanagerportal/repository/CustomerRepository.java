package com.bank.branchmanagerportal.repository;

import com.bank.branchmanagerportal.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
    List<Customer> findByBranchName(String branchName);

    long countByBranchName(String branchName);

    // Count customers added on a specific date for a given branch - ADDED IS NOT NULL
    @Query("SELECT COUNT(c) FROM Customer c WHERE c.branchName = :branchName AND FUNCTION('DATE', c.registrationDate) = :date AND c.registrationDate IS NOT NULL")
    long countByBranchNameAndRegistrationDate(@Param("branchName") String branchName, @Param("date") LocalDate date);
}
