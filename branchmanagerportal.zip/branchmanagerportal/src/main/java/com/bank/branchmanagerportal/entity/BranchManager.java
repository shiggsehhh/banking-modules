// src/main/java/com/bank/branchmanagerportal/entity/BranchManager.java
package com.bank.branchmanagerportal.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime; // Added for lastLogin timestamp

@Entity
public class BranchManager {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;
    private String password; // In a real app, this should be passwordHash and securely stored

    private String branchName;

    // New fields for additional details
    private String fullName; // e.g., "full_name"
    @Column(unique = true) // Email should be unique
    private String email;
    private String phone;
    private String address;

    @Column(name = "last_login") // Column to store the last login timestamp
    private LocalDateTime lastLogin;

    // Constructors
    public BranchManager() {}

    public BranchManager(String username, String password, String branchName,
                         String fullName, String email, String phone, String address) {
        this.username = username;
        this.password = password;
        this.branchName = branchName;
        this.fullName = fullName;
        this.email = email;
        this.phone = phone;
        this.address = address;
        // lastLogin will be set upon successful login
    }

    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getBranchName() { return branchName; }
    public void setBranchName(String branchName) { this.branchName = branchName; }

    // Getters and Setters for new fields
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public LocalDateTime getLastLogin() { return lastLogin; }
    public void setLastLogin(LocalDateTime lastLogin) { this.lastLogin = lastLogin; }
}
