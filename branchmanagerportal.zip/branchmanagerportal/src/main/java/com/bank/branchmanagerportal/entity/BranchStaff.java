// src/main/java/com/bank/branchmanagerportal/entity/BranchStaff.java
package com.bank.branchmanagerportal.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "branch_staff") // Maps to the 'branch_staff' table in the database
public class BranchStaff {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-generates ID
    private Long id;

    private String name; // Full name of the staff member
    private String role; // Role of the staff member (e.g., "TELLER")
    private String branchName; // The branch the staff member belongs to

    // Fields for authentication and contact details, and approval status
    @Column(unique = true, nullable = false) // Username should be unique for login
    private String username;

    @Column(nullable = false)
    private String password; // In a real app, this should be passwordHash and securely stored

    @Column(unique = true) // Email should ideally be unique
    private String email;

    private String phone;
    private String address;

    // Status for approval flow: PENDING_APPROVAL, ACTIVE, REJECTED
    // A new teller will be PENDING_APPROVAL by default
    private String status; // e.g., "PENDING_APPROVAL", "ACTIVE", "REJECTED"

    // Getters and setters for all fields
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getBranchName() { return branchName; }
    public void setBranchName(String branchName) { this.branchName = branchName; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
