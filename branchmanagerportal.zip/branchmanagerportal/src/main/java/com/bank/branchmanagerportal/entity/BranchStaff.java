package com.bank.branchmanagerportal.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime; // Use LocalDateTime for lastLogin, as it often includes time

@Entity
@Table(name = "branch_staff") // Ensure your table name is 'branch_staff'
public class BranchStaff {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String username;
    private String password; // Store as plain text for now, but in real app, hash this!
    private String email;
    private String phone;
    private String address;
    private String role; // e.g., "TELLER", "LOAN_OFFICER"
    private String branchName;
    private String status; // e.g., "PENDING_APPROVAL", "ACTIVE", "REJECTED"

    // NEW: Add this field for last login timestamp or approval timestamp
    private LocalDateTime lastLogin; // Or use LocalDate if you only care about the date

    // Constructors
    public BranchStaff() {}

    public BranchStaff(String name, String username, String password, String email, String phone, String address, String role, String branchName, String status, LocalDateTime lastLogin) {
        this.name = name;
        this.username = username;
        this.password = password;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.role = role;
        this.branchName = branchName;
        this.status = status;
        this.lastLogin = lastLogin;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getBranchName() { return branchName; }
    public void setBranchName(String branchName) { this.branchName = branchName; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    // NEW: Getter and Setter for lastLogin
    public LocalDateTime getLastLogin() { return lastLogin; }
    public void setLastLogin(LocalDateTime lastLogin) { this.lastLogin = lastLogin; }
}
