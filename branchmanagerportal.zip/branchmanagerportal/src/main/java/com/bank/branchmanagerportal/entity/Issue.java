// src/main/java/com/bank/branchmanagerportal/entity/Issue.java
package com.bank.branchmanagerportal.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "issues") // Assuming your table is named 'issues'
public class Issue {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String subject;
    private String description;
    private String status; // e.g., OPEN, IN_PROGRESS, RESOLVED
    private LocalDate dateRaised;
    private String branchName; // The branch where the issue was raised

    // Added customerId to link issues to customers
    @Column(nullable = false) // Assuming an issue must always be linked to a customer
    private Long customerId;

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDate getDateRaised() {
        return dateRaised;
    }

    public void setDateRaised(LocalDate dateRaised) {
        this.dateRaised = dateRaised;
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }
}
