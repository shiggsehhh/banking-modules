// src/main/java/com/bank/branchmanagerportal/repository/IssueRepository.java
package com.bank.branchmanagerportal.repository;

import com.bank.branchmanagerportal.entity.Issue;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface IssueRepository extends JpaRepository<Issue, Long> {
    List<Issue> findByBranchName(String branchName);

    // New method to find issues by customer ID
    List<Issue> findByCustomerId(Long customerId);
}
