package com.bank.branchmanagerportal.repository;

import com.bank.branchmanagerportal.entity.Issue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface IssueRepository extends JpaRepository<Issue, Long> {
    List<Issue> findByBranchName(String branchName);
    List<Issue> findByCustomerId(Long customerId);

    long countByBranchName(String branchName);
    long countByBranchNameAndStatus(String branchName, String status);

    // Count issues raised on a specific date for a branch - ADDED IS NOT NULL
    @Query("SELECT COUNT(i) FROM Issue i WHERE i.branchName = :branchName AND FUNCTION('DATE', i.dateRaised) = :date AND i.dateRaised IS NOT NULL")
    long countByBranchNameAndDateRaised(@Param("branchName") String branchName, @Param("date") LocalDate date);
}
