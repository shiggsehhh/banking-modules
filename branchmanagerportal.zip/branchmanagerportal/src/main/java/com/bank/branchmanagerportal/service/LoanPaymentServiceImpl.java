// src/main/java/com/bank/branchmanagerportal/service/LoanPaymentServiceImpl.java
package com.bank.branchmanagerportal.service;

import com.bank.branchmanagerportal.entity.LoanApplication;
import com.bank.branchmanagerportal.entity.LoanPayment;
import com.bank.branchmanagerportal.entity.LoanPaymentGroup;
import com.bank.branchmanagerportal.repository.LoanApplicationRepository;
import com.bank.branchmanagerportal.repository.LoanPaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class LoanPaymentServiceImpl implements LoanPaymentService {

    @Autowired
    private LoanPaymentRepository paymentRepo;

    @Autowired
    private LoanApplicationRepository loanApplicationRepository; // Autowire LoanApplicationRepository

    @Override
    public List<LoanPayment> getPaymentsByBranch(String branchName) {
        return paymentRepo.findByBranchName(branchName);
    }

    /**
     * Records a new loan payment.
     * Implements a business rule: A loan cannot be overpaid.
     * @param newPayment The LoanPayment entity to be recorded.
     * @return A message indicating success or the reason for failure.
     */
    @Override
    public String recordPayment(LoanPayment newPayment) {
        // Set payment date and time
        newPayment.setPaymentDate(LocalDate.now());
        newPayment.setPaymentDateTime(LocalDateTime.now());

        // 1. Get the target LoanApplication to check its total amount
        Optional<LoanApplication> loanAppOptional = loanApplicationRepository.findById(newPayment.getLoanId());

        if (loanAppOptional.isEmpty()) {
            System.out.println("ERROR: LoanApplication with ID " + newPayment.getLoanId() + " not found. Cannot record payment.");
            return "Error: Loan not found for ID " + newPayment.getLoanId() + ".";
        }

        LoanApplication loanApp = loanAppOptional.get();
        double loanTotalAmount = loanApp.getAmount();

        // 2. Calculate current total payments made for this loan
        List<LoanPayment> existingPayments = paymentRepo.findByLoanId(newPayment.getLoanId());
        double currentTotalPaid = existingPayments.stream()
                                                  .mapToDouble(LoanPayment::getAmountPaid)
                                                  .sum();

        // 3. Check if the loan is already fully paid before accepting any new payment
        if (currentTotalPaid >= loanTotalAmount) {
            System.out.println("WARN: Loan " + newPayment.getLoanId() + " is already fully paid. Cannot accept more payments.");
            return "Error: Loan is already fully paid. Cannot accept more payments.";
        }

        double amountAfterNewPayment = currentTotalPaid + newPayment.getAmountPaid();

        // 4. Check if the new payment itself would cause an overpayment
        if (amountAfterNewPayment > loanTotalAmount) {
            double remainingBalance = loanTotalAmount - currentTotalPaid;
            System.out.println("WARN: New payment of " + newPayment.getAmountPaid() + " would overpay Loan " + newPayment.getLoanId() + ". Remaining: " + remainingBalance);
            return "Error: Payment amount (₹" + String.format("%.2f", newPayment.getAmountPaid()) + ") exceeds remaining balance (₹" + String.format("%.2f", remainingBalance) + ").";
        }

        // If validation passes, save the payment
        paymentRepo.save(newPayment);
        return "Payment recorded successfully!";
    }

    @Override
    public List<LoanPaymentGroup> getGroupedPayments(String branchName) {
        List<LoanPayment> allPayments = paymentRepo.findByBranchName(branchName);
        Map<Long, LoanPaymentGroup> groupedMap = new LinkedHashMap<>();

        // Group payments by loanId and initialize group objects
        for (LoanPayment p : allPayments) {
            groupedMap.computeIfAbsent(p.getLoanId(), k -> new LoanPaymentGroup(p.getLoanId(), p.getCustomerName()))
                      .getPayments().add(p);
        }

        // Post-process to calculate totalPaid and fetch loanAmount for each group
        for (LoanPaymentGroup group : groupedMap.values()) {
            double totalPaid = group.getPayments().stream()
                                    .mapToDouble(LoanPayment::getAmountPaid)
                                    .sum();
            group.setTotalPaid(totalPaid);

            // Fetch loan amount from LoanApplication
            loanApplicationRepository.findById(group.getLoanId())
                .ifPresent(app -> group.setLoanAmount(app.getAmount()));
        }

        // Sort by loan ID for consistent display
        return groupedMap.values().stream()
                .sorted(Comparator.comparing(LoanPaymentGroup::getLoanId))
                .collect(Collectors.toList());
    }
}
