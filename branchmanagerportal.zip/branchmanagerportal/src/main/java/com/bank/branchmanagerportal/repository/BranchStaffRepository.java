package com.bank.branchmanagerportal.repository;

import com.bank.branchmanagerportal.entity.BranchStaff;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public interface BranchStaffRepository extends JpaRepository<BranchStaff, Long> {
    BranchStaff findByUsername(String username);
    List<BranchStaff> findByBranchName(String branchName);
    List<BranchStaff> findByBranchNameAndStatus(String branchName, String status);

    long countByBranchName(String branchName);

    // This is the query causing the error. Ensure it's accurate and matches the entity field. - ADDED IS NOT NULL
    @Query("SELECT COUNT(bs) FROM BranchStaff bs WHERE bs.branchName = :branchName AND bs.status = 'ACTIVE' AND FUNCTION('DATE', bs.lastLogin) = :date AND bs.lastLogin IS NOT NULL")
    long countApprovedStaffByBranchNameAndLastLoginDate(@Param("branchName") String branchName, @Param("date") LocalDate date);

    // Count staff by role for a specific branch
    @Query("SELECT bs.role, COUNT(bs) FROM BranchStaff bs WHERE bs.branchName = :branchName GROUP BY bs.role")
    List<Object[]> countStaffByRole(@Param("branchName") String branchName);
}
