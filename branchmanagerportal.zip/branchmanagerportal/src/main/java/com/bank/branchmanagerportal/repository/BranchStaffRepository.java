// src/main/java/com/bank/branchmanagerportal/repository/BranchStaffRepository.java
package com.bank.branchmanagerportal.repository;

import com.bank.branchmanagerportal.entity.BranchStaff;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface BranchStaffRepository extends JpaRepository<BranchStaff, Long> {
    // Custom query method to find staff members by their branch name (already existed)
    List<BranchStaff> findByBranchName(String branchName);

    // New custom query method to find staff members by branch name AND status
    List<BranchStaff> findByBranchNameAndStatus(String branchName, String status);

    // New custom query method to find staff members by username (for login/authentication)
    BranchStaff findByUsername(String username);
}
