package com.bank.branchmanagerportal.repository;

import com.bank.branchmanagerportal.entity.LoanPayment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface LoanPaymentRepository extends JpaRepository<LoanPayment, Long> {
    List<LoanPayment> findByBranchNameOrderByLoanIdAscPaymentDateAsc(String branchName);

    List<LoanPayment> findByBranchName(String branchName);

    List<LoanPayment> findByLoanId(Long loanId);

    // Sum payments received on a specific date for a branch - ADDED IS NOT NULL
    @Query("SELECT COALESCE(SUM(lp.amountPaid), 0.0) FROM LoanPayment lp WHERE lp.branchName = :branchName AND FUNCTION('DATE', lp.paymentDate) = :date AND lp.paymentDate IS NOT NULL")
    double sumAmountPaidByBranchNameAndPaymentDate(@Param("branchName") String branchName, @Param("date") LocalDate date);

    long countByBranchName(String branchName);

    // Sum payments by month for a specific branch - ADDED IS NOT NULL
    @Query("SELECT FUNCTION('MONTH', lp.paymentDate) AS month, COALESCE(SUM(lp.amountPaid), 0.0) FROM LoanPayment lp WHERE lp.branchName = :branchName AND lp.paymentDate IS NOT NULL GROUP BY FUNCTION('MONTH', lp.paymentDate) ORDER BY month")
    List<Object[]> sumAmountPaidByMonth(@Param("branchName") String branchName);

    // Total sum of all payments made for a given branch
    @Query("SELECT COALESCE(SUM(lp.amountPaid), 0.0) FROM LoanPayment lp WHERE lp.branchName = :branchName")
    double sumTotalAmountPaidByBranchName(@Param("branchName") String branchName);
}
