// src/main/java/com/bank/branchmanagerportal/repository/LoanPaymentRepository.java
package com.bank.branchmanagerportal.repository;

import com.bank.branchmanagerportal.entity.LoanPayment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface LoanPaymentRepository extends JpaRepository<LoanPayment, Long> {
    List<LoanPayment> findByBranchName(String branchName);

    // New method: Find all payments associated with a specific loanId
    List<LoanPayment> findByLoanId(Long loanId);

    Optional<LoanPayment> findByLoanIdAndCustomerName(Long loanId, String customerName);
}
