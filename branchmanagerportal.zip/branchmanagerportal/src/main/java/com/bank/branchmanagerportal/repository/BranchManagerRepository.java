package com.bank.branchmanagerportal.repository;

import com.bank.branchmanagerportal.entity.BranchManager;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BranchManagerRepository extends JpaRepository<BranchManager, Long> {
    // REVERTED: Now directly find by username and password (plain text)
    BranchManager findByUsernameAndPassword(String username, String password);

    // REMOVED: findByUsername is not needed for direct plain-text auth
    // BranchManager findByUsername(String username);
}
