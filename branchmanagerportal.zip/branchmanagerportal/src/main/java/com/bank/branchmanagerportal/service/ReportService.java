package com.bank.branchmanagerportal.service;

import com.bank.branchmanagerportal.entity.BranchReportDTO;

// This interface defines the contract for our Report Service.
public interface ReportService {
    BranchReportDTO generateBranchReport(String branchName);
}
