// src/main/java/com/bank/branchmanagerportal/service/ReportService.java
package com.bank.branchmanagerportal.service;

import com.bank.branchmanagerportal.entity.BranchReportDTO; // Import the new DTO

public interface ReportService {
    BranchReportDTO generateBranchReport(String branchName); // Changed return type to BranchReportDTO
}
