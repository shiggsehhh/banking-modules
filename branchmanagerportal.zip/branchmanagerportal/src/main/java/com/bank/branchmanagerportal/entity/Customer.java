package com.bank.branchmanagerportal.entity;

import jakarta.persistence.*;
import java.time.LocalDate; // Make sure this import is present!

@Entity
@Table(name = "customer") // Ensure your table name is 'customer'
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String accountNumber;
    private String branchName;

    // This is the CRUCIAL field. Ensure it's here!
    private LocalDate registrationDate;

    // Constructors
    public Customer() {}

    public Customer(String name, String accountNumber, String branchName, LocalDate registrationDate) {
        this.name = name;
        this.accountNumber = accountNumber;
        this.branchName = branchName;
        this.registrationDate = registrationDate;
    }

    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getAccountNumber() { return accountNumber; }
    public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }

    public String getBranchName() { return branchName; }
    public void setBranchName(String branchName) { this.branchName = branchName; }

    // This is the CRUCIAL getter and setter. Ensure they are here!
    public LocalDate getRegistrationDate() { return registrationDate; }
    public void setRegistrationDate(LocalDate registrationDate) { this.registrationDate = registrationDate; }
}
