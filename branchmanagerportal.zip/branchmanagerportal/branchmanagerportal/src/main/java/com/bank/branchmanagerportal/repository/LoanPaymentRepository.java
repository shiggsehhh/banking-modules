package com.bank.branchmanagerportal.repository;

import com.bank.branchmanagerportal.entity.LoanPayment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface LoanPaymentRepository extends JpaRepository<LoanPayment, Long> {
    List<LoanPayment> findByBranchName(String branchName);
    Optional<LoanPayment> findByLoanIdAndCustomerName(Long loanId, String customerName);
}
