package com.bank.branchmanagerportal.service;

import com.bank.branchmanagerportal.entity.BranchStaff;
import com.bank.branchmanagerportal.repository.BranchStaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service // Marks this class as a Spring service component
public class BranchStaffService {

    @Autowired // Injects the BranchStaffRepository
    private BranchStaffRepository repository;

    /**
     * Retrieves a list of all staff members belonging to a specific branch.
     * @param branchName The name of the branch.
     * @return A list of BranchStaff entities.
     */
    public List<BranchStaff> getStaffByBranch(String branchName) {
        return repository.findByBranchName(branchName);
    }

    /**
     * Adds a new staff member to the database.
     * @param staff The BranchStaff entity to be saved.
     */
    public void addStaff(BranchStaff staff) {
        repository.save(staff);
    }

    /**
     * Deletes a staff member by their ID.
     * @param id The ID of the staff member to delete.
     */
    public void deleteStaff(Long id) {
        repository.deleteById(id);
    }
}
