package com.bank.branchmanagerportal.service;

import java.util.Map;

public interface ReportService {
    Map<String, Object> generateBranchReport(String branchName);
    
}
