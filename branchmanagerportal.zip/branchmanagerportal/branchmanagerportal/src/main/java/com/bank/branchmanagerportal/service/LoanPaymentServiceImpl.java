package com.bank.branchmanagerportal.service;

import com.bank.branchmanagerportal.entity.LoanPayment;
import com.bank.branchmanagerportal.entity.LoanPaymentGroup;
import com.bank.branchmanagerportal.repository.LoanApplicationRepository;
import com.bank.branchmanagerportal.repository.LoanPaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class LoanPaymentServiceImpl implements LoanPaymentService {

    @Autowired
    private LoanPaymentRepository paymentRepo;

    @Autowired
    private LoanApplicationRepository loanApplicationRepository;

    @Override
    public List<LoanPayment> getPaymentsByBranch(String branchName) {
        return paymentRepo.findByBranchName(branchName);
    }

    @Override
    public void recordPayment(LoanPayment newPayment) {
        newPayment.setPaymentDate(LocalDate.now());
        newPayment.setPaymentDateTime(LocalDateTime.now());
        paymentRepo.save(newPayment);
    }

    @Override
    public List<LoanPaymentGroup> getGroupedPayments(String branchName) {
        List<LoanPayment> allPayments = paymentRepo.findByBranchName(branchName);
        Map<String, LoanPaymentGroup> groupedMap = new LinkedHashMap<>();

        for (LoanPayment p : allPayments) {
            String key = p.getLoanId() + "-" + p.getCustomerName();
            groupedMap.putIfAbsent(key, new LoanPaymentGroup());
            LoanPaymentGroup group = groupedMap.get(key);

            if (group.getPayments() == null) group.setPayments(new ArrayList<>());
            group.getPayments().add(p);
            group.setLoanId(p.getLoanId());
            group.setCustomerName(p.getCustomerName());
            group.setTotalPaid(group.getTotalPaid() + p.getAmountPaid());

            // ✅ Fetch actual loan amount from LoanApplication
            loanApplicationRepository.findById(p.getLoanId())
                .ifPresent(app -> group.setLoanAmount(app.getAmount()));
        }

        return new ArrayList<>(groupedMap.values());
    }
}
