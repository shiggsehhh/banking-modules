package com.bank.branchmanagerportal.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "issues")
public class Issue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Link to customer who raised the issue
    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;

    private String subject;

    @Column(length = 1000)
    private String description;

    private LocalDate dateRaised;

    private String status;  // e.g. "OPEN", "RESOLVED"

    public Issue() {}

    // getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Customer getCustomer() { return customer; }
    public void setCustomer(Customer customer) { this.customer = customer; }

    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public LocalDate getDateRaised() { return dateRaised; }
    public void setDateRaised(LocalDate dateRaised) { this.dateRaised = dateRaised; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
