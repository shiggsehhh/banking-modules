package com.bank.branchmanagerportal.entity;

import java.util.List;

public class BranchReportDTO {
    private int totalCustomers;
    private int totalLoanApplications;
    private double totalLoans;
    private double totalPayments;
    private int totalPaymentsCount;

    private int approvedLoans;
    private int pendingLoans;
    private int rejectedLoans;

    private int totalIssues;
    private int resolvedIssues;
    private int pendingIssues;

    private double avgLoanAmount;
    private double avgPaymentAmount;
    private double loanCoverageRatio;

    private List<BranchStaff> staffList;

    // Getters and Setters
    public int getTotalCustomers() { return totalCustomers; }
    public void setTotalCustomers(int totalCustomers) { this.totalCustomers = totalCustomers; }

    public int getTotalLoanApplications() { return totalLoanApplications; }
    public void setTotalLoanApplications(int totalLoanApplications) { this.totalLoanApplications = totalLoanApplications; }

    public double getTotalLoans() { return totalLoans; }
    public void setTotalLoans(double totalLoans) { this.totalLoans = totalLoans; }

    public double getTotalPayments() { return totalPayments; }
    public void setTotalPayments(double totalPayments) { this.totalPayments = totalPayments; }

    public int getTotalPaymentsCount() { return totalPaymentsCount; }
    public void setTotalPaymentsCount(int totalPaymentsCount) { this.totalPaymentsCount = totalPaymentsCount; }

    public int getApprovedLoans() { return approvedLoans; }
    public void setApprovedLoans(int approvedLoans) { this.approvedLoans = approvedLoans; }

    public int getPendingLoans() { return pendingLoans; }
    public void setPendingLoans(int pendingLoans) { this.pendingLoans = pendingLoans; }

    public int getRejectedLoans() { return rejectedLoans; }
    public void setRejectedLoans(int rejectedLoans) { this.rejectedLoans = rejectedLoans; }

    public int getTotalIssues() { return totalIssues; }
    public void setTotalIssues(int totalIssues) { this.totalIssues = totalIssues; }

    public int getResolvedIssues() { return resolvedIssues; }
    public void setResolvedIssues(int resolvedIssues) { this.resolvedIssues = resolvedIssues; }

    public int getPendingIssues() { return pendingIssues; }
    public void setPendingIssues(int pendingIssues) { this.pendingIssues = pendingIssues; }

    public double getAvgLoanAmount() { return avgLoanAmount; }
    public void setAvgLoanAmount(double avgLoanAmount) { this.avgLoanAmount = avgLoanAmount; }

    public double getAvgPaymentAmount() { return avgPaymentAmount; }
    public void setAvgPaymentAmount(double avgPaymentAmount) { this.avgPaymentAmount = avgPaymentAmount; }

    public double getLoanCoverageRatio() { return loanCoverageRatio; }
    public void setLoanCoverageRatio(double loanCoverageRatio) { this.loanCoverageRatio = loanCoverageRatio; }

    public List<BranchStaff> getStaffList() { return staffList; }
    public void setStaffList(List<BranchStaff> staffList) { this.staffList = staffList; }
}
