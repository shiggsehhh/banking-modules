package com.bank.branchmanagerportal.service;

import com.bank.branchmanagerportal.entity.Issue;
import com.bank.branchmanagerportal.repository.IssueRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IssueService {

    @Autowired
    private IssueRepository issueRepository;

    public void raiseIssue(Issue issue) {
        issueRepository.save(issue);
    }

    public List<Issue> getIssuesByCustomerId(Long customerId) {
        return issueRepository.findByCustomerId(customerId);
    }
}
