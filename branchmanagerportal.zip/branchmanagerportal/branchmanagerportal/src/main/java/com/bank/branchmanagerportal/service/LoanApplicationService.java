package com.bank.branchmanagerportal.service;

import com.bank.branchmanagerportal.entity.LoanApplication;

import java.util.List;

public interface LoanApplicationService {
    List<LoanApplication> getLoanApplications(String branchName);
    void approveLoan(Long id);
    void rejectLoan(Long id);
}
