package com.bank.branchmanagerportal.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "branch_staff") // Maps to the 'branch_staff' table in the database
public class BranchStaff {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-generates ID
    private Long id;

    private String name; // Name of the staff member
    private String role; // Role of the staff member (e.g., "TELLER", "LOAN_OFFICER")
    private String branchName; // The branch the staff member belongs to

    // Getters and setters for all fields
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getBranchName() { return branchName; }
    public void setBranchName(String branchName) { this.branchName = branchName; }
}