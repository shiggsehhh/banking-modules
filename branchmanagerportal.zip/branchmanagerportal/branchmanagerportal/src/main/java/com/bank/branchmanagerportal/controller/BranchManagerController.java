package com.bank.branchmanagerportal.controller;

import com.bank.branchmanagerportal.entity.BranchManager;

import com.bank.branchmanagerportal.entity.BranchStaff;
import com.bank.branchmanagerportal.entity.Customer;
import com.bank.branchmanagerportal.entity.Issue;
import com.bank.branchmanagerportal.entity.LoanApplication;
import com.bank.branchmanagerportal.entity.LoanPayment;
import com.bank.branchmanagerportal.entity.LoanPaymentGroup;
import com.bank.branchmanagerportal.service.*;

import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;

@Controller
public class BranchManagerController {

    @Autowired
    private BranchManagerService branchManagerService;

    @Autowired
    private CustomerService customerService;

    @Autowired
    private BranchStaffService branchStaffService;

    @Autowired
    private LoanApplicationService loanService;

    @Autowired
    private LoanPaymentService paymentService;

    @Autowired
    private ReportService reportService; 
    
    @Autowired
    private IssueService issueService;

    @GetMapping("/")
    public String showLoginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String loginManager(@RequestParam String username,
                               @RequestParam String password,
                               Model model,
                               HttpSession session) {
        BranchManager manager = branchManagerService.authenticate(username, password);

        if (manager != null) {
            session.setAttribute("loggedInManager", manager);
            List<Customer> customers = customerService.getCustomersByBranch(manager.getBranchName());
            model.addAttribute("manager", manager);
            model.addAttribute("customers", customers);
            return "manager-dashboard";
        } else {
            model.addAttribute("error", "Invalid username or password");
            return "login";
        }
    }

    @GetMapping("/dashboard")
    public String showDashboard(Model model, HttpSession session) {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) return "redirect:/";

        List<Customer> customers = customerService.getCustomersByBranch(manager.getBranchName());
        model.addAttribute("manager", manager);
        model.addAttribute("customers", customers);
        return "manager-dashboard";
    }

    @GetMapping("/add-customer")
    public String showAddCustomerForm(Model model, HttpSession session) {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) return "redirect:/";

        model.addAttribute("customer", new Customer());
        model.addAttribute("branchName", manager.getBranchName());
        return "add-customer";
    }

    @PostMapping("/add-customer")
    public String addCustomer(@ModelAttribute Customer customer, HttpSession session, Model model) {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) return "redirect:/";

        customer.setBranchName(manager.getBranchName());
        customerService.saveCustomer(customer);

        List<Customer> customers = customerService.getCustomersByBranch(manager.getBranchName());
        model.addAttribute("manager", manager);
        model.addAttribute("customers", customers);
        model.addAttribute("message", "Customer added successfully!");
        return "manager-dashboard";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }

    @GetMapping("/staff")
    public String viewStaff(Model model, HttpSession session) {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) return "redirect:/";

        model.addAttribute("staffList", branchStaffService.getStaffByBranch(manager.getBranchName()));
        model.addAttribute("newStaff", new BranchStaff());
        return "manage-staff";
    }

    @PostMapping("/staff/add")
    public String addStaff(@ModelAttribute BranchStaff newStaff, HttpSession session) {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) return "redirect:/";

        newStaff.setBranchName(manager.getBranchName());
        branchStaffService.addStaff(newStaff);
        return "redirect:/staff";
    }

    @GetMapping("/staff/delete/{id}")
    public String deleteStaff(@PathVariable Long id) {
        branchStaffService.deleteStaff(id);
        return "redirect:/staff";
    }

    @GetMapping("/loan-applications")
    public String viewLoanApplications(Model model, HttpSession session) {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) return "redirect:/";

        List<LoanApplication> apps = loanService.getLoanApplications(manager.getBranchName());
        model.addAttribute("loanApps", apps);
        return "loan-applications";
    }

    @PostMapping("/loan-applications/approve/{id}")
    public String approveLoan(@PathVariable Long id) {
        loanService.approveLoan(id);
        return "redirect:/loan-applications";
    }

    @PostMapping("/loan-applications/reject/{id}")
    public String rejectLoan(@PathVariable Long id) {
        loanService.rejectLoan(id);
        return "redirect:/loan-applications";
    }

    @GetMapping("/loan-payments")
    public String viewLoanPayments(Model model, HttpSession session) {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) return "redirect:/";

        List<LoanPaymentGroup> grouped = paymentService.getGroupedPayments(manager.getBranchName());
        model.addAttribute("groupedPayments", grouped);
        return "loan-payments";
    }


    @GetMapping("/loan-payments/add")
    public String showAddPaymentForm(Model model) {
        model.addAttribute("payment", new LoanPayment());
        return "add-loan-payment";
    }

    @PostMapping("/loan-payments/add")
    public String addLoanPayment(@ModelAttribute LoanPayment payment, HttpSession session) {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) return "redirect:/";

        payment.setBranchName(manager.getBranchName());
        payment.setPaymentDate(LocalDate.now());

        paymentService.recordPayment(payment);
        return "redirect:/loan-payments";
    }

    @GetMapping("/report")
    public String showReport(Model model, HttpSession session) {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) {
            return "redirect:/login"; // or your login page
        }

        Map<String, Object> report = reportService.generateBranchReport(manager.getBranchName());
        model.addAttribute("manager", manager);
        model.addAttribute("report", report);
        return "branch-report";
    }



    @GetMapping("/report/pdf")
    public void downloadReportPdf(HttpServletResponse response, HttpSession session) throws Exception {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) {
            response.sendRedirect("/");
            return;
        }

        Map<String, Object> report = reportService.generateBranchReport(manager.getBranchName());

        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=branch_report.pdf");

        Document document = new Document();
        PdfWriter.getInstance(document, response.getOutputStream());
        document.open();

        Font titleFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD);
        Font normalFont = new Font(Font.FontFamily.HELVETICA, 12);

        document.add(new Paragraph("Branch Report - " + manager.getBranchName(), titleFont));
        document.add(new Paragraph("Generated on: " + LocalDate.now(), normalFont));
        document.add(new Paragraph(" "));

        document.add(new Paragraph("Total Customers: " + report.get("totalCustomers"), normalFont));
        document.add(new Paragraph("Total Loan Applications: " + report.get("totalLoanApplications"), normalFont));
        document.add(new Paragraph("Total Loans Issued: ₹" + report.get("totalLoans"), normalFont));
        document.add(new Paragraph("Total Payments Made: ₹" + report.get("totalPayments"), normalFont));
        document.add(new Paragraph("Number of Payments: " + report.get("totalPaymentsCount"), normalFont));

        document.close();
    }
    @GetMapping("/raise-issue")
    public String showRaiseIssueForm(Model model, HttpSession session) {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) return "redirect:/";

        model.addAttribute("issue", new Issue());
        model.addAttribute("customers", customerService.getCustomersByBranch(manager.getBranchName()));
        return "raise-issue";
    }

    @PostMapping("/raise-issue")
    public String submitIssue(@ModelAttribute Issue issue, Model model, HttpSession session) {
        BranchManager manager = (BranchManager) session.getAttribute("loggedInManager");
        if (manager == null) return "redirect:/";

        // Set current date and default status
        issue.setDateRaised(LocalDate.now());
        issue.setStatus("OPEN");

        // Save the issue
        issueService.raiseIssue(issue);

        // Show confirmation alert (handled by redirect with a param)
        model.addAttribute("message", "Issue submitted successfully!");

        // For alert popup, redirect with flash attribute or use JS alert on page
        return "redirect:/raise-issue?success=true";
    }
}
