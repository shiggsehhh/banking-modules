package com.bank.branchmanagerportal.entity;

import java.util.List;

public class LoanPaymentGroup {
    private Long loanId;
    private String customerName;
    private List<LoanPayment> payments;
    private double totalPaid;
    public Long getLoanId() {
		return loanId;
	}
	public void setLoanId(Long loanId) {
		this.loanId = loanId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public List<LoanPayment> getPayments() {
		return payments;
	}
	public void setPayments(List<LoanPayment> payments) {
		this.payments = payments;
	}
	public double getTotalPaid() {
		return totalPaid;
	}
	public void setTotalPaid(double totalPaid) {
		this.totalPaid = totalPaid;
	}
	public double getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
	private double loanAmount;

    // Getters and setters
}

