package com.bank.branchmanagerportal.entity;

import jakarta.persistence.*;

@Entity
public class BranchManager {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;
    private String password;
    private String branchName;

    // Constructors
    public BranchManager() {}

    public BranchManager(String username, String password, String branchName) {
        this.username = username;
        this.password = password;
        this.branchName = branchName;
    }

    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getBranchName() { return branchName; }
    public void setBranchName(String branchName) { this.branchName = branchName; }
}
