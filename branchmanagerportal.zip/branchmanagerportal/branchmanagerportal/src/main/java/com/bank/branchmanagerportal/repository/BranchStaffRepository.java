package com.bank.branchmanagerportal.repository;

import com.bank.branchmanagerportal.entity.BranchStaff;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

// JpaRepository provides standard CRUD operations (Create, Read, Update, Delete)
public interface BranchStaffRepository extends JpaRepository<BranchStaff, Long> {
    // Custom query method to find staff members by their branch name
    List<BranchStaff> findByBranchName(String branchName);
}