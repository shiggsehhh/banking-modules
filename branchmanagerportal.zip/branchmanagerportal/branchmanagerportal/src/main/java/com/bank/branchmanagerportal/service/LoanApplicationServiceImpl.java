package com.bank.branchmanagerportal.service;

import com.bank.branchmanagerportal.entity.LoanApplication;
import com.bank.branchmanagerportal.repository.LoanApplicationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LoanApplicationServiceImpl implements LoanApplicationService {

    @Autowired
    private LoanApplicationRepository loanRepo;

    @Override
    public List<LoanApplication> getLoanApplications(String branchName) {
        // Ignore branch filter for testing
        List<LoanApplication> all = loanRepo.findAll();
        System.out.println("DEBUG: Returning all loans (ignoring branch): " + all.size());
        return all;
    }



    @Override
    public void approveLoan(Long id) {
        LoanApplication app = loanRepo.findById(id).orElse(null);
        if (app != null) {
            app.setStatus("APPROVED");
            loanRepo.save(app);
        }
    }

    @Override
    public void rejectLoan(Long id) {
        LoanApplication app = loanRepo.findById(id).orElse(null);
        if (app != null) {
            app.setStatus("REJECTED");
            loanRepo.save(app);
        }
    }
}
