package com.bank.branchmanagerportal.service;

import com.bank.branchmanagerportal.entity.LoanPayment;
import com.bank.branchmanagerportal.entity.LoanPaymentGroup;

import java.util.List;

public interface LoanPaymentService {
    List<LoanPayment> getPaymentsByBranch(String branchName);
    void recordPayment(LoanPayment payment);
    List<LoanPaymentGroup> getGroupedPayments(String branchName); // ✅ Added method
}
