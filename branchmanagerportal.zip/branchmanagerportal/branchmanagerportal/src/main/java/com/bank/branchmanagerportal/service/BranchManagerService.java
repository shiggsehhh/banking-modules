package com.bank.branchmanagerportal.service;

import com.bank.branchmanagerportal.entity.BranchManager;
import com.bank.branchmanagerportal.repository.BranchManagerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BranchManagerService {

    @Autowired
    private BranchManagerRepository branchManagerRepository;

    public BranchManager authenticate(String username, String password) {
        return branchManagerRepository.findByUsernameAndPassword(username, password);
    }
}
