package com.bank.branchmanagerportal.service;

import com.bank.branchmanagerportal.entity.Customer;
import com.bank.branchmanagerportal.entity.LoanApplication;
import com.bank.branchmanagerportal.entity.LoanPayment;
import com.bank.branchmanagerportal.repository.CustomerRepository;
import com.bank.branchmanagerportal.repository.LoanApplicationRepository;
import com.bank.branchmanagerportal.repository.LoanPaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ReportServiceImpl implements ReportService {

    @Autowired
    private CustomerRepository customerRepo;

    @Autowired
    private LoanApplicationRepository loanRepo;

    @Autowired
    private LoanPaymentRepository paymentRepo;

    @Override
    public Map<String, Object> generateBranchReport(String branchName) {
        List<Customer> customers = customerRepo.findByBranchName(branchName);
        List<LoanApplication> loanApps = loanRepo.findByBranchName(branchName);
        List<LoanPayment> payments = paymentRepo.findByBranchName(branchName);

        double totalLoans = loanApps.stream().mapToDouble(LoanApplication::getAmount).sum();
        double totalPayments = payments.stream().mapToDouble(LoanPayment::getAmountPaid).sum();

        long approved = loanApps.stream().filter(l -> "APPROVED".equalsIgnoreCase(l.getStatus())).count();
        long pending = loanApps.stream().filter(l -> "PENDING".equalsIgnoreCase(l.getStatus())).count();
        long rejected = loanApps.stream().filter(l -> "REJECTED".equalsIgnoreCase(l.getStatus())).count();

        double avgLoan = loanApps.isEmpty() ? 0 : totalLoans / loanApps.size();
        double avgPayment = payments.isEmpty() ? 0 : totalPayments / payments.size();
        double coverageRatio = totalLoans == 0 ? 0 : (totalPayments / totalLoans) * 100;

        Map<String, Object> report = new HashMap<>();
        report.put("totalCustomers", customers.size());
        report.put("totalLoans", totalLoans);
        report.put("totalLoanApplications", loanApps.size());
        report.put("totalPayments", totalPayments);
        report.put("totalPaymentsCount", payments.size());

        report.put("approvedLoans", approved);
        report.put("pendingLoans", pending);
        report.put("rejectedLoans", rejected);

        report.put("avgLoanAmount", avgLoan);
        report.put("avgPaymentAmount", avgPayment);
        report.put("loanCoverageRatio", coverageRatio);

        return report;
    }

}
