package com.banking.bank.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {

    // @GetMapping("/customer/dashboard")
    // public String customerDashboard() {
    //     return "customer_dashboard";
    // }

    // @GetMapping("/teller/dashboard")
    // public String tellerDashboard() {
    //     return "teller_dashboard";
    // }

    // @GetMapping("/manager/dashboard")
    // public String managerDashboard() {
    //     return "manager_dashboard";
    // }

    // @GetMapping("/admin/dashboard")
    // public String adminDashboard() {
    //     return "admin_dashboard";
    // }
}