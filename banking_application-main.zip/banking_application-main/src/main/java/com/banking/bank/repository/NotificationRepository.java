package com.banking.bank.repository;

import com.banking.bank.model.Notification;

import jakarta.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {

    // Corrected to use Integer for userId and CreatedAt for timestamp
    List<Notification> findByUserIdOrderByCreatedAtDesc(Integer userId);
    
    @Modifying // Indicates that this query will modify data
    @Transactional // Essential for write operations in Spring Data JPA
    @Query("UPDATE Notification n SET n.isRead = true WHERE n.id IN :notificationIds")
    void markAsReadByIds(@Param("notificationIds") List<Long> notificationIds);


    // Optional: Find unread notifications for a user
    List<Notification> findByUserIdAndIsReadFalseOrderByCreatedAtDesc(Integer userId);
}
