package com.banking.bank.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class OtpPageController {
    @GetMapping("/otp")
    public String showOtpPage() {
        return "otp";
    }
}