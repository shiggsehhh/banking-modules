package com.banking.bank.model;

public enum TransactionType {
    Credit, Debit, Transfer
}