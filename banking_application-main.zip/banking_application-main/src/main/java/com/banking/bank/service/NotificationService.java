package com.banking.bank.service;

import com.banking.bank.model.Notification;
import com.banking.bank.repository.NotificationRepository;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;

    // Method to get all notifications for a specific user
    public List<Notification> getNotificationsByUserId(Integer userId) { // Changed userId type
        return notificationRepository.findByUserIdOrderByCreatedAtDesc(userId); // Changed method name suffix
    }

    // Optional: Method to get only unread notifications for a user
    public List<Notification> getUnreadNotificationsByUserId(Integer userId) { // Changed userId type
        return notificationRepository.findByUserIdAndIsReadFalseOrderByCreatedAtDesc(userId); // Changed method name suffix
    }

    // Optional: Method to save a new notification
    public Notification saveNotification(Notification notification) {
        return notificationRepository.save(notification);
    }

    // Optional: Method to mark a notification as read
    public Notification markNotificationAsRead(Long notificationId) {
        return notificationRepository.findById(notificationId)
                .map(notification -> {
                    notification.setRead(true);
                    return notificationRepository.save(notification);
                })
                .orElse(null); // Or throw an exception if not found
    }
    
    @Transactional // Essential for database write operations
    public void markNotificationsAsRead(List<Long> notificationIds) {
        if (notificationIds != null && !notificationIds.isEmpty()) {
            notificationRepository.markAsReadByIds(notificationIds); // Calls the new method in Repository
        }
    }
    
    @Transactional
    public Optional<Notification> setNotificationReadStatus(Long notificationId, Boolean isRead) {
        return notificationRepository.findById(notificationId)
                .map(notification -> {
                    notification.setRead(isRead);
                    return notificationRepository.save(notification);
                });
    }
    
    /**
     * Creates and saves a new notification for a given user.
     * This is the method that was missing.
     * @param userId The ID of the user to notify.
     * @param message The notification message.
     */
    public void createNotification(Integer userId, String message) {
        Notification notification = new Notification();
        notification.setUserId(userId);
        notification.setMessage(message);
        notification.setCreatedAt(LocalDateTime.now());
        notification.setRead(false); // New notifications are initially unread
        notificationRepository.save(notification);
    }
}