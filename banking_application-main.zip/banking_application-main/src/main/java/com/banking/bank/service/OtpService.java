package com.banking.bank.service;

import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class OtpService {
    private final Map<String, String> otpStorage = new ConcurrentHashMap<>();
    private final Random random = new Random();

    public String generateOtp(String username) {
        String otp = String.format("%06d", random.nextInt(1000000));
        otpStorage.put(username, otp);
        return otp;
    }

    public boolean validateOtp(String username, String otp) {
        String validOtp = otpStorage.get(username);
        if (validOtp != null && validOtp.equals(otp)) {
            otpStorage.remove(username);
            return true;
        }
        return false;
    }
}