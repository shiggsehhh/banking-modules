package com.banking.bank.service;

import com.banking.bank.model.User;
import com.banking.bank.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Optional;
import java.util.logging.Logger;

@Service
public class LoginService {

    private static final Logger logger = Logger.getLogger(LoginService.class.getName());

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    public String authenticate(String username, String password) {
        logger.info("Authenticating user: " + username);

        Optional<User> userOptional = userRepository.findByUsername(username);

        if (userOptional.isPresent()) {
            User user = userOptional.get();

            // Check if account is locked and if lock has expired
            if (user.isAccountLocked()) {
                if (user.getAccountLockedUntil() != null &&
                    user.getAccountLockedUntil().isBefore(LocalDateTime.now())) {
                    // Unlock account
                    user.setAccountLocked(false);
                    user.setLoginAttempts(0);
                    user.setAccountLockedUntil(null);
                    userRepository.save(user);
                } else {
                    logger.warning("Account is locked for user: " + username);
                    return null; // Account is still locked
                }
            }

            // Reset attempts if last login attempt was over 1 hour ago
            if (user.getAccountLockedUntil() == null && user.getLoginAttempts() > 0 && user.getLastLogin() != null) {
                if (user.getLastLogin().plus(1, ChronoUnit.HOURS).isBefore(LocalDateTime.now())) {
                    user.setLoginAttempts(0);
                    userRepository.save(user);
                }
            }

            if (passwordEncoder.matches(password, user.getPasswordHash())) {
                user.setLoginAttempts(0);
                user.setLastLogin(LocalDateTime.now());
                userRepository.save(user);
                return user.getRole().getRoleName();
            } else {
                int attempts = user.getLoginAttempts() + 1;
                user.setLoginAttempts(attempts);
                user.setLastLogin(LocalDateTime.now());
                if (attempts >= 5) {
                    user.setAccountLocked(true);
                    user.setAccountLockedUntil(LocalDateTime.now().plusHours(1));
                }
                userRepository.save(user);
                logger.warning("Password mismatch for user: " + username);
            }
        } else {
            logger.warning("User not found: " + username);
        }

        return null; // Authentication failed
    }
}