package com.banking.bank.controller;

import com.banking.bank.model.User;
import com.banking.bank.model.Role;
import com.banking.bank.repository.UserRepository;
import com.banking.bank.repository.RoleRepository;
import com.banking.bank.repository.BranchRepository;
import com.banking.bank.model.Branch;
import com.banking.bank.model.KycDocument;
import com.banking.bank.repository.KycDocumentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.*;
import java.time.LocalDate;
import java.util.List;

@Controller
public class RegistrationController {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private RoleRepository roleRepository;
    @Autowired
    private BranchRepository branchRepository;
    @Autowired
    private KycDocumentRepository kycDocumentRepository;
    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        List<Branch> branches = branchRepository.findAll();
        model.addAttribute("branches", branches);
        return "register";
    }

    @PostMapping("/register")
    public String registerCustomer(
            @RequestParam String fullName,
            @RequestParam String username,
            @RequestParam String password,
            @RequestParam String email,
            @RequestParam String phone,
            @RequestParam String address,
            @RequestParam String dob,
            @RequestParam String gender,
            @RequestParam Integer branchId,
            @RequestParam String occupation,
            @RequestParam("photo") MultipartFile photo,
            @RequestParam String idProofType,
            @RequestParam String idNumber,
            @RequestParam("idProof") MultipartFile idProof,
            Model model
    ) {
        // Save user
        User user = new User();
        user.setFullName(fullName);
        user.setUsername(username);
        user.setPasswordHash(passwordEncoder.encode(password));
        user.setEmail(email);
        user.setPhone(phone);
        user.setAddress(address);
        user.setDob(LocalDate.parse(dob));
        user.setGender(gender);
        user.setOccupation(occupation);
        user.setKycVerified(false);
        user.setRole(roleRepository.findByRoleName("Customer").orElseThrow());
        user.setBranch(branchRepository.findById(branchId).orElse(null));
        userRepository.save(user);

        // Save KYC documents
        try {
            String uploadDir = "uploads/kyc/" + user.getUserId();
            Files.createDirectories(Paths.get(uploadDir));

            // Photo
            String photoPath = uploadDir + "/photo_" + photo.getOriginalFilename();
            photo.transferTo(Paths.get(photoPath));
            KycDocument photoDoc = new KycDocument(user, "Photo", photoPath, "Pending", null, null, null);
            kycDocumentRepository.save(photoDoc);

            // ID Proof
            String idProofPath = uploadDir + "/" + idProofType + "_" + idProof.getOriginalFilename();
            idProof.transferTo(Paths.get(idProofPath));
            KycDocument idDoc = new KycDocument(user, idProofType, idProofPath, "Pending", null, null, idNumber);
            kycDocumentRepository.save(idDoc);

        } catch (Exception e) {
            model.addAttribute("error", "File upload failed: " + e.getMessage());
            return "register";
        }

        model.addAttribute("message", "Registration successful! Await KYC verification.");
        return "login";
    }
}
