package com.banking.bank.controller;

import com.banking.bank.security.JwtTokenProvider;
import com.banking.bank.model.User;
import com.banking.bank.repository.UserRepository;
import com.banking.bank.service.OtpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletResponse;
import java.util.Map;
import java.time.LocalDateTime;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Autowired
    private OtpService otpService;

    @Autowired
    private JavaMailSender mailSender;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> loginData, HttpServletResponse response) {
        String username = loginData.get("username");
        String password = loginData.get("password");
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Invalid username or password"));

        if (!passwordEncoder.matches(password, user.getPasswordHash())) {
            throw new RuntimeException("Invalid username or password");
        }

        String token = jwtTokenProvider.generateToken(username, user.getRole().getRoleName());

        // Set JWT as HttpOnly cookie
        ResponseCookie cookie = ResponseCookie.from("jwt", token)
                .httpOnly(true)
                .path("/")
                .maxAge(30 * 60) // 30 minutes
                .sameSite("Strict")
                .build();
        response.addHeader("Set-Cookie", cookie.toString());

        return ResponseEntity.ok(Map.of("role", user.getRole().getRoleName()));
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpServletResponse response) {
        ResponseCookie cookie = ResponseCookie.from("jwt", "")
                .httpOnly(true)
                .path("/")
                .maxAge(0)
                .sameSite("Strict")
                .build();
        response.addHeader("Set-Cookie", cookie.toString());
        return ResponseEntity.ok().build();
    }

    @PostMapping("/request-otp")
    public ResponseEntity<?> requestOtp(@RequestBody Map<String, String> loginData) {
        String username = loginData.get("username");
        String password = loginData.get("password");
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Invalid username or password"));

        // Unlock account if lockout expired
        if (user.getAccountLockedUntil() != null && user.getAccountLockedUntil().isBefore(LocalDateTime.now())) {
            user.setLoginAttempts(0);
            user.setAccountLockedUntil(null);
            userRepository.save(user);
        }

        // If still locked, block login
        if (user.getAccountLockedUntil() != null && user.getAccountLockedUntil().isAfter(LocalDateTime.now())) {
            return ResponseEntity.status(423).body("Account locked. Try again after: " + user.getAccountLockedUntil());
        }

        // Reset attempts if last failed login was over 1 hour ago
        if (user.getLastLogin() != null && user.getLastLogin().plusHours(1).isBefore(LocalDateTime.now())) {
            user.setLoginAttempts(0);
            userRepository.save(user);
        }

        // Check password
        if (!passwordEncoder.matches(password, user.getPasswordHash())) {
            int attempts = user.getLoginAttempts() + 1;
            user.setLoginAttempts(attempts);
            user.setLastLogin(LocalDateTime.now()); // Use last_login as last failed login
            if (attempts >= 5) {
                user.setAccountLockedUntil(LocalDateTime.now().plusHours(1));
            }
            userRepository.save(user);
            return ResponseEntity.status(401).body("Invalid username or password");
        }

        // --- KYC check for Customer role ---
        String roleName = user.getRole().getRoleName();
        if ("Customer".equalsIgnoreCase(roleName)) {
            // Check if KYC is verified
            // If not verified, block login
            try {
                // Use reflection to get kycVerified if not present in User entity
                java.lang.reflect.Field kycField = user.getClass().getDeclaredField("kycVerified");
                kycField.setAccessible(true);
                Boolean kycVerified = (Boolean) kycField.get(user);
                if (kycVerified == null || !kycVerified) {
                    return ResponseEntity.status(403).body("KYC not verified. Please complete KYC to login.");
                }
            } catch (NoSuchFieldException | IllegalAccessException e) {
                // If field not present, fallback to DB column (if mapped)
                // Or return error
                return ResponseEntity.status(500).body("KYC verification check failed. Contact support.");
            }
        }

        // Reset attempts on successful login
        user.setLoginAttempts(0);
        user.setAccountLockedUntil(null);
        userRepository.save(user);

        // Generate OTP and send email
        String otp = otpService.generateOtp(username);
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(user.getEmail());
        message.setSubject("Your OTP for Banking Application Login");
        message.setText("Your OTP is: " + otp + "\nIt is valid for 5 minutes.");
        mailSender.send(message);

        return ResponseEntity.ok().build();
    }

    @PostMapping("/verify-otp")
    public ResponseEntity<?> verifyOtp(@RequestBody Map<String, String> otpData, HttpServletResponse response) {
        String username = otpData.get("username");
        String otp = otpData.get("otp");
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Invalid username"));

        if (!otpService.validateOtp(username, otp)) {
            return ResponseEntity.status(401).body("Invalid OTP");
        }

        String token = jwtTokenProvider.generateToken(username, user.getRole().getRoleName());

        ResponseCookie cookie = ResponseCookie.from("jwt", token)
                .httpOnly(true)
                .path("/")
                .maxAge(30 * 60)
                .sameSite("Strict")
                .build();
        response.addHeader("Set-Cookie", cookie.toString());

        return ResponseEntity.ok(Map.of("role", user.getRole().getRoleName()));
    }
}