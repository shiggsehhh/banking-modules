package com.banking.bank.service;

import com.banking.bank.model.TransactionType; // Ensure this is correct
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate; // Ensure LocalDate is imported

@Service
public class PdfGeneratorService {

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    private static final Font FONT_HEADER = new Font(Font.HELVETICA, 18, Font.BOLD);
    private static final Font FONT_SUB_HEADER = new Font(Font.HELVETICA, 14, Font.BOLD);
    private static final Font FONT_NORMAL = new Font(Font.HELVETICA, 10, Font.NORMAL);
    private static final Font FONT_BOLD = new Font(Font.HELVETICA, 10, Font.BOLD);
    private static final Font FONT_TABLE_HEADER = new Font(Font.HELVETICA, 10, Font.BOLD);
    private static final Font FONT_TABLE_CELL = new Font(Font.HELVETICA, 9, Font.NORMAL);
    private static final Font FONT_BALANCE = new Font(Font.HELVETICA, 12, Font.BOLD);


    /**
     * Generates a PDF account statement.
     *
     * @param statementData The data required to generate the statement.
     * @param startDate The start date of the statement period.
     * @param endDate The end date of the statement period.
     * @return A byte array representing the PDF document.
     * @throws DocumentException If there's an error creating the PDF document.
     * @throws IOException If there's an error with I/O operations.
     */
    public byte[] generateStatementPdf(StatementData statementData, LocalDate startDate, LocalDate endDate)
            throws DocumentException, IOException {

        Document document = new Document(PageSize.A4);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PdfWriter.getInstance(document, baos);

        document.open();

        // --- 1. Header Information ---
        Paragraph bankName = new Paragraph("Mirchi Mitchells Bank", FONT_HEADER);
        bankName.setAlignment(Element.ALIGN_CENTER);
        document.add(bankName);

        Paragraph statementTitle = new Paragraph("Account Statement", FONT_SUB_HEADER);
        statementTitle.setAlignment(Element.ALIGN_CENTER);
        statementTitle.setSpacingAfter(10);
        document.add(statementTitle);

        Paragraph statementPeriod = new Paragraph(
            "Statement Period: " + startDate.format(DATE_FORMATTER) + " to " + endDate.format(DATE_FORMATTER),
            FONT_NORMAL);
        statementPeriod.setAlignment(Element.ALIGN_CENTER);
        statementPeriod.setSpacingAfter(20);
        document.add(statementPeriod);

        // --- 2. Account Holder Information ---
        document.add(new Paragraph("Account Holder Details:", FONT_BOLD));
        document.add(new Paragraph("Username: " + statementData.getUser().getUsername(), FONT_NORMAL));
        document.add(new Paragraph("Account Number: " + statementData.getAccount().getAccountNumber(), FONT_NORMAL));
        document.add(new Paragraph("Account Type: " + statementData.getAccount().getAccountType(), FONT_NORMAL));
        document.add(new Paragraph("Customer ID: " + statementData.getUser().getUserId(), FONT_NORMAL));
        document.add(new Paragraph("\n")); // Add some space

        // --- 3. Account Summary ---
        document.add(new Paragraph("Account Summary:", FONT_BOLD));
        document.add(new Paragraph("Opening Balance (" + startDate.format(DATE_FORMATTER) + "): ₹" + String.format("%.2f", statementData.getOpeningBalance()), FONT_BALANCE));
        document.add(new Paragraph("Total Debits in Period: ₹" + String.format("%.2f", statementData.getTotalDebitsInPeriod()), FONT_NORMAL));
        document.add(new Paragraph("Total Credits in Period: ₹" + String.format("%.2f", statementData.getTotalCreditsInPeriod()), FONT_NORMAL));
        document.add(new Paragraph("Closing Balance (" + endDate.format(DATE_FORMATTER) + "): ₹" + String.format("%.2f", statementData.getClosingBalance()), FONT_BALANCE));
        document.add(new Paragraph("\n")); // Add some space


        // --- 4. Transaction Details ---
        document.add(new Paragraph("Transaction Details:", FONT_BOLD));
        document.add(new Paragraph("\n")); // Add some space

        PdfPTable table = new PdfPTable(5); // 5 columns: Date, Description, Debit, Credit, Running Balance
        table.setWidthPercentage(100);
        table.setSpacingBefore(10f);
        table.setSpacingAfter(10f);

        // Set column widths (optional, but good for layout)
        float[] columnWidths = {1.5f, 4f, 1.5f, 1.5f, 2f}; // relative widths
        table.setWidths(columnWidths);

        // Table Headers
        addTableHeader(table, "Date");
        addTableHeader(table, "Description");
        addTableHeader(table, "Debit (₹)");
        addTableHeader(table, "Credit (₹)");
        addTableHeader(table, "Running Balance (₹)");

        // Populate table with transactions
        BigDecimal runningBalance = statementData.getOpeningBalance(); // Start running balance from opening balance
        for (com.banking.bank.model.Transaction transaction : statementData.getTransactions()) {
            addTableCell(table, transaction.getTransactionDate().format(DATE_FORMATTER));
            addTableCell(table, transaction.getDescription());

            if (transaction.getTransactionType() == TransactionType.Debit) {
                addTableCell(table, String.format("%.2f", transaction.getAmount())); // Debit column
                addTableCell(table, ""); // No credit
                runningBalance = runningBalance.subtract(transaction.getAmount());
            } else { // TransactionType.Credit
                addTableCell(table, ""); // No debit
                addTableCell(table, String.format("%.2f", transaction.getAmount())); // Credit column
                runningBalance = runningBalance.add(transaction.getAmount());
            }
            addTableCell(table, String.format("%.2f", runningBalance)); // Running Balance
        }

        document.add(table);

        document.close();

        return baos.toByteArray();
    }

    // Helper method to add table header cells
    private void addTableHeader(PdfPTable table, String headerText) {
        PdfPCell header = new PdfPCell(new Phrase(headerText, FONT_TABLE_HEADER));
        header.setHorizontalAlignment(Element.ALIGN_CENTER);
        header.setVerticalAlignment(Element.ALIGN_MIDDLE);
        header.setPadding(5);
        //header.setBackgroundColor(new com.lowagie.text.Color(230, 230, 230)); // Light grey background
        table.addCell(header);
    }

    // Helper method to add table data cells
    private void addTableCell(PdfPTable table, String cellText) {
        PdfPCell cell = new PdfPCell(new Phrase(cellText, FONT_TABLE_CELL));
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setPadding(5);
        table.addCell(cell);
    }
}