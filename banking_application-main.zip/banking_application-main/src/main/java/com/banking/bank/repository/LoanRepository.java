package com.banking.bank.repository;

import com.banking.bank.model.Loan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LoanRepository extends JpaRepository<Loan, Long> {

    // Custom query method to find loans by user ID
    List<Loan> findByUserId(Integer userId);

    // You can add more methods here as needed, e.g.,
    // Optional<Loan> findByLoanIdAndUserId(Long loanId, Integer userId);
    // List<Loan> findByUserIdAndLoanStatus(Integer userId, LoanStatus status);
}