package com.banking.bank.model;

public enum AccountStatus {
    Active,
    Closed,
    Frozen
}