package com.banking.bank.controller;

import com.banking.bank.dto.AddressUpdateRequest;
import com.banking.bank.dto.ContactInfoUpdateRequest;
import com.banking.bank.dto.PasswordChangeRequest;
import com.banking.bank.dto.UserProfileDto;
import com.banking.bank.model.Account;
import com.banking.bank.model.Loan;
import com.banking.bank.model.Notification;
import com.banking.bank.model.User;
import com.banking.bank.model.Transaction;
import com.banking.bank.model.TransactionMode;
import com.banking.bank.service.CustomerService;
import com.banking.bank.service.NotificationService;
import com.banking.bank.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping; // <-- ADD THIS IMPORT
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam; // <-- ADD THIS IMPORT
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes; // <-- ADD THIS IMPORT
import com.banking.bank.service.PdfGeneratorService; // <-- NEW
import com.banking.bank.service.StatementData; // <-- NEW
import com.lowagie.text.DocumentException;
import org.springframework.web.bind.annotation.GetMapping; // <-- Ensure this is present
import org.springframework.web.bind.annotation.PostMapping; 
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.math.BigDecimal; // <-- ADD THIS IMPORT
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;  
@Controller
@RequestMapping("/customer")
public class CustomerController {

	@Autowired
	private CustomerService customerService;
	
	@Autowired // <-- ADD THIS
    private PdfGeneratorService pdfGeneratorService; 
	
	@Autowired
	private NotificationService notificationService;
	
	@Autowired
    private BCryptPasswordEncoder passwordEncoder;
	// <-- ADD THIS
	//private final Integer DEFAULT_CUSTOMER_ID = 1;

	@Autowired
	private UserRepository userRepository;
	// <-- NEW

	@GetMapping("/")
	public String redirectToDashboard() {
		return "redirect:/customer/dashboard";
	}

	/**
	 * Handles requests for the customer dashboard. Displays user's name, primary
	 * account balance, and recent transactions.
	 */
	@GetMapping("/dashboard")
	public String viewDashboard(Model model) {
		Optional<User> userOptional = customerService.getUserById(getCurrentUserId());
		if (userOptional.isPresent()) {
			User customerUser = userOptional.get();
			model.addAttribute("userName", customerUser.getFullName());

			Optional<Account> primaryAccount = customerService.getPrimaryAccountForUser(getCurrentUserId());
			primaryAccount.ifPresent(account -> model.addAttribute("accountBalance", account.getBalance()));
			primaryAccount.ifPresent(account -> model.addAttribute("accountNumber", account.getAccountNumber()));

			List<Transaction> recentTransactions = customerService.getRecentTransactionsForUser(getCurrentUserId());
			model.addAttribute("recentTransactions", recentTransactions);

			if (model.containsAttribute("transferSuccess")) {
				model.addAttribute("transferSuccess", model.getAttribute("transferSuccess"));
			}
			if (model.containsAttribute("transferError")) {
				model.addAttribute("transferError", model.getAttribute("transferError"));
			}

			return "customer/dashboard"; // <-- CHANGED
		} else {
			return "error";
		}
	}

	@GetMapping("/accounts")
	public String viewAccounts(Model model) {
	    List<Account> accounts = customerService.getAccountsByUserId(getCurrentUserId());
	    model.addAttribute("accounts", accounts);
	    return "customer/account-details"; // <-- CHANGED
	}

	/**
	 * Optional: View details of a specific account by ID.
	 */
	@GetMapping("/accounts/{accountId}")
	public String viewAccountDetail(@PathVariable Long accountId, Model model) {
		Optional<Account> accountOptional = customerService.getAccountById(accountId);

		if (accountOptional.isPresent() && accountOptional.get().getUserId().equals(getCurrentUserId())) {
			model.addAttribute("account", accountOptional.get());
			return "customer/single-account-detail"; // <-- CHANGED
		} else {
			// Account not found or doesn't belong to the current user
			return "error"; // Placeholder error page
		}
	}

	/**
	 * Handles requests for the customer's transaction history. Displays all
	 * transactions for the logged-in customer. Feature: View Transaction History
	 */
	@GetMapping("/transactions")
	public String viewTransactionHistory(Model model) {
	    List<Transaction> allTransactions = customerService.getAllTransactionsForUser(getCurrentUserId());
	    model.addAttribute("allTransactions", allTransactions);
	    return "customer/transaction-history"; // <-- CHANGED
	}

	/**
	 * Displays the form for making a new transfer. Accessible via GET
	 * /customer/transfer
	 */
	@GetMapping("/transfer")
	public String showTransferForm(Model model) {
		// Retrieve flash attributes if redirected back to the form (e.g., on validation
		// error)
		if (model.containsAttribute("transferError")) {
			model.addAttribute("transferError", model.getAttribute("transferError"));
		}
		return "customer/make-transfer"; // <-- CHANGED
	}

	/**
	 * Handles the submission of the transfer form. Accessible via POST
	 * /customer/transfer
	 */
	@PostMapping("/transfer")
	public String processTransfer(
			@RequestParam("recipientName") String recipientName,
			@RequestParam("recipientAccountNumber") String recipientAccountNumber,
			@RequestParam("recipientIfscCode") String recipientIfscCode,
			@RequestParam("amount") BigDecimal amount,
			RedirectAttributes redirectAttributes
	) {
		// Basic server-side validation for amount
		if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
			redirectAttributes.addFlashAttribute("transferError", "Transfer amount must be positive.");
			return "redirect:/customer/transfer"; // Redirect back to the form
		}

		try {
			// Call the service method to perform the transfer logic
			// This method will be implemented in CustomerService next
			customerService.performTransfer(getCurrentUserId(), recipientName, recipientAccountNumber, recipientIfscCode, amount);
			// On success, add a success message and redirect to dashboard
			redirectAttributes.addFlashAttribute("transferSuccess",
					"Transfer of ₹" + amount + " to " + recipientName + " successful!");
			return "redirect:/customer/dashboard";
		} catch (IllegalArgumentException e) {
			// Catch specific business logic errors from service (e.g., insufficient funds)
			redirectAttributes.addFlashAttribute("transferError", e.getMessage());
			return "redirect:/customer/transfer"; // Redirect back to form with error
		} catch (Exception e) {
			// Catch any other unexpected errors (e.g., database issues)
			redirectAttributes.addFlashAttribute("transferError",
					"An unexpected error occurred during transfer: " + e.getMessage());
			return "redirect:/customer/transfer"; // Redirect back to form with error
		}
	}
	 /**
     * Displays the form for depositing money into the account.
     * Accessible via GET /customer/deposit
     */
    @GetMapping("/deposit")
    public String showDepositForm(Model model) {
        // Add flash attributes if redirected back to the form (e.g., on validation error)
        if (model.containsAttribute("depositError")) {
            model.addAttribute("depositError", model.getAttribute("depositError"));
        }
        return "customer/deposit-form"; // <-- CHANGED
    }

    /**
     * Handles the submission of the deposit form.
     * Accessible via POST /customer/deposit
     */
    @PostMapping("/deposit")
    public String processDeposit(
            @RequestParam("amount") BigDecimal amount,
            @RequestParam("transactionMode") String transactionModeString,
            RedirectAttributes redirectAttributes
    ) {
        // Basic server-side validation for amount
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            redirectAttributes.addFlashAttribute("depositError", "Deposit amount must be positive.");
            return "redirect:/customer/deposit";
        }

        TransactionMode mode;
        try {
            mode = TransactionMode.valueOf(transactionModeString); // Convert string to enum
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("depositError", "Invalid deposit mode selected.");
            return "redirect:/customer/deposit";
        }

        try {
            customerService.processDeposit(getCurrentUserId(), amount, mode);
            redirectAttributes.addFlashAttribute("depositSuccess", "Successfully deposited ₹" + amount + " via " + mode + ".");
            return "redirect:/customer/dashboard";
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("depositError", e.getMessage());
            return "redirect:/customer/deposit";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("depositError", "An unexpected error occurred during deposit: " + e.getMessage());
            return "redirect:/customer/deposit";
        }
    }
    
 // --- NEW METHOD for Loan Zone functionality ---
    /**
     * Displays the loan zone page, showing all loans for the logged-in customer.
     * Accessible via GET /customer/loan-zone
     */
    @GetMapping("/loan-zone")
    public String viewLoanZone(Model model) {
        List<Loan> customerLoans = customerService.getLoansByUserId(getCurrentUserId());
        model.addAttribute("loans", customerLoans);
        if (model.containsAttribute("loanMessage")) {
            model.addAttribute("loanMessage", model.getAttribute("loanMessage"));
        }
        return "customer/loan-zone"; // <-- CHANGED
    }
    
    @PostMapping("/loan-zone/pay")
    public String processLoanPayment(
            @RequestParam("loanId") Long loanId,
            @RequestParam("paymentAmount") BigDecimal paymentAmount,
            RedirectAttributes redirectAttributes) {
        if (paymentAmount == null || paymentAmount.compareTo(BigDecimal.ZERO) <= 0) {
            redirectAttributes.addFlashAttribute("loanMessage", "Payment amount must be positive.");
            return "redirect:/customer/loan-zone";
        }
        try {
            BigDecimal newBalance = customerService.processLoanPayment(getCurrentUserId(), loanId, paymentAmount);
            Map<String, String> paymentSuccessDetails = new HashMap<>();
            paymentSuccessDetails.put("paidAmount", paymentAmount.toPlainString());
            paymentSuccessDetails.put("newBalance", newBalance.toPlainString());
            redirectAttributes.addFlashAttribute("paymentSuccessDetails", paymentSuccessDetails);
            redirectAttributes.addFlashAttribute("loanMessage", "Loan payment for ID " + loanId + " successful!");
            return "redirect:/customer/loan-zone";
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("loanMessage", "Payment failed: " + e.getMessage());
            return "redirect:/customer/loan-zone";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("loanMessage", "An unexpected error occurred during payment: " + e.getMessage());
            e.printStackTrace();
            return "redirect:/customer/loan-zone";
        }
    }
    
    /**
     * Displays the loan application form.
     * Accessible via GET /customer/loan-zone/apply
     */
    @GetMapping("/loan-zone/apply")
    public String showLoanApplicationForm(Model model) {
        // Add flash attributes if redirected from a failed application (for messages)
        if (model.containsAttribute("loanApplicationMessage")) {
            model.addAttribute("loanApplicationMessage", model.getAttribute("loanApplicationMessage"));
            model.addAttribute("loanApplicationSuccess", model.getAttribute("loanApplicationSuccess")); // To determine message type
        }
        return "customer/loan-apply"; // <-- CHANGED
    }

    /**
     * Handles the submission of the loan application form.
     * Accessible via POST /customer/loan-zone/apply
     */
    @PostMapping("/loan-zone/apply")
    public String processLoanApplication(
            @RequestParam("loanAmount") BigDecimal loanAmount,
            @RequestParam("loanTermMonths") Integer loanTermMonths,
            @RequestParam(value = "assetDocument", required = false) MultipartFile assetDocument,
            RedirectAttributes redirectAttributes) {
        if (loanAmount == null || loanAmount.compareTo(BigDecimal.ZERO) <= 0) {
            redirectAttributes.addFlashAttribute("loanApplicationMessage", "Loan amount must be positive.");
            redirectAttributes.addFlashAttribute("loanApplicationSuccess", false);
            return "redirect:/customer/loan-zone/apply";
        }
        // Add similar validation for loanTermMonths if not already handled by HTML5 min/max
        if (loanTermMonths == null || loanTermMonths <= 0) {
             redirectAttributes.addFlashAttribute("loanApplicationMessage", "Loan term must be positive.");
             redirectAttributes.addFlashAttribute("loanApplicationSuccess", false);
             return "redirect:/customer/loan-zone/apply";
        }


        try {
            boolean success = customerService.applyForLoan(getCurrentUserId(), loanAmount, loanTermMonths, assetDocument);
            if (success) {
                redirectAttributes.addFlashAttribute("loanApplicationMessage", "Loan application submitted successfully! It is now PENDING approval.");
                redirectAttributes.addFlashAttribute("loanApplicationSuccess", true);
            } else {
                redirectAttributes.addFlashAttribute("loanApplicationMessage", "Loan application failed. Please try again.");
                redirectAttributes.addFlashAttribute("loanApplicationSuccess", false);
            }
            return "redirect:/customer/loan-zone";
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("loanApplicationMessage", "Loan application failed: " + e.getMessage());
            redirectAttributes.addFlashAttribute("loanApplicationSuccess", false);
            return "redirect:/customer/loan-zone/apply";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("loanApplicationMessage", "An unexpected error occurred during loan application: " + e.getMessage());
            redirectAttributes.addFlashAttribute("loanApplicationSuccess", false);
            e.printStackTrace();
            return "redirect:/customer/loan-zone/apply";
        }
    }
    
    /**
     * Handles the request to download account statement as PDF.
     * Accessible via GET /customer/download-statement
     */
    @GetMapping("/download-statement") // This is the URL to display the form page
    public String showDownloadStatementPage(Model model) {
        // You can add any model attributes here if you want to pass data to the HTML,
        // for example, an error message if redirected from a failed PDF generation attempt.
        return "customer/download-statement"; // <-- CHANGED
    }


    /**
     * This method is specifically for GENERATING and DOWNLOADING the PDF.
     * It's triggered when the form on download-statement.html is submitted.
     * Notice the DIFFERENT @GetMapping path.
     */
    @GetMapping("/generate-statement-pdf")
    public void generateStatementPdf(
            @RequestParam("startDate") LocalDate startDate,
            @RequestParam("endDate") LocalDate endDate,
            HttpServletResponse response) throws IOException, DocumentException {
        response.setContentType("application/pdf");
        String headerKey = "Content-Disposition";
        String headerValue = String.format("attachment; filename=account_statement_%s_to_%s.pdf", startDate.toString(), endDate.toString());
        response.setHeader(headerKey, headerValue);

        try {
            StatementData statementData = customerService.getTransactionsForStatement(getCurrentUserId(), startDate, endDate);
            byte[] pdfBytes = pdfGeneratorService.generateStatementPdf(statementData, startDate, endDate);
            response.getOutputStream().write(pdfBytes);
            response.getOutputStream().flush();
            response.getOutputStream().close();
        } catch (IllegalArgumentException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, e.getMessage());
            e.printStackTrace();
        } catch (DocumentException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error generating PDF: " + e.getMessage());
            e.printStackTrace();
        } catch (IOException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error writing PDF to response: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An unexpected error occurred: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * API endpoint to fetch notifications for the logged-in customer.
     * Returns a list of Notification objects (will be converted to JSON automatically).
     */
    @GetMapping("/notifications") // New endpoint for fetching notifications
    @ResponseBody // This annotation is crucial to return data (JSON/XML), not a view name
    public List<Notification> getCustomerNotifications() {
        return notificationService.getNotificationsByUserId(getCurrentUserId());
    }
    
    @GetMapping("/all-notifications")
    public String showAllNotifications(Model model) {
        List<Notification> allNotifications = notificationService.getNotificationsByUserId(getCurrentUserId());
        model.addAttribute("notifications", allNotifications);
        return "customer/all-notifications"; // <-- CHANGED
    }
    
    /**
     * Endpoint to manually update the read status of a specific notification.
     * Expects a JSON body like: {"isRead": true} or {"isRead": false}
     * @param notificationId The ID of the notification to update.
     * @param payload A map containing the "isRead" boolean status.
     * @return ResponseEntity with updated notification or error status.
     */
    @PutMapping("/notifications/{notificationId}/status")
    @ResponseBody // Crucial: this method returns data (JSON), not a view
    public ResponseEntity<com.banking.bank.model.Notification> updateNotificationStatus(
            @PathVariable Long notificationId,
            @RequestBody Map<String, Boolean> payload) {

        // Basic validation for the payload
        if (payload == null || !payload.containsKey("isRead")) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        Boolean isRead = payload.get("isRead");

        // In a real app, you'd verify the notification belongs to the authenticated user
        // For now, we rely on the service to handle the findById correctly.
        // If you add user context to the service method, use that here.
        // For simplicity in this example, we're not adding user verification here.

        return notificationService.setNotificationReadStatus(notificationId, isRead)
                .map(updatedNotification -> new ResponseEntity<>(updatedNotification, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND)); // If notification not found
    }
    
    /**
     * Displays the user's profile page with their personal and primary account details.
     * @param model The Spring Model to pass data to the view.
     * @return The name of the profile view.
     */
    @GetMapping("/profile")
    public String showProfile(Model model) {
        Optional<UserProfileDto> userProfileOptional = customerService.getUserProfile(getCurrentUserId());
        if (userProfileOptional.isPresent()) {
            model.addAttribute("userProfile", userProfileOptional.get());
            return "customer/profile"; // <-- CHANGED
        } else {
            model.addAttribute("errorMessage", "User profile not found.");
            return "customer/dashboard"; // <-- CHANGED
        }
    }
    
    /**
     * Handles requests to change the user's password.
     * @param passwordChangeRequest DTO containing current, new, and confirm new passwords.
     * @return ResponseEntity indicating success or failure.
     */
    @PutMapping("/profile/password")
    @ResponseBody
    public ResponseEntity<String> changePassword(@RequestBody PasswordChangeRequest passwordChangeRequest) {
        Integer userId = getCurrentUserId();
        if (!passwordChangeRequest.getNewPassword().equals(passwordChangeRequest.getConfirmNewPassword())) {
            return new ResponseEntity<>("New password and confirmation do not match.", HttpStatus.BAD_REQUEST);
        }
        try {
            customerService.changePassword(userId, passwordChangeRequest.getCurrentPassword(), passwordChangeRequest.getNewPassword());
            return new ResponseEntity<>("Password changed successfully.", HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred during password change.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Handles requests to update the user's contact information (email and phone).
     * @param contactInfoUpdateRequest DTO containing new email and phone.
     * @return ResponseEntity indicating success or failure.
     */
    @PutMapping("/profile/contact-info")
    @ResponseBody
    public ResponseEntity<String> updateContactInfo(@RequestBody ContactInfoUpdateRequest contactInfoUpdateRequest) {
        Integer userId = getCurrentUserId();
        try {
            customerService.updateContactInfo(userId, contactInfoUpdateRequest.getEmail(), contactInfoUpdateRequest.getPhone());
            return new ResponseEntity<>("Contact information updated successfully.", HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred during contact info update.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Handles requests to update the user's residential address.
     * @param addressUpdateRequest DTO containing the new address.
     * @return ResponseEntity indicating success or failure.
     */
    @PutMapping("/profile/address")
    @ResponseBody
    public ResponseEntity<String> updateAddress(@RequestBody AddressUpdateRequest addressUpdateRequest) {
        Integer userId = getCurrentUserId();
        try {
            customerService.updateAddress(userId, addressUpdateRequest.getAddress());
            return new ResponseEntity<>("Address updated successfully.", HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred during address update.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    private Integer getCurrentUserId() {
        String username = SecurityContextHolder.getContext().getAuthentication().getName();
        return userRepository.findByUsername(username)
                .map(User::getUserId)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }
}