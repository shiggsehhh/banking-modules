package com.banking.bank.service;

import com.banking.bank.model.Account;
import com.banking.bank.model.Transaction;
import com.banking.bank.model.User;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

// A simple data class to hold all necessary info for the statement
public class StatementData {
    private User user;
    private Account account;
    private List<Transaction> transactions;
    private BigDecimal openingBalance;
    private BigDecimal closingBalance; // This will be the account's current balance
    private BigDecimal totalDebitsInPeriod;
    private BigDecimal totalCreditsInPeriod;

    public StatementData(User user, Account account, List<Transaction> transactions,
                         BigDecimal openingBalance, BigDecimal closingBalance,
                         BigDecimal totalDebitsInPeriod, BigDecimal totalCreditsInPeriod) {
        this.user = user;
        this.account = account;
        this.transactions = transactions;
        this.openingBalance = openingBalance;
        this.closingBalance = closingBalance;
        this.totalDebitsInPeriod = totalDebitsInPeriod;
        this.totalCreditsInPeriod = totalCreditsInPeriod;
    }

    // Getters for all fields
    public User getUser() {
        return user;
    }

    public Account getAccount() {
        return account;
    }

    public List<Transaction> getTransactions() {
        return transactions;
    }

    public BigDecimal getOpeningBalance() {
        return openingBalance;
    }

    public BigDecimal getClosingBalance() {
        return closingBalance;
    }

    public BigDecimal getTotalDebitsInPeriod() {
        return totalDebitsInPeriod;
    }

    public BigDecimal getTotalCreditsInPeriod() {
        return totalCreditsInPeriod;
    }
}