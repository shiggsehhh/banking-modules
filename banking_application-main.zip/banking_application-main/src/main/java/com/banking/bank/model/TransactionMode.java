package com.banking.bank.model;

public enum TransactionMode {
    NEFT, IMPS, Cash, Cheque
}