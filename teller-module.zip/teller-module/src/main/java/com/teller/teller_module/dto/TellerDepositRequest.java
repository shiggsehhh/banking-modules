package com.teller.teller_module.dto;

import java.math.BigDecimal;
import jakarta.validation.constraints.*;

public class TellerDepositRequest {

    @NotNull
    private Long accountId;

    @NotNull
    @Positive
    private BigDecimal amount;

    // Constructors, getters, setters
    public TellerDepositRequest() {}

    public TellerDepositRequest(Long accountId, BigDecimal amount) {
        this.accountId = accountId;
        this.amount = amount;
    }

    public Long getAccountId() { return accountId; }
    public void setAccountId(Long accountId) { this.accountId = accountId; }

    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
}
