package com.teller.teller_module.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Message {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String content;

    private String reply;

    private LocalDateTime sentAt;

    private LocalDateTime repliedAt;
    private String status;
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getReply() {
		return reply;
	}

	public void setReply(String reply) {
		this.reply = reply;
	}

	public LocalDateTime getSentAt() {
		return sentAt;
	}

	public void setSentAt(LocalDateTime sentAt) {
		this.sentAt = sentAt;
	}

	public LocalDateTime getRepliedAt() {
		return repliedAt;
	}

	public void setRepliedAt(LocalDateTime repliedAt) {
		this.repliedAt = repliedAt;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Message(Long id, String content, String reply, LocalDateTime sentAt, LocalDateTime repliedAt, User user) {
		super();
		this.id = id;
		this.content = content;
		this.reply = reply;
		this.sentAt = sentAt;
		this.repliedAt = repliedAt;
		this.user = user;
	}

	public Message() {
		super();
	}

	  // add this field if missing

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    
}