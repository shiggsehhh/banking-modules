package com.teller.teller_module.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;

public class NewAccountRequest {

    private Long customerId; // Optional if new customer

    private String customerName; // Required if new customer
    private String customerEmail; // Required if new customer
    private String phone; // Required if new customer
    private String address; // Required if new customer

    private String accountType;
    private BigDecimal initialDeposit;

    public NewAccountRequest() {
        super();
    }

    public NewAccountRequest(Long customerId, String customerName, String customerEmail, String phone, String address,
                             String accountType, BigDecimal initialDeposit) {
        super();
        this.customerId = customerId;
        this.customerName = customerName;
        this.customerEmail = customerEmail;
        this.phone = phone;
        this.address = address;
        this.accountType = accountType;
        this.initialDeposit = initialDeposit;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public BigDecimal getInitialDeposit() {
        return initialDeposit;
    }

    public void setInitialDeposit(BigDecimal initialDeposit) {
        this.initialDeposit = initialDeposit;
    }
}

//package com.teller.teller_module.dto;
//
//import jakarta.validation.constraints.*;
//import java.math.BigDecimal;
//
//public class NewAccountRequest {
//
//	private Long customerId; // optional if new customer
//    private String customerName; // if new customer
//    private String customerEmail; // if new customer
//    private String accountType;
//    private BigDecimal initialDeposit;
//    
//    
//	public NewAccountRequest() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
//	public NewAccountRequest(Long customerId, String customerName, String customerEmail, String accountType,
//			BigDecimal initialDeposit) {
//		super();
//		this.customerId = customerId;
//		this.customerName = customerName;
//		this.customerEmail = customerEmail;
//		this.accountType = accountType;
//		this.initialDeposit = initialDeposit;
//	}
//	public Long getCustomerId() {
//		return customerId;
//	}
//	public void setCustomerId(Long customerId) {
//		this.customerId = customerId;
//	}
//	public String getCustomerName() {
//		return customerName;
//	}
//	public void setCustomerName(String customerName) {
//		this.customerName = customerName;
//	}
//	public String getCustomerEmail() {
//		return customerEmail;
//	}
//	public void setCustomerEmail(String customerEmail) {
//		this.customerEmail = customerEmail;
//	}
//	public String getAccountType() {
//		return accountType;
//	}
//	public void setAccountType(String accountType) {
//		this.accountType = accountType;
//	}
//	public BigDecimal getInitialDeposit() {
//		return initialDeposit;
//	}
//	public void setInitialDeposit(BigDecimal initialDeposit) {
//		this.initialDeposit = initialDeposit;
//	}
//    
//    
//}