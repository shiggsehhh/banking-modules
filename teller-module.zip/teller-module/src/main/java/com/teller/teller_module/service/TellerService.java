package com.teller.teller_module.service;

import com.teller.teller_module.dto.*;
import com.teller.teller_module.model.*;

import java.math.BigDecimal;
import java.util.List;

public interface TellerService {

	void processDeposit(Long accountId, BigDecimal amount);
	void processWithdrawal(Long accountId, BigDecimal amount);
    Account openAccount(NewAccountRequest request);
    void approveKyc(Long kycId);
    Account getCustomerAccount(Long customerId);
    List<KYC> getPendingKycApplications();
    void replyToCustomer(Long messageId, String reply);
    void issueCard(Long customerId, String cardType);
    Account getCustomerAccountDetailsByAccountNumber(String accountNo);
    List<Message> getCustomerMessages();
}