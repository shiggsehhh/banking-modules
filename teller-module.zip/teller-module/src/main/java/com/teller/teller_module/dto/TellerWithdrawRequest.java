package com.teller.teller_module.dto;

import java.math.BigDecimal;
import jakarta.validation.constraints.*;

public class TellerWithdrawRequest {

    @NotNull
    private Long accountId;  // Changed from customerId to accountId

    @NotNull
    @Positive
    private BigDecimal amount;

    public TellerWithdrawRequest() {
        super();
    }

    public TellerWithdrawRequest(@NotNull Long accountId, @NotNull @Positive BigDecimal amount) {
        super();
        this.accountId = accountId;
        this.amount = amount;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
}
