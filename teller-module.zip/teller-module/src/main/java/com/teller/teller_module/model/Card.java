package com.teller.teller_module.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class Card {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String cardNumber;

	private String cardType; // DEBIT, CREDIT

	private LocalDate issueDate;

	private LocalDate expiryDate;

	private boolean active;
	@Enumerated(EnumType.STRING)
	private CardType type;
	private String status; // Add this field

	// Getter and Setter for status

	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user;

	public Card(Long id, String cardNumber, String cardType, LocalDate issueDate, LocalDate expiryDate, boolean active,
			User user) {
		super();
		this.id = id;
		this.cardNumber = cardNumber;
		this.cardType = cardType;
		this.issueDate = issueDate;
		this.expiryDate = expiryDate;
		this.active = active;
		this.user = user;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Card() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public LocalDate getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public CardType getType() {
		return type;
	}

	public void setType(CardType type) {
		this.type = type;
	}

}