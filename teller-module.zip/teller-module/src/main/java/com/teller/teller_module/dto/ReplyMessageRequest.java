package com.teller.teller_module.dto;

import jakarta.validation.constraints.*;

public class ReplyMessageRequest {

    @NotNull
    private Long messageId;

    @NotBlank
    private String reply;

	public ReplyMessageRequest() {
		super();
	}

	public ReplyMessageRequest(@NotNull Long messageId, @NotBlank String reply) {
		super();
		this.messageId = messageId;
		this.reply = reply;
	}

	public Long getMessageId() {
		return messageId;
	}

	public void setMessageId(Long messageId) {
		this.messageId = messageId;
	}

	public String getReply() {
		return reply;
	}

	public void setReply(String reply) {
		this.reply = reply;
	}

    
}
