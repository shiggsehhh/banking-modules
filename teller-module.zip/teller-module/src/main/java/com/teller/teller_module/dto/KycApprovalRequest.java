package com.teller.teller_module.dto;

import jakarta.validation.constraints.NotNull;

public class KycApprovalRequest {

    @NotNull
    private Long kycId;
    
    public KycApprovalRequest() {
		super();
		
	}


	public KycApprovalRequest(@NotNull Long kycId) {
		super();
		this.kycId = kycId;
	}

	public Long getKycId() {
		return kycId;
	}

	public void setKycId(Long kycId) {
		this.kycId = kycId;
	}

    
}
