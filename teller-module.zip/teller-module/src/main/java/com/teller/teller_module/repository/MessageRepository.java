package com.teller.teller_module.repository;

import com.teller.teller_module.model.Message;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MessageRepository extends JpaRepository<Message, Long> {
    // Optionally, add filter by customer/teller ID
}