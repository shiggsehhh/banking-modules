package com.teller.teller_module.model;

public enum Role {
	  CUSTOMER,
	    TELLER,
	    ADMIN
}
