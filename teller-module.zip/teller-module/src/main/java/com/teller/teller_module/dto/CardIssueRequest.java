package com.teller.teller_module.dto;

import jakarta.validation.constraints.*;

public class CardIssueRequest {

    public CardIssueRequest() {
		super();
	}

	public CardIssueRequest(@NotNull Long customerId, @NotBlank String cardType) {
		super();
		this.customerId = customerId;
		this.cardType = cardType;
	}

	@NotNull
    private Long customerId;

    @NotBlank
    private String cardType; // DEBIT or CREDIT

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}    
}