package com.teller.teller_module.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.teller.teller_module.dto.NewAccountRequest;
import com.teller.teller_module.model.Account;
import com.teller.teller_module.model.Card;
import com.teller.teller_module.model.CardType;
import com.teller.teller_module.model.KYC;
import com.teller.teller_module.model.Message;
import com.teller.teller_module.model.Role;
import com.teller.teller_module.model.Transaction;
import com.teller.teller_module.model.User;
import com.teller.teller_module.repository.AccountRepository;
import com.teller.teller_module.repository.CardRepository;
import com.teller.teller_module.repository.KYCRepository;
import com.teller.teller_module.repository.MessageRepository;
import com.teller.teller_module.repository.TransactionRepository;
import com.teller.teller_module.repository.UserRepository;

@Service
public class TellerServiceImpl implements TellerService {

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private KYCRepository kycRepository;

    @Autowired
    private MessageRepository messageRepository;

    @Autowired
    private CardRepository cardRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    @Transactional
    public void processDeposit(Long accountId, BigDecimal amount) {
        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> new RuntimeException("Account not found with id: " + accountId));

        account.setBalance(account.getBalance().add(amount));
        accountRepository.save(account);

        Transaction txn = new Transaction("DEPOSIT", amount, account);
        transactionRepository.save(txn);
    }

    @Override
    @Transactional
    public void processWithdrawal(Long accountId, BigDecimal amount) {
        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> new RuntimeException("Account not found with id: " + accountId));

        if (account.getBalance().compareTo(amount) < 0) {
            throw new RuntimeException("Insufficient balance");
        }

        account.setBalance(account.getBalance().subtract(amount));
        accountRepository.save(account);

        Transaction txn = new Transaction("WITHDRAWAL", amount, account);
        transactionRepository.save(txn);
    }

    @Override
    @Transactional
    public Account openAccount(NewAccountRequest request) {

        User user;

        // Check if it's a new customer or existing
        if (request.getCustomerId() != null) {
            // Existing customer
            user = userRepository.findById(request.getCustomerId())
                    .orElseThrow(() -> new RuntimeException("Customer not found with ID: " + request.getCustomerId()));
        } else {
            // New customer
            user = new User();
            user.setFullName(request.getCustomerName());
            user.setEmail(request.getCustomerEmail());
            user.setPhone(request.getPhone());      // Newly added
            user.setAddress(request.getAddress());  // Newly added
            user.setRole(Role.CUSTOMER);
            user = userRepository.save(user); // Save new user to DB
        }

        // Create account and link to user
        Account account = new Account();
        account.setUser(user);
        account.setAccountType(request.getAccountType());
        account.setBalance(request.getInitialDeposit());
        account.setCreatedAt(LocalDateTime.now());

        // Optionally, generate a unique account number here
        account.setAccountNumber(generateUniqueAccountNumber());

        // Save account
        return accountRepository.save(account);
    }

    private String generateUniqueAccountNumber() {
        return "ACCT" + System.currentTimeMillis();
    }

    @Override
    public void approveKyc(Long kycId) {
        KYC kyc = kycRepository.findById(kycId)
                .orElseThrow(() -> new RuntimeException("KYC not found"));
        kyc.setStatus("APPROVED");
        kycRepository.save(kyc);
    }

    @Override
    public Account getCustomerAccountDetailsByAccountNumber(String accountNo) {
        return accountRepository.findByAccountNumber(accountNo)
                .orElseThrow(() -> new RuntimeException("Account not found for accountNo: " + accountNo));
    }

    @Override
    public Account getCustomerAccount(Long customerId) {
        // You can keep this method if needed, unchanged
        return accountRepository.findById(customerId)
                .stream()
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Account not found for customerId: " + customerId));
    }

    @Override
    public java.util.List<KYC> getPendingKycApplications() {
        return kycRepository.findByStatus("PENDING");
    }

    @Override
    public void replyToCustomer(Long messageId, String reply) {
        Message msg = messageRepository.findById(messageId)
                .orElseThrow(() -> new RuntimeException("Message not found"));
        msg.setReply(reply);
        msg.setStatus("REPLIED");
        messageRepository.save(msg);
    }

    @Override
    public java.util.List<Message> getCustomerMessages() {
        return messageRepository.findAll(); // Optionally filter by user type
    }

    @Override
    public void issueCard(Long customerId, String cardType) {
        User user = userRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Card card = new Card();
        card.setUser(user);
        CardType cardTypeEnum = CardType.valueOf(cardType.toUpperCase());
        card.setType(cardTypeEnum);
        card.setStatus("ISSUED");

        cardRepository.save(card);
    }
}
