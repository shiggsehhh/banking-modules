package com.teller.teller_module.repository;

import com.teller.teller_module.model.KYC;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface KYCRepository extends JpaRepository<KYC, Long> {
    List<KYC> findByStatus(String status);
}