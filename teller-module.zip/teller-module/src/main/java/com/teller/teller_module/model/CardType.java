package com.teller.teller_module.model;

public enum CardType {
	DEBIT,
    CREDIT,
    PREPAID 
}
