package com.teller.teller_module;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TellerModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(TellerModuleApplication.class, args);
	}

}
