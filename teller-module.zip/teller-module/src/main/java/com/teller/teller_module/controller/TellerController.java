package com.teller.teller_module.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.teller.teller_module.dto.CardIssueRequest;
import com.teller.teller_module.dto.KycApprovalRequest;
import com.teller.teller_module.dto.NewAccountRequest;
import com.teller.teller_module.dto.ReplyMessageRequest;
import com.teller.teller_module.dto.TellerDepositRequest;
import com.teller.teller_module.dto.TellerWithdrawRequest;
import com.teller.teller_module.model.Account;
import com.teller.teller_module.model.KYC;
import com.teller.teller_module.model.Message;
import com.teller.teller_module.service.TellerService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/teller")
public class TellerController {

    @Autowired
    private TellerService tellerService;

    @GetMapping("/ping")
    public String ping() {
        return "Teller Module is running!";
    }

    // 1. Deposit (updated to use accountId)
    @PostMapping("/deposit")
    public String processCustomerDeposit(@Valid @RequestBody TellerDepositRequest request) {
        tellerService.processDeposit(request.getAccountId(), request.getAmount()); // changed from customerId -> accountId
        return "Deposit successful.";
    }

    // 2. Withdraw (updated to use accountId)
    @PostMapping("/withdraw")
    public String processCustomerWithdrawal(@Valid @RequestBody TellerWithdrawRequest request) {
        tellerService.processWithdrawal(request.getAccountId(), request.getAmount()); // changed from customerId -> accountId
        return "Withdrawal successful.";
    }

    // 3. Open new account
    @PostMapping("/open-account")
    public ResponseEntity<Account> openNewAccount(@RequestBody @Valid NewAccountRequest request) {
        Account account = tellerService.openAccount(request);
        return new ResponseEntity<>(account, HttpStatus.CREATED);
    }

    // 4. Approve KYC
    @PutMapping("/kyc/approve")
    public String approveKyc(@Valid @RequestBody KycApprovalRequest request) {
        tellerService.approveKyc(request.getKycId());
        return "KYC approved.";
    }

    // 5. Get account by account number
    @GetMapping("/customer-account/{accountNo}")
    public Account getCustomerAccountDetails(@PathVariable String accountNo) {
        return tellerService.getCustomerAccountDetailsByAccountNumber(accountNo);
    }

    // 6. Get pending KYCs
    @GetMapping("/customer-kyc/pending")
    public List<KYC> getPendingKycApplications() {
        return tellerService.getPendingKycApplications();
    }

    // 7. Get customer messages
    @GetMapping("/messages/customer")
    public List<Message> getCustomerMessages() {
        return tellerService.getCustomerMessages();
    }

    // 8. Reply to customer
    @PostMapping("/reply-customer")
    public String replyToCustomer(@Valid @RequestBody ReplyMessageRequest request) {
        tellerService.replyToCustomer(request.getMessageId(), request.getReply());
        return "Reply sent to customer.";
    }

    // 9. Issue new card
    @PostMapping("/card/issue")
    public String issueNewCard(@Valid @RequestBody CardIssueRequest request) {
        tellerService.issueCard(request.getCustomerId(), request.getCardType());
        return "Card issued successfully.";
    }
}
