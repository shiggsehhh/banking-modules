package com.teller.teller_module.repository;

import com.teller.teller_module.model.Card;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CardRepository extends JpaRepository<Card, Long> {
    // Add queries like findByUserId if needed
}