package com.teller.teller_module.repository;

import com.teller.teller_module.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
    // You can add methods like findByEmail or findByRole if needed
}
