package com.teller.teller_module.repository;

import com.teller.teller_module.model.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    // Add custom queries if needed later
}