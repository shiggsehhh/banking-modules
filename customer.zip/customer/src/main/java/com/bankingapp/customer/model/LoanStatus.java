package com.bankingapp.customer.model;

public enum LoanStatus {
    PENDING,
    APPROVED,
    REJECTED,
    CLOSED,
    ACTIVE,   // Ensure this is here
    OVERDUE   // Ensure this is here
}