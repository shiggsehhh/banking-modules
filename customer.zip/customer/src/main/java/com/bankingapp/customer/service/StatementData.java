package com.bankingapp.customer.service;

import com.bankingapp.customer.model.Account;
import com.bankingapp.customer.model.Transaction;
import com.bankingapp.customer.model.User;

import java.math.BigDecimal;
import java.util.List;

/**
 * A simple POJO to represent bank statement data for a customer.
 */
public class StatementData {
    private User user;
    private Account account;
    private List<Transaction> transactions;
    private BigDecimal openingBalance;
    private BigDecimal closingBalance;
    private BigDecimal totalDebitsInPeriod;
    private BigDecimal totalCreditsInPeriod;

    // No-argument constructor
    public StatementData() {}

    // All-arguments constructor
    public StatementData(User user, Account account, List<Transaction> transactions,
                         BigDecimal openingBalance, BigDecimal closingBalance,
                         BigDecimal totalDebitsInPeriod, BigDecimal totalCreditsInPeriod) {
        this.user = user;
        this.account = account;
        this.transactions = transactions;
        this.openingBalance = openingBalance;
        this.closingBalance = closingBalance;
        this.totalDebitsInPeriod = totalDebitsInPeriod;
        this.totalCreditsInPeriod = totalCreditsInPeriod;
    }

    // Getters and Setters
    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public List<Transaction> getTransactions() {
        return transactions;
    }

    public void setTransactions(List<Transaction> transactions) {
        this.transactions = transactions;
    }

    public BigDecimal getOpeningBalance() {
        return openingBalance;
    }

    public void setOpeningBalance(BigDecimal openingBalance) {
        this.openingBalance = openingBalance;
    }

    public BigDecimal getClosingBalance() {
        return closingBalance;
    }

    public void setClosingBalance(BigDecimal closingBalance) {
        this.closingBalance = closingBalance;
    }

    public BigDecimal getTotalDebitsInPeriod() {
        return totalDebitsInPeriod;
    }

    public void setTotalDebitsInPeriod(BigDecimal totalDebitsInPeriod) {
        this.totalDebitsInPeriod = totalDebitsInPeriod;
    }

    public BigDecimal getTotalCreditsInPeriod() {
        return totalCreditsInPeriod;
    }

    public void setTotalCreditsInPeriod(BigDecimal totalCreditsInPeriod) {
        this.totalCreditsInPeriod = totalCreditsInPeriod;
    }
}
