package com.bankingapp.customer.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.ui.Model;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import com.bankingapp.customer.model.User; // Assuming your User model path

@Controller
public class PiggyBankPageController {

    @GetMapping("/customer/piggybank")
    public String showPiggyBankPage(Model model, @AuthenticationPrincipal User currentUser) {
        System.out.println("Navigated to Piggy Bank Page");

        if (currentUser != null) {
            // Ensure currentUser.getUserId() returns Integer as per your User model
            Integer userId = currentUser.getUserId();
            String userName = currentUser.getFullName(); // Assuming getFullName() for display

            System.out.println("Authenticated User Found:");
            System.out.println("  User ID: " + userId);
            System.out.println("  Username: " + userName);

            // Add attributes to the model for Thymeleaf to use
            model.addAttribute("userId", userId);
            model.addAttribute("userName", userName);
        } else {
            // Handle cases where no authenticated user is found (e.g., redirect to login)
            System.out.println("No authenticated user found for Piggy Bank Page. Redirecting to login.");
            return "redirect:/login"; // Redirect to login page if user is not authenticated
        }
        return "piggybank"; // Returns the name of the Thymeleaf template (piggybank.html)
    }
}