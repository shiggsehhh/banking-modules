package com.bankingapp.customer.model;

import jakarta.persistence.*; // Use this for Spring Boot 3+ (Jakarta EE 9+)
// import javax.persistence.*; // Use this for Spring Boot 2 (Java EE 8)

import java.math.BigDecimal;
import java.time.LocalDate; // For next_due_date
import java.time.LocalDateTime; // If you prefer for created_at/updated_at instead of java.sql.Timestamp

@Entity
@Table(name = "loans") // Maps to your 'loans' table in the database
public class Loan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "loan_id")
    private Long loanId;

    @Column(name = "user_id", nullable = false)
    private Integer userId; // Links to the User model

    @Column(name = "loan_amount", nullable = false, precision = 15, scale = 2)
    private BigDecimal loanAmount;

    @Column(name = "interest_rate", nullable = false, precision = 5, scale = 2)
    private BigDecimal interestRate;

    @Column(name = "tenure_months", nullable = false) // Matches your DB column name
    private Integer tenureMonths;

    @Enumerated(EnumType.STRING)
    @Column(name = "loan_status", nullable = false, length = 20)
    private LoanStatus loanStatus;

    @Column(name = "emi_amount", precision = 15, scale = 2)
    private BigDecimal emiAmount;

    // Columns you added to your database table:
    @Column(name = "amount_paid", nullable = false, precision = 15, scale = 2)
    private BigDecimal amountPaid;

    @Column(name = "current_due", nullable = false, precision = 15, scale = 2)
    private BigDecimal currentDue;

    // NEW COLUMN: next_due_date
    @Column(name = "next_due_date")
    private LocalDate nextDueDate; // Mapped to DATE in DB
    
    
    @Column(name = "application_date") // Add this column mapping
    private LocalDate applicationDate;
    // Optional fields from your database, adjust as needed
    // @Column(name = "emi_schedule")
    // private String emiSchedule; // Or a custom Java object if you parse JSON

    // @Column(name = "documents")
    // private String documents; // Or a custom list if you parse paths

    // Using LocalDateTime is generally preferred over java.sql.Timestamp for modern JPA
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    @Column(name = "asset_document_path") // Maps to the new column in DB
    private String assetDocumentPath; 
    // Default constructor (required by JPA)
    public Loan() {}

    // --- Getters and Setters (Generate these or copy-paste) ---

    public Long getLoanId() {
        return loanId;
    }

    public void setLoanId(Long loanId) {
        this.loanId = loanId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public BigDecimal getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(BigDecimal loanAmount) {
        this.loanAmount = loanAmount;
    }

    public BigDecimal getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(BigDecimal interestRate) {
        this.interestRate = interestRate;
    }

    public Integer getTenureMonths() {
        return tenureMonths;
    }

    public void setTenureMonths(Integer tenureMonths) {
        this.tenureMonths = tenureMonths;
    }

    public LoanStatus getLoanStatus() {
        return loanStatus;
    }

    public void setLoanStatus(LoanStatus loanStatus) {
        this.loanStatus = loanStatus;
    }

    public BigDecimal getEmiAmount() {
        return emiAmount;
    }

    public void setEmiAmount(BigDecimal emiAmount) {
        this.emiAmount = emiAmount;
    }

    public BigDecimal getAmountPaid() {
        return amountPaid;
    }

    public void setAmountPaid(BigDecimal amountPaid) {
        this.amountPaid = amountPaid;
    }

    public BigDecimal getCurrentDue() {
        return currentDue;
    }

    public void setCurrentDue(BigDecimal currentDue) {
        this.currentDue = currentDue;
    }

    public LocalDate getNextDueDate() { // Getter for the new column
        return nextDueDate;
    }

    public void setNextDueDate(LocalDate nextDueDate) { // Setter for the new column
        this.nextDueDate = nextDueDate;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    public LocalDate getApplicationDate() {
        return applicationDate;
    }

    public void setApplicationDate(LocalDate applicationDate) {
        this.applicationDate = applicationDate;
    }
    
    public String getAssetDocumentPath() {
        return assetDocumentPath;
    }

    public void setAssetDocumentPath(String assetDocumentPath) {
        this.assetDocumentPath = assetDocumentPath;
    }
}