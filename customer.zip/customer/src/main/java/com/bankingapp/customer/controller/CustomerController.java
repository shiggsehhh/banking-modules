package com.bankingapp.customer.controller;

import com.bankingapp.customer.dto.AddressUpdateRequest;
import com.bankingapp.customer.dto.ContactInfoUpdateRequest;
import com.bankingapp.customer.dto.PasswordChangeRequest;
import com.bankingapp.customer.dto.UserProfileDto;
import com.bankingapp.customer.model.Account;
import com.bankingapp.customer.model.Loan;
import com.bankingapp.customer.model.Notification;
import com.bankingapp.customer.model.User;
import com.bankingapp.customer.model.Transaction;
import com.bankingapp.customer.model.TransactionMode;
import com.bankingapp.customer.service.CustomerService;
import com.bankingapp.customer.service.NotificationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping; // <-- ADD THIS IMPORT
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam; // <-- ADD THIS IMPORT
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes; // <-- ADD THIS IMPORT
import com.bankingapp.customer.service.PdfGeneratorService; // <-- NEW
import com.bankingapp.customer.service.StatementData; // <-- NEW
import com.lowagie.text.DocumentException;
import org.springframework.web.bind.annotation.GetMapping; // <-- Ensure this is present
import org.springframework.web.bind.annotation.PostMapping; 
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.math.BigDecimal; // <-- ADD THIS IMPORT
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;  
@Controller
@RequestMapping("/customer")
public class CustomerController {

	@Autowired
	private CustomerService customerService;
	
	@Autowired // <-- ADD THIS
    private PdfGeneratorService pdfGeneratorService; 
	
	@Autowired
	private NotificationService notificationService;
	
	@Autowired
    private BCryptPasswordEncoder passwordEncoder;
	// <-- ADD THIS
	private final Integer DEFAULT_CUSTOMER_ID = 1;

	@GetMapping("/")
	public String redirectToDashboard() {
		return "redirect:/customer/dashboard";
	}

	/**
	 * Handles requests for the customer dashboard. Displays user's name, primary
	 * account balance, and recent transactions.
	 */
	@GetMapping("/dashboard")
	public String viewDashboard(Model model) {
		System.out.println("Dashboard endpoint hit");
		Optional<User> userOptional = customerService.getUserById(DEFAULT_CUSTOMER_ID);
		if (userOptional.isPresent()) {
			User customerUser = userOptional.get();
			model.addAttribute("userName", customerUser.getFullName());

			Optional<Account> primaryAccount = customerService.getPrimaryAccountForUser(DEFAULT_CUSTOMER_ID);
			primaryAccount.ifPresent(account -> model.addAttribute("accountBalance", account.getBalance()));
			primaryAccount.ifPresent(account -> model.addAttribute("accountNumber", account.getAccountNumber()));

			List<Transaction> recentTransactions = customerService.getRecentTransactionsForUser(DEFAULT_CUSTOMER_ID);
			model.addAttribute("recentTransactions", recentTransactions);

			// Add flash attributes if redirected from transfer (for messages)
			// These messages come from RedirectAttributes in the processTransfer method
			if (model.containsAttribute("transferSuccess")) {
				model.addAttribute("transferSuccess", model.getAttribute("transferSuccess"));
			}
			if (model.containsAttribute("transferError")) {
				model.addAttribute("transferError", model.getAttribute("transferError"));
			}

			return "dashboard";
		} else {
			return "error";
		}
	}

	/**
	 * Handles requests to view all account details for the customer. Feature: View
	 * Account Details
	 */
	@GetMapping("/accounts")
	public String viewAccounts(Model model) {
		List<Account> accounts = customerService.getAccountsByUserId(DEFAULT_CUSTOMER_ID);
		model.addAttribute("accounts", accounts);
		return "account-details"; // Renders src/main/resources/templates/account-details.html
	}

	/**
	 * Optional: View details of a specific account by ID.
	 */
	@GetMapping("/accounts/{accountId}")
	public String viewAccountDetail(@PathVariable Long accountId, Model model) {
		Optional<Account> accountOptional = customerService.getAccountById(accountId);

		if (accountOptional.isPresent() && accountOptional.get().getUserId().equals(DEFAULT_CUSTOMER_ID)) {
			model.addAttribute("account", accountOptional.get());
			return "single-account-detail"; // Renders src/main/resources/templates/single-account-detail.html
		} else {
			// Account not found or doesn't belong to the default user
			return "error"; // Placeholder error page
		}
	}

	/**
	 * Handles requests for the customer's transaction history. Displays all
	 * transactions for the logged-in customer. Feature: View Transaction History
	 */
	@GetMapping("/transactions")
	public String viewTransactionHistory(Model model) {
		List<Transaction> allTransactions = customerService.getAllTransactionsForUser(DEFAULT_CUSTOMER_ID);
		model.addAttribute("allTransactions", allTransactions);
		return "transaction-history"; // Renders src/main/resources/templates/transaction-history.html
	}

	/**
	 * Displays the form for making a new transfer. Accessible via GET
	 * /customer/transfer
	 */
	@GetMapping("/transfer")
	public String showTransferForm(Model model) {
		// Retrieve flash attributes if redirected back to the form (e.g., on validation
		// error)
		if (model.containsAttribute("transferError")) {
			model.addAttribute("transferError", model.getAttribute("transferError"));
		}
		return "make-transfer"; // Renders src/main/resources/templates/make-transfer.html
	}

	/**
	 * Handles the submission of the transfer form. Accessible via POST
	 * /customer/transfer
	 */
	@PostMapping("/transfer")
	public String processTransfer(@RequestParam("recipientName") String recipientName,
			@RequestParam("recipientAccountNumber") String recipientAccountNumber,
			@RequestParam("recipientIfscCode") String recipientIfscCode, @RequestParam("amount") BigDecimal amount, // Spring
																													// can
																													// directly
																													// convert
																													// if
																													// valid
			RedirectAttributes redirectAttributes // Used for flash attributes across redirect
	) {
		// Basic server-side validation for amount
		if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
			redirectAttributes.addFlashAttribute("transferError", "Transfer amount must be positive.");
			return "redirect:/customer/transfer"; // Redirect back to the form
		}

		try {
			// Call the service method to perform the transfer logic
			// This method will be implemented in CustomerService next
			customerService.performTransfer(DEFAULT_CUSTOMER_ID, // Sender User ID
					recipientName, recipientAccountNumber, recipientIfscCode, amount);
			// On success, add a success message and redirect to dashboard
			redirectAttributes.addFlashAttribute("transferSuccess",
					"Transfer of ₹" + amount + " to " + recipientName + " successful!");
			return "redirect:/customer/dashboard";
		} catch (IllegalArgumentException e) {
			// Catch specific business logic errors from service (e.g., insufficient funds)
			redirectAttributes.addFlashAttribute("transferError", e.getMessage());
			return "redirect:/customer/transfer"; // Redirect back to form with error
		} catch (Exception e) {
			// Catch any other unexpected errors (e.g., database issues)
			redirectAttributes.addFlashAttribute("transferError",
					"An unexpected error occurred during transfer: " + e.getMessage());
			return "redirect:/customer/transfer"; // Redirect back to form with error
		}
	}
	 /**
     * Displays the form for depositing money into the account.
     * Accessible via GET /customer/deposit
     */
    @GetMapping("/deposit")
    public String showDepositForm(Model model) {
        // Add flash attributes if redirected back to the form (e.g., on validation error)
        if (model.containsAttribute("depositError")) {
            model.addAttribute("depositError", model.getAttribute("depositError"));
        }
        return "deposit-form"; // Renders src/main/resources/templates/deposit-form.html
    }

    /**
     * Handles the submission of the deposit form.
     * Accessible via POST /customer/deposit
     */
    @PostMapping("/deposit")
    public String processDeposit(
            @RequestParam("amount") BigDecimal amount,
            @RequestParam("transactionMode") String transactionModeString, // Receive as String, convert to enum
            RedirectAttributes redirectAttributes
    ) {
        // Basic server-side validation for amount
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            redirectAttributes.addFlashAttribute("depositError", "Deposit amount must be positive.");
            return "redirect:/customer/deposit";
        }

        TransactionMode mode;
        try {
            mode = TransactionMode.valueOf(transactionModeString); // Convert string to enum
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("depositError", "Invalid deposit mode selected.");
            return "redirect:/customer/deposit";
        }

        try {
            // Call the service method to perform the deposit
            // This method will be implemented in CustomerService next
            customerService.processDeposit(DEFAULT_CUSTOMER_ID, amount, mode);

            redirectAttributes.addFlashAttribute("depositSuccess", "Successfully deposited ₹" + amount + " via " + mode + ".");
            return "redirect:/customer/dashboard"; // Redirect to dashboard on success
        } catch (IllegalArgumentException e) {
            // Catch specific business logic errors from service (if any for deposit)
            redirectAttributes.addFlashAttribute("depositError", e.getMessage());
            return "redirect:/customer/deposit"; // Redirect back to form with error
        } catch (Exception e) {
            // Catch any other unexpected errors
            redirectAttributes.addFlashAttribute("depositError", "An unexpected error occurred during deposit: " + e.getMessage());
            return "redirect:/customer/deposit"; // Redirect back to form with error
        }
    }
    
 // --- NEW METHOD for Loan Zone functionality ---
    /**
     * Displays the loan zone page, showing all loans for the logged-in customer.
     * Accessible via GET /customer/loan-zone
     */
    @GetMapping("/loan-zone")
    public String viewLoanZone(Model model) {
        // Fetch all loans for the default customer
        List<Loan> customerLoans = customerService.getLoansByUserId(DEFAULT_CUSTOMER_ID);
        model.addAttribute("loans", customerLoans); // Add the list of loans to the model

        // Add flash attributes for messages (e.g., eligibility messages)
        if (model.containsAttribute("loanMessage")) {
            model.addAttribute("loanMessage", model.getAttribute("loanMessage"));
        }

        return "loan-zone"; // Render src/main/resources/templates/loan-zone.html
    }
    
    @PostMapping("/loan-zone/pay")
    public String processLoanPayment(
            @RequestParam("loanId") Long loanId,
            @RequestParam("paymentAmount") BigDecimal paymentAmount,
            RedirectAttributes redirectAttributes) {

        if (paymentAmount == null || paymentAmount.compareTo(BigDecimal.ZERO) <= 0) {
            redirectAttributes.addFlashAttribute("loanMessage", "Payment amount must be positive.");
            return "redirect:/customer/loan-zone";
        }

        try {
            BigDecimal newBalance = customerService.processLoanPayment(DEFAULT_CUSTOMER_ID, loanId, paymentAmount);

            // Create a map to hold success details for the pop-up
            Map<String, String> paymentSuccessDetails = new HashMap<>();
            paymentSuccessDetails.put("paidAmount", paymentAmount.toPlainString()); // Convert to string for flash attribute
            paymentSuccessDetails.put("newBalance", newBalance.toPlainString());   // Convert to string

            redirectAttributes.addFlashAttribute("paymentSuccessDetails", paymentSuccessDetails);
            redirectAttributes.addFlashAttribute("loanMessage", "Loan payment for ID " + loanId + " successful!"); // Still keep this for general feedback

            return "redirect:/customer/loan-zone";
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("loanMessage", "Payment failed: " + e.getMessage());
            return "redirect:/customer/loan-zone";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("loanMessage", "An unexpected error occurred during payment: " + e.getMessage());
            e.printStackTrace();
            return "redirect:/customer/loan-zone";
        }
    }
    
    /**
     * Displays the loan application form.
     * Accessible via GET /customer/loan-zone/apply
     */
    @GetMapping("/loan-zone/apply")
    public String showLoanApplicationForm(Model model) {
        // Add flash attributes if redirected from a failed application (for messages)
        if (model.containsAttribute("loanApplicationMessage")) {
            model.addAttribute("loanApplicationMessage", model.getAttribute("loanApplicationMessage"));
            model.addAttribute("loanApplicationSuccess", model.getAttribute("loanApplicationSuccess")); // To determine message type
        }
        return "loan-apply"; // Renders src/main/resources/templates/loan-apply.html
    }

    /**
     * Handles the submission of the loan application form.
     * Accessible via POST /customer/loan-zone/apply
     */
    @PostMapping("/loan-zone/apply")
    public String processLoanApplication(
            @RequestParam("loanAmount") BigDecimal loanAmount,
            @RequestParam("loanTermMonths") Integer loanTermMonths,
            @RequestParam(value = "assetDocument", required = false) MultipartFile assetDocument, // ADD THIS PARAMETER
            RedirectAttributes redirectAttributes) {

        if (loanAmount == null || loanAmount.compareTo(BigDecimal.ZERO) <= 0) {
            redirectAttributes.addFlashAttribute("loanApplicationMessage", "Loan amount must be positive.");
            redirectAttributes.addFlashAttribute("loanApplicationSuccess", false);
            return "redirect:/customer/loan-zone/apply";
        }
        // Add similar validation for loanTermMonths if not already handled by HTML5 min/max
        if (loanTermMonths == null || loanTermMonths <= 0) {
             redirectAttributes.addFlashAttribute("loanApplicationMessage", "Loan term must be positive.");
             redirectAttributes.addFlashAttribute("loanApplicationSuccess", false);
             return "redirect:/customer/loan-zone/apply";
        }


        try {
            // Pass the assetDocument to the service method
            boolean success = customerService.applyForLoan(DEFAULT_CUSTOMER_ID, loanAmount, loanTermMonths, assetDocument);
            if (success) {
                redirectAttributes.addFlashAttribute("loanApplicationMessage", "Loan application submitted successfully! It is now PENDING approval.");
                redirectAttributes.addFlashAttribute("loanApplicationSuccess", true);
            } else {
                redirectAttributes.addFlashAttribute("loanApplicationMessage", "Loan application failed. Please try again.");
                redirectAttributes.addFlashAttribute("loanApplicationSuccess", false);
            }
            return "redirect:/customer/loan-zone";
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("loanApplicationMessage", "Loan application failed: " + e.getMessage());
            redirectAttributes.addFlashAttribute("loanApplicationSuccess", false);
            return "redirect:/customer/loan-zone/apply";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("loanApplicationMessage", "An unexpected error occurred during loan application: " + e.getMessage());
            redirectAttributes.addFlashAttribute("loanApplicationSuccess", false);
            e.printStackTrace();
            return "redirect:/customer/loan-zone/apply";
        }
    }
    
    /**
     * Handles the request to download account statement as PDF.
     * Accessible via GET /customer/download-statement
     */
    @GetMapping("/download-statement") // This is the URL to display the form page
    public String showDownloadStatementPage(Model model) {
        // You can add any model attributes here if you want to pass data to the HTML,
        // for example, an error message if redirected from a failed PDF generation attempt.
        return "download-statement"; // Returns the name of the Thymeleaf template (download-statement.html)
    }


    /**
     * This method is specifically for GENERATING and DOWNLOADING the PDF.
     * It's triggered when the form on download-statement.html is submitted.
     * Notice the DIFFERENT @GetMapping path.
     */
    @GetMapping("/generate-statement-pdf") // This is the new URL for PDF generation
    public void generateStatementPdf( // Renamed method for clarity
            @RequestParam("startDate") LocalDate startDate,
            @RequestParam("endDate") LocalDate endDate,
            HttpServletResponse response) throws IOException, DocumentException {

        // Set content type and header for PDF download
        response.setContentType("application/pdf");
        String headerKey = "Content-Disposition";
        String headerValue = String.format("attachment; filename=account_statement_%s_to_%s.pdf",
                startDate.toString(), endDate.toString());
        response.setHeader(headerKey, headerValue);

        try {
            // 1. Fetch the necessary data using CustomerService
            StatementData statementData = customerService.getTransactionsForStatement(
                    DEFAULT_CUSTOMER_ID, startDate, endDate);

            // 2. Generate the PDF using PdfGeneratorService
            byte[] pdfBytes = pdfGeneratorService.generateStatementPdf(
                    statementData, startDate, endDate);

            // 3. Write the PDF bytes to the response output stream
            response.getOutputStream().write(pdfBytes);
            response.getOutputStream().flush();
            response.getOutputStream().close();

        } catch (IllegalArgumentException e) {
            // For errors from PDF generation, you might want to redirect back to the form page
            // with an error message in the URL or using RedirectAttributes.
            // For simplicity, here we'll send an HTTP error:
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, e.getMessage());
            e.printStackTrace();
        } catch (DocumentException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error generating PDF: " + e.getMessage());
            e.printStackTrace();
        } catch (IOException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error writing PDF to response: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) { // Catch any other unexpected errors
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An unexpected error occurred: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * API endpoint to fetch notifications for the logged-in customer.
     * Returns a list of Notification objects (will be converted to JSON automatically).
     */
    @GetMapping("/notifications") // New endpoint for fetching notifications
    @ResponseBody // This annotation is crucial to return data (JSON/XML), not a view name
    public List<Notification> getCustomerNotifications() {
        // In a real application, you would get the authenticated user's ID
        // For now, we'll use the DEFAULT_CUSTOMER_ID for testing
        return notificationService.getNotificationsByUserId(DEFAULT_CUSTOMER_ID);
    }
    
    @GetMapping("/all-notifications")
    public String showAllNotifications(Model model) {
        // In a real application, get the authenticated user's ID securely
        // For now, we'll use the DEFAULT_CUSTOMER_ID for testing
        List<Notification> allNotifications = // <--- CHANGE THIS LINE!
                notificationService.getNotificationsByUserId(DEFAULT_CUSTOMER_ID);

        model.addAttribute("notifications", allNotifications);
        return "all-notifications"; // This tells Thymeleaf to render all-notifications.html
    }
    
    /**
     * Endpoint to manually update the read status of a specific notification.
     * Expects a JSON body like: {"isRead": true} or {"isRead": false}
     * @param notificationId The ID of the notification to update.
     * @param payload A map containing the "isRead" boolean status.
     * @return ResponseEntity with updated notification or error status.
     */
    @PutMapping("/notifications/{notificationId}/status")
    @ResponseBody // Crucial: this method returns data (JSON), not a view
    public ResponseEntity<com.bankingapp.customer.model.Notification> updateNotificationStatus(
            @PathVariable Long notificationId,
            @RequestBody Map<String, Boolean> payload) {

        // Basic validation for the payload
        if (payload == null || !payload.containsKey("isRead")) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        Boolean isRead = payload.get("isRead");

        // In a real app, you'd verify the notification belongs to the authenticated user
        // For now, we rely on the service to handle the findById correctly.
        // If you add user context to the service method, use that here.
        // For simplicity in this example, we're not adding user verification here.

        return notificationService.setNotificationReadStatus(notificationId, isRead)
                .map(updatedNotification -> new ResponseEntity<>(updatedNotification, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND)); // If notification not found
    }
    
    /**
     * Displays the user's profile page with their personal and primary account details.
     * @param model The Spring Model to pass data to the view.
     * @return The name of the profile view.
     */
    @GetMapping("/profile")
    public String showProfile(Model model) {
        Optional<UserProfileDto> userProfileOptional = customerService.getUserProfile(DEFAULT_CUSTOMER_ID);

        if (userProfileOptional.isPresent()) {
            model.addAttribute("userProfile", userProfileOptional.get());
            return "profile"; // This will resolve to src/main/resources/templates/profile.html
        } else {
            // Handle case where user profile cannot be found (e.g., user ID is invalid)
            model.addAttribute("errorMessage", "User profile not found.");
            return "dashboard"; // Redirect to dashboard or an error page
        }
    }
    
    /**
     * Handles requests to change the user's password.
     * @param passwordChangeRequest DTO containing current, new, and confirm new passwords.
     * @return ResponseEntity indicating success or failure.
     */
    @PutMapping("/profile/password")
    @ResponseBody // This endpoint returns JSON/text, not a view
    public ResponseEntity<String> changePassword(@RequestBody PasswordChangeRequest passwordChangeRequest) {
        // In a real application, you'd get the userId from the authenticated session
        Integer userId = DEFAULT_CUSTOMER_ID; // Using default for now

        if (!passwordChangeRequest.getNewPassword().equals(passwordChangeRequest.getConfirmNewPassword())) {
            return new ResponseEntity<>("New password and confirmation do not match.", HttpStatus.BAD_REQUEST);
        }

        try {
            // The actual password change logic will be in CustomerService
            customerService.changePassword(
                userId,
                passwordChangeRequest.getCurrentPassword(),
                passwordChangeRequest.getNewPassword()
            );
            return new ResponseEntity<>("Password changed successfully.", HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred during password change.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Handles requests to update the user's contact information (email and phone).
     * @param contactInfoUpdateRequest DTO containing new email and phone.
     * @return ResponseEntity indicating success or failure.
     */
    @PutMapping("/profile/contact-info")
    @ResponseBody // This endpoint returns JSON/text, not a view
    public ResponseEntity<String> updateContactInfo(@RequestBody ContactInfoUpdateRequest contactInfoUpdateRequest) {
        // In a real application, you'd get the userId from the authenticated session
        Integer userId = DEFAULT_CUSTOMER_ID; // Using default for now

        try {
            customerService.updateContactInfo(
                userId,
                contactInfoUpdateRequest.getEmail(),
                contactInfoUpdateRequest.getPhone()
            );
            return new ResponseEntity<>("Contact information updated successfully.", HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred during contact info update.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Handles requests to update the user's residential address.
     * @param addressUpdateRequest DTO containing the new address.
     * @return ResponseEntity indicating success or failure.
     */
    @PutMapping("/profile/address")
    @ResponseBody // This endpoint returns JSON/text, not a view
    public ResponseEntity<String> updateAddress(@RequestBody AddressUpdateRequest addressUpdateRequest) {
        // In a real application, you'd get the userId from the authenticated session
        Integer userId = DEFAULT_CUSTOMER_ID; // Using default for now

        try {
            customerService.updateAddress(
                userId,
                addressUpdateRequest.getAddress()
            );
            return new ResponseEntity<>("Address updated successfully.", HttpStatus.OK);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred during address update.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}