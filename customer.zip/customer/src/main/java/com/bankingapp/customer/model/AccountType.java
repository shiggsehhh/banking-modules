package com.bankingapp.customer.model;

public enum AccountType {
    Savings,
    Current,
    Fixed_Deposit // Use underscore for enum name if DB has space/underscore, or adjust mapping
}