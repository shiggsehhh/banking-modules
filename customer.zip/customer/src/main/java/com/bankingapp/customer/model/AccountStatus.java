package com.bankingapp.customer.model;

public enum AccountStatus {
    Active,
    Closed,
    Frozen
}