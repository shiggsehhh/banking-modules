package com.bankingapp.customer.repository;

import com.bankingapp.customer.model.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface AccountRepository extends JpaRepository<Account, Long> {
    // This is the correct signature for finding accounts by user ID, as user_id is Integer
    List<Account> findByUserId(Integer userId);

    // This remains correct for finding an account by its number
    Optional<Account> findByAccountNumber(String accountNumber);

    // JpaRepository<Account, Long> already provides:
    // Optional<Account> findById(Long id);
    // No need to explicitly declare it here.
}