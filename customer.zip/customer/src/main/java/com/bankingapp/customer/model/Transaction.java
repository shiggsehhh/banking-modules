package com.bankingapp.customer.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "transactions")
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "transaction_id")
    private Long transactionId;

    @Column(name = "account_id", nullable = false)
    private Long accountId; // Foreign key to Account

    @Enumerated(EnumType.STRING)
    @Column(name = "transaction_type", nullable = false)
    private TransactionType transactionType;

    @Column(name = "amount", nullable = false)
    private BigDecimal amount;

    @Enumerated(EnumType.STRING)
    @Column(name = "transaction_mode") // Default 'NEFT' is handled by DB
    private TransactionMode transactionMode;

    @Column(name = "transaction_date") // Default CURRENT_TIMESTAMP is handled by DB
    private LocalDateTime transactionDate;

    @Column(name = "reference_account_number", length = 20)
    private String referenceAccountNumber;

    @Column(name = "description", length = 255)
    private String description;

    // Optional: ManyToOne relationship to Account if needed for full object graph
    // @ManyToOne(fetch = FetchType.LAZY)
    // @JoinColumn(name = "account_id", insertable = false, updatable = false)
    // private Account account;

    // --- Constructors ---
    public Transaction() {
    }

    public Transaction(Long accountId, TransactionType transactionType, BigDecimal amount,
                       TransactionMode transactionMode, LocalDateTime transactionDate,
                       String referenceAccountNumber, String description) {
        this.accountId = accountId;
        this.transactionType = transactionType;
        this.amount = amount;
        this.transactionMode = transactionMode;
        this.transactionDate = transactionDate;
        this.referenceAccountNumber = referenceAccountNumber;
        this.description = description;
    }

    // --- Getters and Setters ---
    public Long getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(Long transactionId) {
        this.transactionId = transactionId;
    }

    public Long getAccountId() {
        return accountId;
    }

    public void setAccountId(Long accountId) {
        this.accountId = accountId;
    }

    public TransactionType getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(TransactionType transactionType) {
        this.transactionType = transactionType;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public TransactionMode getTransactionMode() {
        return transactionMode;
    }

    public void setTransactionMode(TransactionMode transactionMode) {
        this.transactionMode = transactionMode;
    }

    public LocalDateTime getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(LocalDateTime transactionDate) {
        this.transactionDate = transactionDate;
    }

    public String getReferenceAccountNumber() {
        return referenceAccountNumber;
    }

    public void setReferenceAccountNumber(String referenceAccountNumber) {
        this.referenceAccountNumber = referenceAccountNumber;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}