package com.bankingapp.customer.service;

import com.bankingapp.customer.model.PiggyBankGoal;
import com.bankingapp.customer.repository.PiggyBankGoalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
public class PiggyBankGoalService {

    @Autowired
    private PiggyBankGoalRepository piggyBankGoalRepository;

    public List<PiggyBankGoal> getGoalsByUserId(Integer userId) {
        return piggyBankGoalRepository.findByUserId(userId);
    }

    public PiggyBankGoal createGoal(PiggyBankGoal goal) {
        return piggyBankGoalRepository.save(goal);
    }

    @Transactional
    public Optional<PiggyBankGoal> addFundsToGoal(Integer goalId, BigDecimal amount) {
        if (amount.compareTo(BigDecimal.ZERO) <= 0) return Optional.empty();

        Optional<PiggyBankGoal> goalOptional = piggyBankGoalRepository.findById(goalId);
        if (goalOptional.isPresent()) {
            PiggyBankGoal goal = goalOptional.get();
            BigDecimal newAmount = goal.getCurrentAmount().add(amount);
            if (newAmount.compareTo(goal.getTargetAmount()) > 0) newAmount = goal.getTargetAmount();
            goal.setCurrentAmount(newAmount);
            return Optional.of(piggyBankGoalRepository.save(goal));
        }
        return Optional.empty();
    }

    public Optional<PiggyBankGoal> getGoalById(Integer goalId) {
        return piggyBankGoalRepository.findById(goalId);
    }

    public void deleteGoal(Integer goalId) {
        piggyBankGoalRepository.deleteById(goalId);
    }
}