package com.bankingapp.customer.model;

public enum TransactionMode {
    NEFT, IMPS, Cash, Cheque
}